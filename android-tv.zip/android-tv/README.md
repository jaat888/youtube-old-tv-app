# YT TV (native Android TV, no WebView)

YouTube-style TV app. Search / home / related come from YouTube's InnerTube API,
stream links from the VISIONOS (+ ANDROID_VR backup) clients (no PO token needed),
playback with Media3 ExoPlayer. Debug-signed with V1+V2 (same keystore as before).

Remote: OK pause | Left/Right seek | Up quality | Down up-next | Back close.
Autoplay: when a video ends, the first related video plays.
