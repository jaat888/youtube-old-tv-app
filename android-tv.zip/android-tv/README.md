# YT TV (native Android TV, no WebView)

YouTube-style TV app. Search / home / related come from YouTube's InnerTube API,
stream links from the VISIONOS (+ ANDROID_VR backup) clients (no PO token needed),
playback with Media3 ExoPlayer. Debug-signed with V1+V2 (same keystore as before).

Remote: OK pause | Left/Right seek | Up quality | Down up-next | Back close.
Autoplay: when a video ends, the first related video plays.

v1.1: search shows videos + channels with suggestions; channel page; Subscribe (saved on the TV,
no login); Home rows "From your subscriptions" / "Because you watched"; chips Subscriptions + My Channels.
Open a channel: OK on a channel card in search, Down in the player (menu), or long-press OK on a video.

Account (after "Sign in" in the sidebar), checked against SmartTube's MediaServiceCore:
- My Channels = the channels the account is subscribed to (cached, refreshed in the background).
- Home / Subscriptions / History = the account's own feeds, now with more pages as you scroll
  (TV answers keep the next-page token in `nextContinuationData`), sponsored tiles are skipped.
- Watching a video reports it to the account History (playback + watchtime, like SmartTube). Best effort.
