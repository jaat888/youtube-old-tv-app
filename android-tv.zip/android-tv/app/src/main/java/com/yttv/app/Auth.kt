package com.yttv.app

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID

/**
 * Sign-in with a TV code, the same way YouTube's own TV app (and SmartTube) does it:
 *  1. read the TV client id / secret from the youtube.com/tv page (nothing is hard-coded here)
 *  2. ask for a device code, show it, the user types it at google.com/device on a phone
 *  3. poll until the user approves -> refresh token (saved on the TV only)
 */
object Auth {
    const val TV_UA = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version"
    const val TV_VERSION = "7.20260901.15.00"

    private const val SCOPE = "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content"
    private const val DEVICE_URL = "https://www.youtube.com/o/oauth2/device/code"
    private const val TOKEN_URL = "https://www.youtube.com/o/oauth2/token"

    class Code(val device: String, val user: String, val url: String, val expiresIn: Int, val interval: Int)

    @Volatile private var cid = ""
    @Volatile private var csec = ""
    @Volatile private var access = ""
    @Volatile private var accessUntil = 0L

    fun signedIn(c: Context): Boolean = Store.authRefresh(c).isNotEmpty()

    fun signOut(c: Context) {
        Store.setAuthRefresh(c, "")
        Store.clearAccount(c)
        access = ""
        accessUntil = 0L
    }

    // ------------------------------------------------------------------ http helpers

    private fun getText(url: String): String {
        val req = Request.Builder().url(url)
            .header("User-Agent", TV_UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "SOCS=CAI; CONSENT=YES+1")
            .build()
        YT.http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("YouTube HTTP ${r.code}")
            return r.body?.string() ?: ""
        }
    }

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val req = Request.Builder().url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("User-Agent", TV_UA)
            .build()
        YT.http.newCall(req).execute().use { r ->
            val t = r.body?.string() ?: ""
            return try {
                JSONObject(t)
            } catch (e: Exception) {
                throw RuntimeException("YouTube HTTP ${r.code}")
            }
        }
    }

    /** TV client id + secret, read from the TV page's base script (once per app start). */
    private fun creds() {
        if (cid.isNotEmpty() && csec.isNotEmpty()) return
        synchronized(this) {
            if (cid.isNotEmpty() && csec.isNotEmpty()) return
            val page = getText("https://www.youtube.com/tv")
            val m = Regex("<script[^>]*id=\"base-js\"[^>]*src=\"([^\"]+)\"").find(page)
                ?: Regex("src=\"([^\"]*base\\.js[^\"]*)\"").find(page)
                ?: throw RuntimeException("TV page changed (no base script)")
            var src = m.groupValues[1]
            if (src.startsWith("//")) src = "https:$src"
            else if (src.startsWith("/")) src = "https://www.youtube.com$src"
            val js = getText(src)
            val cm = Regex("clientId:\"([-\\w]+\\.apps\\.googleusercontent\\.com)\",[^\"]*?:\"([\\w-]+)\"").find(js)
                ?: throw RuntimeException("Could not read the TV sign-in client")
            cid = cm.groupValues[1]
            csec = cm.groupValues[2]
        }
    }

    // ------------------------------------------------------------------ sign-in steps

    /** Step 1: get the code to show on the TV. */
    fun startCode(): Code {
        creds()
        val r = postJson(
            DEVICE_URL,
            JSONObject().put("client_id", cid).put("scope", SCOPE)
                .put("device_id", UUID.randomUUID().toString().replace("-", ""))
                .put("model_name", "ytlr::")
        )
        val dc = r.optString("device_code")
        val uc = r.optString("user_code")
        if (dc.isEmpty() || uc.isEmpty()) {
            throw RuntimeException(r.optString("error_description").ifEmpty { r.optString("error").ifEmpty { "No code received" } })
        }
        return Code(
            dc, uc,
            r.optString("verification_url").ifEmpty { "https://www.google.com/device" },
            r.optInt("expires_in", 1800), r.optInt("interval", 5)
        )
    }

    /** Step 2 (repeat): "ok", "pending", "slow", "denied", "expired" or "error:...". */
    fun poll(c: Context, code: Code): String {
        creds()
        val r = postJson(
            TOKEN_URL,
            JSONObject().put("client_id", cid).put("client_secret", csec)
                .put("code", code.device).put("grant_type", "http://oauth.net/grant_type/device/1.0")
        )
        val at = r.optString("access_token")
        if (at.isNotEmpty()) {
            val rt = r.optString("refresh_token")
            if (rt.isNotEmpty()) Store.setAuthRefresh(c, rt)
            access = at
            accessUntil = System.currentTimeMillis() + r.optLong("expires_in", 3600) * 1000L - 60_000L
            return "ok"
        }
        return when (val e = r.optString("error")) {
            "authorization_pending" -> "pending"
            "slow_down" -> "slow"
            "access_denied" -> "denied"
            "expired_token" -> "expired"
            else -> "error:$e"
        }
    }

    /** A valid access token (refreshed when old), or null when signed out. Runs on a background thread. */
    fun token(c: Context): String? {
        val rt = Store.authRefresh(c)
        if (rt.isEmpty()) return null
        if (access.isNotEmpty() && System.currentTimeMillis() < accessUntil) return access
        return synchronized(this) {
            if (access.isNotEmpty() && System.currentTimeMillis() < accessUntil) return@synchronized access
            creds()
            val r = postJson(
                TOKEN_URL,
                JSONObject().put("client_id", cid).put("client_secret", csec)
                    .put("refresh_token", rt).put("grant_type", "refresh_token")
            )
            val at = r.optString("access_token")
            if (at.isEmpty()) {
                if (r.optString("error") == "invalid_grant") Store.setAuthRefresh(c, "")
                throw RuntimeException("Sign-in expired, please sign in again")
            }
            access = at
            accessUntil = System.currentTimeMillis() + r.optLong("expires_in", 3600) * 1000L - 60_000L
            at
        }
    }
}
