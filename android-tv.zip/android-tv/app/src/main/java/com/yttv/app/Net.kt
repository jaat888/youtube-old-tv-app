package com.yttv.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Background-thread helper: work runs off the UI thread, ok/fail come back on it. */
object Net {
    val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(4)
    private val imgPool = Executors.newFixedThreadPool(8)
    // the player gets its own threads: starting a video must never wait behind home / row loading
    private val playPool = Executors.newFixedThreadPool(3)

    fun <T> asyncPlay(work: () -> T, ok: (T) -> Unit, fail: (Exception) -> Unit = {}) {
        playPool.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Throwable) {
                main.post { fail(if (e is Exception) e else RuntimeException(e.toString(), e)) }
            }
        }
    }

    fun <T> async(work: () -> T, ok: (T) -> Unit, fail: (Exception) -> Unit = {}) {
        pool.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Throwable) {
                main.post { fail(if (e is Exception) e else RuntimeException(e.toString(), e)) }
            }
        }
    }

    internal fun submitImage(r: Runnable) = imgPool.execute(r)
}

object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    // Disk cache: so posters already seen show instantly next time the app
    // opens, instead of re-downloading from a possibly-slow/cold server.
    // Capped so it can't grow forever - oldest files get trimmed once the
    // folder passes DISK_CACHE_MAX_BYTES.
    private const val DISK_CACHE_MAX_BYTES = 50L * 1024 * 1024
    private var diskDir: java.io.File? = null
    private val diskLock = Any()
    private var writesSinceTrim = 0

    /** Call once (e.g. from MainActivity.onCreate) before the first load(). */
    fun init(appContext: android.content.Context) {
        if (diskDir != null) return
        val d = java.io.File(appContext.cacheDir, "thumbs")
        if (!d.exists()) d.mkdirs()
        diskDir = d
    }

    private fun diskFile(url: String, targetW: Int): java.io.File? {
        val dir = diskDir ?: return null
        val key = java.security.MessageDigest.getInstance("MD5")
            .digest(url.toByteArray()).joinToString("") { "%02x".format(it) }
        return java.io.File(dir, "${key}_$targetW.webp")
    }

    /** Deletes oldest-first until under the cap. Only scans every 20 writes - a
     *  full directory listing on every poster save would be wasteful. */
    private fun trimDiskCacheIfNeeded() {
        val dir = diskDir ?: return
        synchronized(diskLock) {
            writesSinceTrim++
            if (writesSinceTrim < 20) return
            writesSinceTrim = 0
            val files = dir.listFiles() ?: return
            var total = files.sumOf { it.length() }
            if (total <= DISK_CACHE_MAX_BYTES) return
            for (f in files.sortedBy { it.lastModified() }) {
                if (total <= DISK_CACHE_MAX_BYTES) break
                val len = f.length()
                if (f.delete()) total -= len
            }
        }
    }

    fun load(iv: ImageView, url: String, targetW: Int, attempt: Int = 0, onSet: ((Bitmap) -> Unit)? = null) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.animate().cancel(); iv.alpha = 1f
            iv.setImageBitmap(hit)
            onSet?.invoke(hit)
            return
        }
        if (attempt == 0) { iv.animate().cancel(); iv.alpha = 1f; iv.setImageDrawable(null) }
        if (url.isEmpty()) return
        Net.submitImage(Runnable {
          try {
            // Disk cache first: skip the network entirely on a hit.
            val df = diskFile(url, targetW)
            val fromDisk = if (attempt == 0 && df != null && df.exists()) {
                try { BitmapFactory.decodeFile(df.path) } catch (e: Exception) { null }
            } else null
            if (fromDisk != null) {
                cache.put(url, fromDisk)
                Net.main.post { if (iv.tag == url) { fadeIn(iv, fromDisk); onSet?.invoke(fromDisk) } }
                return@Runnable
            }
            val bmp = try {
                download(url, targetW)
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(url, bmp)
                // show the poster FIRST; saving to the disk cache is best-effort and must never block it
                Net.main.post { if (iv.tag == url) { fadeIn(iv, bmp); onSet?.invoke(bmp) } }
                if (df != null) {
                    try {
                        // WEBP_LOSSY only exists on Android 11+ (API 30); older phones crashed here.
                        @Suppress("DEPRECATION")
                        val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        java.io.FileOutputStream(df).use { bmp.compress(fmt, 85, it) }
                        trimDiskCacheIfNeeded()
                    } catch (e: Throwable) { /* disk cache is best-effort */ }
                }
            } else if (attempt < 3) {
                // Server can be asleep for a few seconds (cold start) -> black poster forever.
                // Retry a few times with backoff instead of giving up after one failed try.
                Net.main.postDelayed({ if (iv.tag == url) load(iv, url, targetW, attempt + 1, onSet) }, 1200L * (attempt + 1))
            }
          } catch (t: Throwable) {
            cache.evictAll()   // out of memory etc.: drop cached posters, never crash the app for an image
          }
        })
    }

    /** Poster eases in instead of popping in. */
    private fun fadeIn(iv: ImageView, bmp: Bitmap) {
        iv.alpha = 0f
        iv.setImageBitmap(bmp)
        iv.animate().alpha(1f).setDuration(180).start()
    }

    private fun download(url: String, targetW: Int): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) YtTV/1.0")
            if (c.responseCode !in 200..299) return null
            val bytes = c.inputStream.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= targetW) sample *= 2
            val o2 = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        } finally {
            c.disconnect()
        }
    }
}
