package com.yttv.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** "Sign in with TV code": shows a code, you type it at google.com/device on your phone. */
class SignInActivity : ComponentActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var titleT: TextView
    private lateinit var codeT: TextView
    private lateinit var info: TextView
    private lateinit var again: TextView
    private lateinit var out: TextView
    private var gen = 0
    private var closing = false

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    private fun chip(text: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 18f
        t.setTextColor(Color.WHITE)
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(26), dp(10), dp(26), dp(10))
        t.setBackgroundResource(R.drawable.chip_bg)
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { click() }
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(R.color.bg)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(resources.getColor(R.color.bg))
        root.setPadding(dp(40), dp(20), dp(40), dp(20))

        titleT = TextView(this)
        titleT.setTextColor(Color.WHITE)
        titleT.textSize = 26f
        titleT.setTypeface(null, Typeface.BOLD)
        titleT.gravity = Gravity.CENTER
        root.addView(titleT)

        codeT = TextView(this)
        codeT.setTextColor(Color.WHITE)
        codeT.textSize = 46f
        codeT.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        codeT.gravity = Gravity.CENTER
        codeT.setPadding(0, dp(14), 0, dp(14))
        root.addView(codeT)

        info = TextView(this)
        info.setTextColor(Color.parseColor("#BBBBBB"))
        info.textSize = 17f
        info.gravity = Gravity.CENTER
        root.addView(info)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(0, dp(20), 0, 0)
        val back = chip("\u2039 Back") { finish() }
        again = chip("New code") { start() }
        out = chip("Sign out") {
            Auth.signOut(this)
            Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show()
            finish()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(8)
        lp.rightMargin = dp(8)
        row.addView(back, lp)
        row.addView(again, lp)
        row.addView(out, lp)
        root.addView(row)
        setContentView(root)
        UiUtil.immersive(window)

        if (Auth.signedIn(this)) {
            titleT.text = "You are signed in \u2713"
            codeT.visibility = View.GONE
            again.visibility = View.GONE
            info.text = "Home shows your recommendations, Subscriptions and History come from your account.\nSubscribing here also subscribes on YouTube."
            out.requestFocus()
        } else {
            out.visibility = View.GONE
            start()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    override fun onDestroy() {
        closing = true
        gen++
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun start() {
        val g = ++gen
        handler.removeCallbacksAndMessages(null)
        titleT.text = "Sign in to YouTube"
        codeT.visibility = View.VISIBLE
        codeT.text = "..."
        info.text = "Getting a code..."
        again.visibility = View.GONE
        Net.async({ Auth.startCode() }, { code ->
            if (!closing && g == gen) {
                codeT.text = code.user
                info.text = "On your phone or PC open\n${code.url}\nand enter this code, then allow access."
                poll(code, g, System.currentTimeMillis() + code.expiresIn * 1000L, code.interval)
            }
        }, { e ->
            if (!closing && g == gen) fail("Could not get a code\n(${e.message})")
        })
    }

    private fun fail(msg: String) {
        codeT.text = "\u2014"
        info.text = msg
        again.visibility = View.VISIBLE
        again.requestFocus()
    }

    private fun poll(code: Auth.Code, g: Int, deadline: Long, interval: Int) {
        handler.postDelayed({
            if (!closing && g == gen) {
                Net.async({ Auth.poll(this, code) }, { st ->
                    if (!closing && g == gen) {
                        if (st == "ok") {
                            Toast.makeText(this, "Signed in", Toast.LENGTH_SHORT).show()
                            finish()
                        } else if (st == "denied") {
                            fail("Access was denied.")
                        } else if (st == "expired" || System.currentTimeMillis() > deadline) {
                            fail("The code expired.")
                        } else if (st == "pending" || st == "slow") {
                            poll(code, g, deadline, if (st == "slow") interval + 5 else interval)
                        } else {
                            fail("Sign-in failed ($st)")
                        }
                    }
                }, { _ ->
                    if (!closing && g == gen) poll(code, g, deadline, interval)
                })
            }
        }, interval * 1000L)
    }
}
