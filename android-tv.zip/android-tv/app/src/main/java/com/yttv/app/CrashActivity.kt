package com.yttv.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView

/** Plain Activity (no androidx), runs in its own process so it survives the crash. */
class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.BLACK)
        sv.isFocusable = true
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setPadding(40, 30, 40, 30)
        tv.text = "APP CRASH - screenshot / photo bhej do\n\n" + (intent.getStringExtra("trace") ?: "no trace")
        sv.addView(tv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)
        sv.requestFocus()
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK) { finishAffinity(); return true }
        return super.onKeyDown(k, e)
    }
}
