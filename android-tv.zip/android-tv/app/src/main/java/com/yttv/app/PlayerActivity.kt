package com.yttv.app

import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.util.Locale

/**
 * Full-screen player.
 *   OK            play / pause (+ show bar)
 *   Left / Right  seek 10 s (hold = 30 s)
 *   Up            choose quality
 *   Down          "Up next" list (related videos)
 *   Back          close
 * When a video ends, the first related video plays automatically (autoplay).
 */
class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_VID = "vid"
        private const val BAR_MS = 4000L
    }

    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var spinner: View
    private lateinit var pauseIcon: ImageView
    private lateinit var seekText: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var titleText: TextView
    private lateinit var channelText: TextView
    private lateinit var seekBar: ProgressBar
    private lateinit var timeCur: TextView
    private lateinit var timeDur: TextView

    private var cur: Vid? = null
    private var stream: Stream? = null
    private var related: List<Vid> = emptyList()
    private val played = HashSet<String>()

    private var gen = 0
    private var mode = 0        // 0 = separate video+audio, 1 = single safe file
    private var retries = 0
    private var curHeight = 0
    private var closing = false

    private var pendingSeekMs = -1L
    private var barHideAt = 0L

    private val applySeek = Runnable {
        val p = player ?: return@Runnable
        if (pendingSeekMs >= 0) {
            p.seekTo(pendingSeekMs)
            pendingSeekMs = -1L
        }
        handler.postDelayed({ seekText.visibility = View.GONE }, 700)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.player_view)
        spinner = findViewById(R.id.spinner)
        pauseIcon = findViewById(R.id.pause_icon)
        seekText = findViewById(R.id.seek_text)
        topBar = findViewById(R.id.top_bar)
        bottomBar = findViewById(R.id.bottom_bar)
        titleText = findViewById(R.id.title_text)
        channelText = findViewById(R.id.channel_text)
        seekBar = findViewById(R.id.seek_bar)
        timeCur = findViewById(R.id.time_cur)
        timeDur = findViewById(R.id.time_dur)

        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20_000, 60_000, 2_500, 5_000)
            .build()
        val p = ExoPlayer.Builder(this).setLoadControl(load).build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true
        )
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                spinner.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (state == Player.STATE_ENDED) playNextAuto()
                refreshPauseIcon()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                refreshPauseIcon()
            }

            override fun onPlayerError(error: PlaybackException) {
                onPlaybackFailed(error)
            }
        })
        playerView.player = p
        player = p

        val vid = try {
            Vid.fromJson(JSONObject(intent.getStringExtra(EXTRA_VID) ?: "{}"))
        } catch (e: Exception) {
            null
        }
        if (vid == null || vid.id.isEmpty()) {
            finish()
            return
        }
        startVideo(vid)
        handler.post(tick)
    }

    // ------------------------------------------------------------------ loading

    private fun startVideo(v: Vid) {
        cur = v
        played.add(v.id)
        Store.addHistory(this, v)
        titleText.text = v.title
        channelText.text = listOf(v.channel, v.meta).filter { it.isNotEmpty() }.joinToString("  •  ")
        mode = 0
        retries = 0
        stream = null
        related = emptyList()
        spinner.visibility = View.VISIBLE
        player?.stop()
        player?.clearMediaItems()
        showBars()
        val g = ++gen
        Net.async({ YT.resolve(v.id, 0) }, { s ->
            if (g == gen && !closing) {
                stream = s
                play(s, 0L)
            }
        }, { e ->
            if (g == gen && !closing) fail(e.message ?: "Video unavailable")
        })
        Net.async({ YT.related(v.id) }, { r ->
            if (g == gen) related = r
        }, { })
    }

    private fun play(s: Stream, startMs: Long) {
        val p = player ?: return
        val http = ChunkedDataSource.factory(YT.http, s.ua)
        val pf = ProgressiveMediaSource.Factory(http)
        val src: MediaSource
        val v = if (mode == 0) s.pickVideo(Store.quality(this)) else null
        if (v != null && s.audio != null) {
            src = MergingMediaSource(
                pf.createMediaSource(MediaItem.fromUri(v.url)),
                pf.createMediaSource(MediaItem.fromUri(s.audio.url))
            )
            curHeight = v.height
        } else if (s.muxed != null) {
            src = pf.createMediaSource(MediaItem.fromUri(s.muxed.url))
            curHeight = s.muxed.height
        } else {
            fail("No playable stream")
            return
        }
        p.setMediaSource(src, startMs)
        p.prepare()
        p.playWhenReady = true
    }

    private fun onPlaybackFailed(e: PlaybackException) {
        val v = cur ?: return
        val p = player ?: return
        val pos = p.currentPosition
        val s = stream
        if (mode == 0 && s?.muxed != null) {
            // 1) try the single-file version (safer on old TVs)
            mode = 1
            toast("Switching to safe quality (${e.errorCodeName} ${e.cause?.message ?: ""})")
            play(s, pos)
            return
        }
        if (retries < 2) {
            // 2) ask YouTube again, starting with the other client
            retries++
            mode = 0
            val g = ++gen
            spinner.visibility = View.VISIBLE
            val first = retries
            Net.async({ YT.resolve(v.id, first) }, { ns ->
                if (g == gen && !closing) {
                    stream = ns
                    play(ns, pos)
                }
            }, { ex ->
                if (g == gen && !closing) fail(ex.message ?: "Playback failed")
            })
            return
        }
        fail("Playback failed: ${e.errorCodeName} ${e.cause?.message ?: ""}")
    }

    private fun fail(msg: String) {
        spinner.visibility = View.GONE
        toast(msg)
        handler.postDelayed({ if (!closing) finish() }, 2500)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun playNextAuto() {
        val next = related.firstOrNull { it.id !in played }
        if (next == null) {
            finish()
        } else {
            startVideo(next)
        }
    }

    // ------------------------------------------------------------------ UI

    private fun refreshPauseIcon() {
        val p = player ?: return
        val paused = !p.playWhenReady && p.playbackState == Player.STATE_READY
        pauseIcon.visibility = if (paused) View.VISIBLE else View.GONE
    }

    private fun showBars() {
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        barHideAt = System.currentTimeMillis() + BAR_MS
    }

    private fun updateUi() {
        val p = player ?: return
        val pos = if (pendingSeekMs >= 0) pendingSeekMs else p.currentPosition
        val dur = p.duration
        if (dur != C.TIME_UNSET && dur > 0) {
            seekBar.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
            timeDur.text = fmt(dur) + (if (curHeight > 0) "   ${curHeight}p" else "")
        }
        timeCur.text = fmt(pos)
        val paused = !p.playWhenReady
        if (!paused && System.currentTimeMillis() > barHideAt && topBar.visibility == View.VISIBLE) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    private fun nudge(dir: Int, repeat: Int) {
        val p = player ?: return
        val step = (if (repeat > 6) 30_000L else 10_000L) * dir
        val base = if (pendingSeekMs >= 0) pendingSeekMs else p.currentPosition
        var t = base + step
        val d = p.duration
        t = if (d != C.TIME_UNSET && d > 0) t.coerceIn(0L, maxOf(0L, d - 1000)) else maxOf(0L, t)
        pendingSeekMs = t
        seekText.text = (if (dir > 0) "▶▶ " else "◀◀ ") + fmt(t)
        seekText.visibility = View.VISIBLE
        showBars()
        handler.removeCallbacks(applySeek)
        handler.postDelayed(applySeek, 350)
    }

    private fun togglePause() {
        val p = player ?: return
        p.playWhenReady = !p.playWhenReady
        showBars()
        refreshPauseIcon()
    }

    private fun qualityDialog() {
        val s = stream ?: return
        val hs = s.heights()
        if (hs.isEmpty()) return
        val labels = hs.map { "${it}p" + (if (it == curHeight) "   ✓" else "") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Quality")
            .setItems(labels) { _, i ->
                Store.setQuality(this, hs[i])
                val pos = player?.currentPosition ?: 0L
                mode = 0
                play(s, pos)
            }
            .show()
    }

    private fun upNextDialog() {
        val list = related.take(20)
        if (list.isEmpty()) {
            toast("Loading suggestions...")
            return
        }
        val labels = list.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Up next")
            .setItems(labels) { _, i -> startVideo(list[i]) }
            .show()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (event.repeatCount == 0) togglePause()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { player?.playWhenReady = true; showBars(); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { player?.playWhenReady = false; showBars(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { nudge(-1, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { nudge(1, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MENU -> {
                    if (event.repeatCount == 0) qualityDialog()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (event.repeatCount == 0) upNextDialog()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> { playNextAuto(); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        closing = true
        gen++
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
