package com.yttv.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Vid(
    val id: String,
    val title: String,
    val channel: String = "",
    val meta: String = "",
    val dur: String = ""
) {
    val thumb: String get() = "https://i.ytimg.com/vi/$id/mqdefault.jpg"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("channel", channel).put("meta", meta).put("dur", dur)

    companion object {
        fun fromJson(o: JSONObject) = Vid(
            o.optString("id"), o.optString("title"), o.optString("channel"),
            o.optString("meta"), o.optString("dur")
        )
    }
}

/** Small local storage: chosen quality + watch history (no login needed). */
object Store {
    private const val P = "yttv"

    fun quality(c: Context): Int = c.getSharedPreferences(P, 0).getInt("quality", 720)

    fun setQuality(c: Context, h: Int) {
        c.getSharedPreferences(P, 0).edit().putInt("quality", h).apply()
    }

    fun history(c: Context): List<Vid> {
        val out = ArrayList<Vid>()
        try {
            val a = JSONArray(c.getSharedPreferences(P, 0).getString("hist", "[]"))
            for (i in 0 until a.length()) out.add(Vid.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    fun addHistory(c: Context, v: Vid) {
        val list = ArrayList<Vid>(history(c))
        list.removeAll { it.id == v.id }
        list.add(0, v)
        val a = JSONArray()
        for (i in 0 until minOf(list.size, 80)) a.put(list[i].toJson())
        c.getSharedPreferences(P, 0).edit().putString("hist", a.toString()).apply()
    }

    fun clearHistory(c: Context) {
        c.getSharedPreferences(P, 0).edit().remove("hist").apply()
    }
}
