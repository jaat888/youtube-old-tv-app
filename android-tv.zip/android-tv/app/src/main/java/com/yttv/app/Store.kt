package com.yttv.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Vid(
    val id: String,
    val title: String,
    val channel: String = "",
    val meta: String = "",
    val dur: String = "",
    val channelId: String = "",
    val cthumb: String = ""
) {
    val thumb: String get() = "https://i.ytimg.com/vi/$id/mqdefault.jpg"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("channel", channel).put("meta", meta)
        .put("dur", dur).put("cid", channelId).put("cthumb", cthumb)

    companion object {
        fun fromJson(o: JSONObject) = Vid(
            o.optString("id"), o.optString("title"), o.optString("channel"),
            o.optString("meta"), o.optString("dur"), o.optString("cid"), o.optString("cthumb")
        )
    }
}

/** A YouTube channel (search result card, or a saved subscription). */
data class Chan(
    val id: String,
    val name: String,
    val thumb: String = "",
    val subs: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("thumb", thumb).put("subs", subs)

    companion object {
        fun fromJson(o: JSONObject) = Chan(
            o.optString("id"), o.optString("name"), o.optString("thumb"), o.optString("subs")
        )
    }
}

/** "3 days ago" / "Streamed 5 hours ago" -> minutes (small = fresh). Unknown = very old. */
fun ageMinutes(meta: String): Long {
    val m = Regex("(\\d+)\\s+(second|minute|hour|day|week|month|year)s?\\s+ago").find(meta)
        ?: return Long.MAX_VALUE / 2
    val n = m.groupValues[1].toLongOrNull() ?: return Long.MAX_VALUE / 2
    val mult = when (m.groupValues[2]) {
        "second" -> 0L
        "minute" -> 1L
        "hour" -> 60L
        "day" -> 1440L
        "week" -> 10080L
        "month" -> 43200L
        else -> 525600L
    }
    return n * mult
}

/** Small local storage: quality, watch history, subscriptions, recent searches (no login needed). */
object Store {
    private const val P = "yttv"

    private fun prefs(c: Context) = c.getSharedPreferences(P, 0)

    fun quality(c: Context): Int = prefs(c).getInt("quality", 720)

    fun setQuality(c: Context, h: Int) {
        prefs(c).edit().putInt("quality", h).apply()
    }

    fun fill(c: Context): Boolean = prefs(c).getBoolean("fill", false)

    fun setFill(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("fill", on).apply()
    }

    fun autoplay(c: Context): Boolean = prefs(c).getBoolean("autoplay", true)

    fun setAutoplay(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("autoplay", on).apply()
    }

    // ---------------------------------------------------------------- history

    fun history(c: Context): List<Vid> {
        val out = ArrayList<Vid>()
        try {
            val a = JSONArray(prefs(c).getString("hist", "[]"))
            for (i in 0 until a.length()) out.add(Vid.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    fun addHistory(c: Context, v: Vid) {
        val list = ArrayList<Vid>(history(c))
        list.removeAll { it.id == v.id }
        list.add(0, v)
        val a = JSONArray()
        for (i in 0 until minOf(list.size, 80)) a.put(list[i].toJson())
        prefs(c).edit().putString("hist", a.toString()).apply()
    }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove("hist").apply()
    }

    // ---------------------------------------------------------------- subscriptions

    fun subs(c: Context): List<Chan> {
        val out = ArrayList<Chan>()
        try {
            val a = JSONArray(prefs(c).getString("subs", "[]"))
            for (i in 0 until a.length()) out.add(Chan.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveSubs(c: Context, list: List<Chan>) {
        val a = JSONArray()
        for (ch in list) a.put(ch.toJson())
        prefs(c).edit().putString("subs", a.toString()).apply()
    }

    fun isSub(c: Context, id: String): Boolean = id.isNotEmpty() && subs(c).any { it.id == id }

    /** Subscribe / unsubscribe. Returns true if the channel is subscribed afterwards. */
    fun toggleSub(c: Context, ch: Chan): Boolean {
        if (ch.id.isEmpty()) return false
        val list = ArrayList<Chan>(subs(c))
        return if (list.any { it.id == ch.id }) {
            list.removeAll { it.id == ch.id }
            saveSubs(c, list)
            false
        } else {
            list.add(0, ch)
            saveSubs(c, list)
            true
        }
    }

    /** Refresh name / photo of a channel that is already subscribed (keeps its place). */
    fun refreshSub(c: Context, ch: Chan) {
        val list = ArrayList<Chan>(subs(c))
        val i = list.indexOfFirst { it.id == ch.id }
        if (i < 0) return
        val old = list[i]
        list[i] = Chan(
            ch.id,
            ch.name.ifEmpty { old.name },
            ch.thumb.ifEmpty { old.thumb },
            ch.subs.ifEmpty { old.subs }
        )
        saveSubs(c, list)
    }

    // ---------------------------------------------------------------- recent searches

    fun recents(c: Context): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(prefs(c).getString("recent", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun addRecent(c: Context, q: String) {
        val list = ArrayList<String>(recents(c))
        list.removeAll { it.equals(q, ignoreCase = true) }
        list.add(0, q)
        val a = JSONArray()
        for (i in 0 until minOf(list.size, 10)) a.put(list[i])
        prefs(c).edit().putString("recent", a.toString()).apply()
    }
}
