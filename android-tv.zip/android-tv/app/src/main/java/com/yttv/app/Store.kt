package com.yttv.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Vid(
    val id: String,
    val title: String,
    val channel: String = "",
    val meta: String = "",
    val dur: String = "",
    val channelId: String = "",
    val cthumb: String = "",
    val pct: Int = 0            // % already watched (from the YouTube account), 0 = unknown
) {
    val thumb: String get() = "https://i.ytimg.com/vi/$id/mqdefault.jpg"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("channel", channel).put("meta", meta)
        .put("dur", dur).put("cid", channelId).put("cthumb", cthumb).put("pct", pct)

    companion object {
        fun fromJson(o: JSONObject) = Vid(
            o.optString("id"), o.optString("title"), o.optString("channel"),
            o.optString("meta"), o.optString("dur"), o.optString("cid"), o.optString("cthumb"), o.optInt("pct")
        )
    }
}

/** A YouTube channel (search result card, or a saved subscription). */
data class Chan(
    val id: String,
    val name: String,
    val thumb: String = "",
    val subs: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("thumb", thumb).put("subs", subs)

    companion object {
        fun fromJson(o: JSONObject) = Chan(
            o.optString("id"), o.optString("name"), o.optString("thumb"), o.optString("subs")
        )
    }
}

/** A YouTube playlist (card in search results / channel Playlists tab). */
data class Plist(
    val id: String,
    val title: String,
    val count: String = "",
    val thumb: String = "",
    val channel: String = ""
)

/** "3 days ago" / "Streamed 5 hours ago" -> minutes (small = fresh). Unknown = very old. */
fun ageMinutes(meta: String): Long {
    val m = Regex("(\\d+)\\s+(second|minute|hour|day|week|month|year)s?\\s+ago").find(meta)
        ?: return Long.MAX_VALUE / 2
    val n = m.groupValues[1].toLongOrNull() ?: return Long.MAX_VALUE / 2
    val mult = when (m.groupValues[2]) {
        "second" -> 0L
        "minute" -> 1L
        "hour" -> 60L
        "day" -> 1440L
        "week" -> 10080L
        "month" -> 43200L
        else -> 525600L
    }
    return n * mult
}

/** Small local storage: quality, watch history, subscriptions, recent searches (no login needed). */
object Store {
    private const val P = "yttv"

    private fun prefs(c: Context) = c.getSharedPreferences(P, 0)

    fun quality(c: Context): Int = prefs(c).getInt("quality", 720)

    fun setQuality(c: Context, h: Int) {
        prefs(c).edit().putInt("quality", h).apply()
    }

    fun volume(c: Context): Float = prefs(c).getFloat("volume", 1f)

    fun setVolume(c: Context, v: Float) {
        prefs(c).edit().putFloat("volume", v).apply()
    }

    fun speed(c: Context): Float = prefs(c).getFloat("speed", 1f)

    fun setSpeed(c: Context, v: Float) {
        prefs(c).edit().putFloat("speed", v).apply()
    }

    fun fill(c: Context): Boolean = prefs(c).getBoolean("fill", false)

    fun setFill(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("fill", on).apply()
    }

    fun authRefresh(c: Context): String = prefs(c).getString("auth_refresh", "") ?: ""

    fun setAuthRefresh(c: Context, t: String) {
        prefs(c).edit().putString("auth_refresh", t).apply()
    }

    fun autoplay(c: Context): Boolean = prefs(c).getBoolean("autoplay", true)

    fun setAutoplay(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("autoplay", on).apply()
    }

    // ---------------------------------------------------------------- history

    fun history(c: Context): List<Vid> {
        val out = ArrayList<Vid>()
        try {
            val a = JSONArray(prefs(c).getString("hist", "[]"))
            for (i in 0 until a.length()) out.add(Vid.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    // ---------------------------------------------------------------- watch progress (per video, kept on the TV)

    private var progCache: JSONObject? = null

    private fun progAll(c: Context): JSONObject {
        var o = progCache
        if (o == null) {
            o = try { JSONObject(prefs(c).getString("prog", "{}")) } catch (e: Exception) { JSONObject() }
            progCache = o
        }
        return o!!
    }

    /** Remember how far this video got: [posMs] of [durMs]. */
    fun setProgress(c: Context, id: String, posMs: Long, durMs: Long) {
        if (id.isEmpty() || durMs <= 0L) return
        val o = progAll(c)
        o.put(id, JSONArray().put(posMs).put(durMs).put(System.currentTimeMillis()))
        if (o.length() > 400) {
            // keep the 300 newest
            val l = ArrayList<Pair<String, Long>>()
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                l.add(Pair(k, o.optJSONArray(k)?.optLong(2) ?: 0L))
            }
            l.sortBy { it.second }
            for (i in 0 until l.size - 300) o.remove(l[i].first)
        }
        prefs(c).edit().putString("prog", o.toString()).apply()
    }

    /** (position, length) in ms, or null if never watched on this TV. */
    fun progress(c: Context, id: String): Pair<Long, Long>? {
        val a = progAll(c).optJSONArray(id) ?: return null
        val d = a.optLong(1)
        return if (d > 0L) Pair(a.optLong(0), d) else null
    }

    /** 0..100 */
    fun percent(c: Context, id: String): Int {
        val p = progress(c, id) ?: return 0
        return (p.first * 100 / p.second).toInt().coerceIn(0, 100)
    }

    fun addHistory(c: Context, v: Vid) {
        val list = ArrayList<Vid>(history(c))
        list.removeAll { it.id == v.id }
        list.add(0, v)
        val a = JSONArray()
        for (i in 0 until minOf(list.size, 80)) a.put(list[i].toJson())
        prefs(c).edit().putString("hist", a.toString()).apply()
    }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove("hist").apply()
    }

    // ---------------------------------------------------------------- subscriptions

    fun subs(c: Context): List<Chan> {
        val out = ArrayList<Chan>()
        try {
            val a = JSONArray(prefs(c).getString("subs", "[]"))
            for (i in 0 until a.length()) out.add(Chan.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveSubs(c: Context, list: List<Chan>) {
        val a = JSONArray()
        for (ch in list) a.put(ch.toJson())
        prefs(c).edit().putString("subs", a.toString()).apply()
    }

    // ---- channels of the signed-in account (cached, refreshed from YouTube in the background)

    fun accountChans(c: Context): List<Chan> {
        val out = ArrayList<Chan>()
        try {
            val a = JSONArray(prefs(c).getString("acc_chans", "[]"))
            for (i in 0 until a.length()) out.add(Chan.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }

    fun accountChansAge(c: Context): Long =
        System.currentTimeMillis() - prefs(c).getLong("acc_chans_at", 0L)

    fun setAccountChans(c: Context, list: List<Chan>) {
        val a = JSONArray()
        for (ch in list) a.put(ch.toJson())
        prefs(c).edit().putString("acc_chans", a.toString()).putLong("acc_chans_at", System.currentTimeMillis()).apply()
    }

    // ---- channel photos found for feed cards that came without one (kept between app starts)

    fun photoCache(c: Context): String = prefs(c).getString("cphotos", "{}") ?: "{}"

    fun putPhoto(c: Context, id: String, url: String) {
        try {
            val o = JSONObject(photoCache(c))
            if (o.length() > 800) {
                val ks = ArrayList<String>()
                val it = o.keys()
                while (it.hasNext()) ks.add(it.next())
                for (k in ks.take(200)) o.remove(k)
            }
            o.put(id, url)
            prefs(c).edit().putString("cphotos", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun clearAccount(c: Context) {
        prefs(c).edit().remove("acc_chans").remove("acc_chans_at").apply()
    }

    /** Signed in: the account's channels are the truth. Signed out: the list saved on this TV. */
    fun isSub(c: Context, id: String): Boolean {
        if (id.isEmpty()) return false
        if (subs(c).any { it.id == id }) return true
        return Auth.signedIn(c) && accountChans(c).any { it.id == id }
    }

    /** Subscribe / unsubscribe. Returns true if the channel is subscribed afterwards. */
    fun toggleSub(c: Context, ch: Chan): Boolean {
        if (ch.id.isEmpty()) return false
        val was = isSub(c, ch.id)
        val list = ArrayList<Chan>(subs(c))
        list.removeAll { it.id == ch.id }
        val signed = Auth.signedIn(c)
        val acc = ArrayList<Chan>(if (signed) accountChans(c) else emptyList())
        acc.removeAll { it.id == ch.id }
        return if (was) {
            saveSubs(c, list)
            if (signed) setAccountChans(c, acc)
            syncRemote(c, ch.id, false)
            false
        } else {
            list.add(0, ch)
            saveSubs(c, list)
            if (signed) {
                acc.add(0, ch)
                setAccountChans(c, acc)
            }
            syncRemote(c, ch.id, true)
            true
        }
    }

    /** Signed in: also (un)subscribe on the real YouTube account (best effort, errors ignored). */
    private fun syncRemote(c: Context, id: String, on: Boolean) {
        if (!Auth.signedIn(c)) return
        val app = c.applicationContext
        Net.async({ YT.subscribeRemote(app, id, on) }, { }, { })
    }

    /** Refresh name / photo of a channel that is already subscribed (keeps its place). */
    fun refreshSub(c: Context, ch: Chan) {
        val list = ArrayList<Chan>(subs(c))
        val i = list.indexOfFirst { it.id == ch.id }
        if (i < 0) return
        val old = list[i]
        list[i] = Chan(
            ch.id,
            ch.name.ifEmpty { old.name },
            ch.thumb.ifEmpty { old.thumb },
            ch.subs.ifEmpty { old.subs }
        )
        saveSubs(c, list)
    }

    // ---------------------------------------------------------------- recent searches

    fun recents(c: Context): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(prefs(c).getString("recent", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun addRecent(c: Context, q: String) {
        val list = ArrayList<String>(recents(c))
        list.removeAll { it.equals(q, ignoreCase = true) }
        list.add(0, q)
        val a = JSONArray()
        for (i in 0 until minOf(list.size, 10)) a.put(list[i])
        prefs(c).edit().putString("recent", a.toString()).apply()
    }
}
