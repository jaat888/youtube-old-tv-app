package com.yttv.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Channel page: photo, name, subscribers, Subscribe button, and the channel's videos (newest first).
 * Subscriptions are saved on the TV only (no login).
 */
class ChannelActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ID = "cid"
        const val EXTRA_NAME = "cname"
    }

    private val items = ArrayList<Any>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: FeedAdapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private lateinit var nameT: TextView
    private lateinit var subsT: TextView
    private lateinit var letter: TextView
    private lateinit var photo: android.widget.ImageView
    private lateinit var subBtn: TextView

    private var chan = Chan("", "")
    private var token: String? = null
    private var loading = false
    private var exhausted = false
    private var firstDone = false
    private var closing = false
    private var cardW = 0
    private var spans = 4

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        val id = intent.getStringExtra(EXTRA_ID) ?: ""
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""
        if (id.isEmpty()) {
            finish()
            return
        }
        chan = Chan(id, name)
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi()
        showHeader()
        subBtn.requestFocus()
        loadMore()
    }

    override fun onDestroy() {
        closing = true
        super.onDestroy()
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        spans = if (widthDp >= 1000) 4 else 3
        val pad = dp(24)
        cardW = (dm.widthPixels - (pad - dp(5)) * 2) / spans - dp(10)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(resources.getColor(R.color.bg))

        // ---- header: photo + name/subscribers + Subscribe
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(pad, dp(18), pad, dp(10))

        val size = dp(84)
        val av = UiUtil.avatarView(this, size, 34f)
        letter = av.second
        photo = av.third
        head.addView(av.first, LinearLayout.LayoutParams(size, size))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        nameT = TextView(this)
        nameT.setTextColor(Color.WHITE)
        nameT.textSize = 26f
        nameT.setTypeface(null, Typeface.BOLD)
        nameT.maxLines = 1
        nameT.ellipsize = TextUtils.TruncateAt.END
        col.addView(nameT)
        subsT = TextView(this)
        subsT.setTextColor(Color.parseColor("#AAAAAA"))
        subsT.textSize = 15f
        subsT.maxLines = 1
        col.addView(subsT)
        val clp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        clp.leftMargin = dp(18)
        head.addView(col, clp)

        subBtn = TextView(this)
        subBtn.textSize = 18f
        subBtn.setTypeface(null, Typeface.BOLD)
        subBtn.setPadding(dp(30), dp(10), dp(30), dp(10))
        subBtn.setBackgroundResource(R.drawable.chip_bg)
        subBtn.isFocusable = true
        subBtn.isClickable = true
        subBtn.setOnClickListener { toggleSub() }
        head.addView(subBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- videos
        val right = FrameLayout(this)
        grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, spans)
        grid.setPadding(pad - dp(5), dp(4), pad - dp(5), pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        adapter = FeedAdapter(
            this, items, cardW, spans * 2,
            { v -> open(v) },
            { v -> open(v) },
            { },
            { loadMore() }
        )
        grid.adapter = adapter
        right.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.chip_bg)
        message.visibility = View.GONE
        message.setOnClickListener { retry() }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        root.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showHeader() {
        nameT.text = chan.name
        subsT.text = chan.subs
        subsT.visibility = if (chan.subs.isEmpty()) View.GONE else View.VISIBLE
        UiUtil.letterAvatar(letter, chan.name)
        Img.load(photo, chan.thumb, dp(84))
        showSubState()
    }

    private fun showSubState() {
        val on = Store.isSub(this, chan.id)
        subBtn.text = if (on) "Subscribed" else "Subscribe"
        subBtn.isSelected = on
        subBtn.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun toggleSub() {
        val now = Store.toggleSub(this, chan)
        showSubState()
        Toast.makeText(
            this,
            if (now) "Subscribed: ${chan.name}" else "Unsubscribed: ${chan.name}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun retry() {
        message.visibility = View.GONE
        loadMore()
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val tok = token
        val id = chan.id
        val nm = chan.name
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({ YT.channel(id, tok, nm) }, { cp ->
            if (!closing) {
                loading = false
                spinner.visibility = View.GONE
                val info = cp.info
                if (info != null && !firstDone) {
                    chan = Chan(
                        chan.id,
                        info.name.ifEmpty { chan.name },
                        info.thumb.ifEmpty { chan.thumb },
                        info.subs.ifEmpty { chan.subs }
                    )
                    showHeader()
                    // keep the saved copy fresh (name / photo) if already subscribed
                    Store.refreshSub(this, chan)
                }
                firstDone = true
                token = cp.page.token
                exhausted = cp.page.token == null
                val start = items.size
                for (x in cp.page.mixed) if (x is Vid && seen.add(x.id)) items.add(x)
                if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                if (items.isEmpty()) {
                    if (exhausted) showMsg("No videos found", false) else loadMore()
                }
            }
        }, { e ->
            if (!closing) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMsg("Could not load channel\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private fun showMsg(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    private fun open(v: Vid) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        startActivity(i)
    }
}
