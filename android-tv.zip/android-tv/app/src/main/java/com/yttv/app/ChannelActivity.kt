package com.yttv.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Channel page: photo, name, subscribers, Subscribe button, and the channel's videos (newest first).
 * Subscriptions are saved on the TV only (no login).
 */
class ChannelActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ID = "cid"
        const val EXTRA_NAME = "cname"
    }

    private val items = ArrayList<Any>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: FeedAdapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private lateinit var nameT: TextView
    private lateinit var subsT: TextView
    private lateinit var letter: TextView
    private lateinit var photo: android.widget.ImageView
    private lateinit var subBtn: TextView

    private var chan = Chan("", "")
    private var token: String? = null
    private var loading = false
    private var exhausted = false
    private var firstDone = false
    private var closing = false
    private var gen = 0
    private var tabPlaylists = false
    private lateinit var tabVideosBtn: TextView
    private lateinit var tabPlBtn: TextView
    private var cardW = 0
    private var spans = 4

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        val id = intent.getStringExtra(EXTRA_ID) ?: ""
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""
        if (id.isEmpty()) {
            finish()
            return
        }
        chan = Chan(id, name)
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi()
        UiUtil.immersive(window)
        showHeader()
        subBtn.requestFocus()
        loadMore()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    override fun onDestroy() {
        closing = true
        super.onDestroy()
    }

    /** Remote buttons: PLAY opens the video, MENU (re)subscribes, PAGE / CHANNEL keys scroll. */
    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        if (ev.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            val inGrid = f != null && UiUtil.isInside(f, grid)
            when (ev.keyCode) {
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> {
                    if (ev.repeatCount == 0) toggleSub()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> if (inGrid) {
                    if (ev.repeatCount == 0) {
                        val it = items.getOrNull(UiUtil.focusedPos(grid))
                        if (it is Vid) open(it) else if (it is Plist) openPlist(it)
                    }
                    return true
                }
                KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN ->
                    if (inGrid && UiUtil.page(grid, spans, true)) return true
                KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP ->
                    if (inGrid && UiUtil.page(grid, spans, false)) return true
            }
        }
        return super.dispatchKeyEvent(ev)
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        spans = if (widthDp >= 1000) 4 else 3
        val pad = dp(24)
        cardW = (dm.widthPixels - (pad - dp(5)) * 2 - dp(20)) / spans - dp(10)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(resources.getColor(R.color.bg))

        // ---- header: photo + name/subscribers + Subscribe
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(pad + dp(20), dp(18), pad, dp(10))

        val size = dp(84)
        val av = UiUtil.avatarView(this, size, 34f)
        letter = av.second
        photo = av.third
        head.addView(av.first, LinearLayout.LayoutParams(size, size))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        nameT = TextView(this)
        nameT.setTextColor(Color.WHITE)
        nameT.textSize = 26f
        nameT.setTypeface(null, Typeface.BOLD)
        nameT.maxLines = 1
        nameT.ellipsize = TextUtils.TruncateAt.END
        col.addView(nameT)
        subsT = TextView(this)
        subsT.setTextColor(Color.parseColor("#AAAAAA"))
        subsT.textSize = 15f
        subsT.maxLines = 1
        col.addView(subsT)
        val clp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        clp.leftMargin = dp(18)
        head.addView(col, clp)

        subBtn = TextView(this)
        subBtn.textSize = 18f
        subBtn.setTypeface(null, Typeface.BOLD)
        subBtn.setPadding(dp(30), dp(10), dp(30), dp(10))
        subBtn.setBackgroundResource(R.drawable.chip_bg)
        subBtn.isFocusable = true
        subBtn.isClickable = true
        subBtn.setOnClickListener { toggleSub() }
        head.addView(subBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- tabs: Videos | Playlists
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(pad + dp(20), 0, pad, dp(6))
        tabVideosBtn = mkTab("Videos") { switchTab(false) }
        tabPlBtn = mkTab("Playlists") { switchTab(true) }
        tabs.addView(tabVideosBtn)
        tabs.addView(tabPlBtn)
        root.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        markTabs()

        // ---- videos
        val right = FrameLayout(this)
        grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, spans)
        grid.setPadding(pad + dp(15), dp(4), pad - dp(5), pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        adapter = FeedAdapter(
            this, items, cardW, spans * 2,
            { v -> open(v) },
            { v -> open(v) },
            { },
            { loadMore() },
            { p -> openPlist(p) }
        )
        grid.adapter = adapter
        right.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.chip_bg)
        message.visibility = View.GONE
        message.setOnClickListener { retry() }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        root.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun mkTab(text: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 16f
        t.setPadding(dp(22), dp(7), dp(22), dp(7))
        t.setBackgroundResource(R.drawable.chip_bg)
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(10)
        t.layoutParams = lp
        return t
    }

    private fun markTabs() {
        tabVideosBtn.isSelected = !tabPlaylists
        tabVideosBtn.setTextColor(if (!tabPlaylists) Color.BLACK else Color.WHITE)
        tabPlBtn.isSelected = tabPlaylists
        tabPlBtn.setTextColor(if (tabPlaylists) Color.BLACK else Color.WHITE)
    }

    private fun switchTab(pl: Boolean) {
        if (pl == tabPlaylists) return
        tabPlaylists = pl
        markTabs()
        gen++
        items.clear()
        seen.clear()
        adapter.notifyDataSetChanged()
        token = null
        exhausted = false
        loading = false
        message.visibility = View.GONE
        loadMore()
    }

    private fun openPlist(p: Plist) {
        val i = Intent(this, PlaylistActivity::class.java)
        i.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        i.putExtra(PlaylistActivity.EXTRA_TITLE, p.title)
        startActivity(i)
    }

    private fun showHeader() {
        nameT.text = chan.name
        subsT.text = chan.subs
        subsT.visibility = if (chan.subs.isEmpty()) View.GONE else View.VISIBLE
        UiUtil.letterAvatar(letter, chan.name)
        Img.load(photo, chan.thumb, dp(84))
        showSubState()
    }

    private fun showSubState() {
        val on = Store.isSub(this, chan.id)
        subBtn.text = if (on) "Subscribed" else "Subscribe"
        subBtn.isSelected = on
        subBtn.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun toggleSub() {
        val now = Store.toggleSub(this, chan)
        showSubState()
        Toast.makeText(
            this,
            if (now) "Subscribed: ${chan.name}" else "Unsubscribed: ${chan.name}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun retry() {
        message.visibility = View.GONE
        loadMore()
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val tok = token
        val id = chan.id
        val nm = chan.name
        val g = gen
        val pl = tabPlaylists
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({ YT.channel(id, tok, nm, pl) }, { cp ->
            if (!closing && g == gen) {
                loading = false
                spinner.visibility = View.GONE
                val info = cp.info
                if (info != null && !firstDone) {
                    chan = Chan(
                        chan.id,
                        info.name.ifEmpty { chan.name },
                        info.thumb.ifEmpty { chan.thumb },
                        info.subs.ifEmpty { chan.subs }
                    )
                    showHeader()
                    // keep the saved copy fresh (name / photo) if already subscribed
                    Store.refreshSub(this, chan)
                }
                firstDone = true
                token = cp.page.token
                exhausted = cp.page.token == null
                val start = items.size
                for (x in cp.page.mixed) {
                    if (x is Vid && seen.add(x.id)) items.add(x)
                    else if (x is Plist && seen.add("p:" + x.id)) items.add(x)
                }
                if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                if (items.isEmpty()) {
                    if (exhausted) showMsg(if (pl) "No playlists" else "No videos found", false) else loadMore()
                }
            }
        }, { e ->
            if (!closing && g == gen) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMsg("Could not load channel\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private fun showMsg(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    private fun open(v: Vid) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        // the channel's loaded videos become the queue: Next / Previous and the More panel use them
        val vids = items.filterIsInstance<Vid>()
        if (vids.size > 1 && vids.any { it.id == v.id }) {
            val q = org.json.JSONArray()
            for (x in vids.take(150)) q.put(x.toJson())
            i.putExtra(PlayerActivity.EXTRA_QUEUE, q.toString())
            i.putExtra(PlayerActivity.EXTRA_QUEUE_TITLE, chan.name.ifEmpty { "Channel" } + " videos")
        }
        startActivity(i)
    }
}
