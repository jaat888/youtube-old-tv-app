package com.yttv.app

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InputStream

/**
 * Reads a googlevideo file in small pieces (?range=a-b), like yt-dlp does.
 * YouTube cuts or throttles one long open-ended download after a short while
 * (video stops after ~10 s); many small range requests keep it going.
 */
@UnstableApi
class ChunkedDataSource(
    private val client: OkHttpClient,
    private val ua: String
) : BaseDataSource(true) {

    companion object {
        private const val CHUNK = 2L * 1024 * 1024

        fun factory(client: OkHttpClient, ua: String): DataSource.Factory =
            DataSource.Factory { ChunkedDataSource(client, ua) }
    }

    private var uri: Uri? = null
    private var pos = 0L
    private var endPos = Long.MAX_VALUE   // exclusive
    private var chunkLeft = 0L
    private var chunkAsked = 0L
    private var resp: Response? = null
    private var stream: InputStream? = null
    private var opened = false
    private var finished = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        pos = dataSpec.position
        val clen = dataSpec.uri.getQueryParameter("clen")?.toLongOrNull() ?: -1L
        endPos = if (dataSpec.length != C.LENGTH_UNSET.toLong()) pos + dataSpec.length
        else if (clen > 0) clen else Long.MAX_VALUE
        finished = false
        openChunk()
        opened = true
        transferStarted(dataSpec)
        return if (endPos == Long.MAX_VALUE) C.LENGTH_UNSET.toLong() else endPos - pos
    }

    private fun openChunk() {
        closeChunk()
        val from = pos
        val to = minOf(from + CHUNK - 1, if (endPos == Long.MAX_VALUE) Long.MAX_VALUE else endPos - 1)
        val base = uri.toString()
        val url = base + (if (base.contains("?")) "&" else "?") + "range=$from-$to"
        val req = Request.Builder().url(url).header("User-Agent", ua).build()
        val r = client.newCall(req).execute()
        if (r.code != 200 && r.code != 206) {
            val c = r.code
            r.close()
            throw IOException("googlevideo HTTP $c")
        }
        resp = r
        stream = r.body?.byteStream() ?: throw IOException("empty body")
        chunkAsked = to - from + 1
        chunkLeft = chunkAsked
    }

    private fun closeChunk() {
        try { stream?.close() } catch (e: Exception) { }
        try { resp?.close() } catch (e: Exception) { }
        stream = null
        resp = null
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        while (true) {
            if (finished || pos >= endPos) return C.RESULT_END_OF_INPUT
            val s = stream ?: return C.RESULT_END_OF_INPUT
            val want = if (chunkLeft < length) chunkLeft.toInt() else length
            val n = if (want > 0) s.read(buffer, offset, want) else -1
            if (n > 0) {
                pos += n
                chunkLeft -= n
                bytesTransferred(n)
                return n
            }
            // this piece is finished (or the file ended early)
            if (chunkLeft > 0 && endPos == Long.MAX_VALUE) {
                finished = true
                return C.RESULT_END_OF_INPUT
            }
            if (pos >= endPos) return C.RESULT_END_OF_INPUT
            openChunk()
        }
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        closeChunk()
        if (opened) {
            opened = false
            transferEnded()
        }
    }
}
