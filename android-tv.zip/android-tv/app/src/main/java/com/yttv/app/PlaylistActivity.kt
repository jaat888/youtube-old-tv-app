package com.yttv.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray

/**
 * A playlist: Back + title + "Play all" on top, the videos below.
 * Opening a video plays it with the rest of the playlist queued (autoplay goes down the list).
 */
class PlaylistActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ID = "pid"
        const val EXTRA_TITLE = "ptitle"
    }

    private val items = ArrayList<Any>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: FeedAdapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView

    private var pid = ""
    private var token: String? = null
    private var loading = false
    private var exhausted = false
    private var closing = false
    private var cardW = 0
    private var spans = 4

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        pid = intent.getStringExtra(EXTRA_ID) ?: ""
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Playlist"
        if (pid.isEmpty()) {
            finish()
            return
        }
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi(title)
        UiUtil.immersive(window)
        loadMore()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    override fun onDestroy() {
        closing = true
        super.onDestroy()
    }

    private fun chip(text: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 18f
        t.setTextColor(Color.WHITE)
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(22), dp(10), dp(22), dp(10))
        t.setBackgroundResource(R.drawable.chip_bg)
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { click() }
        return t
    }

    private fun buildUi(title: String) {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        spans = if (widthDp >= 1000) 4 else 3
        val pad = dp(24)
        cardW = (dm.widthPixels - (pad - dp(5)) * 2 - dp(20)) / spans - dp(10)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(resources.getColor(R.color.bg))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(pad + dp(20), dp(18), pad, dp(10))

        val back = chip("\u2039 Back") { finish() }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.rightMargin = dp(18)
        head.addView(back, blp)

        val nameT = TextView(this)
        nameT.text = title
        nameT.setTextColor(Color.WHITE)
        nameT.textSize = 24f
        nameT.setTypeface(null, Typeface.BOLD)
        nameT.maxLines = 1
        nameT.ellipsize = TextUtils.TruncateAt.END
        head.addView(nameT, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val all = chip("\u25B6 Play all") { playFrom(0) }
        head.addView(all, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val right = FrameLayout(this)
        grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, spans)
        grid.setPadding(pad + dp(15), dp(4), pad - dp(5), pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        adapter = FeedAdapter(
            this, items, cardW, spans * 2,
            { v -> playFrom(items.indexOf(v)) },
            { v -> playFrom(items.indexOf(v)) },
            { },
            { loadMore() }
        )
        grid.adapter = adapter
        right.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.chip_bg)
        message.visibility = View.GONE
        message.setOnClickListener {
            message.visibility = View.GONE
            loadMore()
        }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        root.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val tok = token
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({ YT.playlist(pid, tok) }, { p ->
            if (!closing) {
                loading = false
                spinner.visibility = View.GONE
                token = p.token
                exhausted = p.token == null
                val start = items.size
                for (x in p.mixed) if (x is Vid && seen.add(x.id)) items.add(x)
                if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                if (items.isEmpty()) {
                    if (exhausted) showMsg("No videos found", false) else loadMore()
                }
            }
        }, { e ->
            if (!closing) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMsg("Could not load playlist\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private fun showMsg(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    /** Play item [index] and queue the whole loaded playlist behind it. */
    private fun playFrom(index: Int) {
        val vids = items.filterIsInstance<Vid>()
        if (vids.isEmpty()) return
        val v = vids[index.coerceIn(0, vids.size - 1)]
        val q = JSONArray()
        for (x in vids.take(150)) q.put(x.toJson())
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        i.putExtra(PlayerActivity.EXTRA_QUEUE, q.toString())
        startActivity(i)
    }
}
