package com.yttv.app

import android.app.Application
import android.content.Intent
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/** Debug helper: on any crash, show the error on the TV screen (no adb / developer options needed). */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Img.init(applicationContext)   // also when Android restores the player screen without the main screen
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val txt = "Thread: ${t.name}\nAndroid: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n" +
                    "Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n\n" + sw.toString()
                val i = Intent(this, CrashActivity::class.java)
                i.putExtra("trace", txt.take(7000))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(i)
                Thread.sleep(400)
            } catch (x: Throwable) {
            }
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(10)
        }
    }
}
