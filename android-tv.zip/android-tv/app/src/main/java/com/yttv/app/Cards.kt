package com.yttv.app

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Small helpers shared by the home screen and the channel page. */
object UiUtil {
    val avatarColors = intArrayOf(
        Color.parseColor("#E53935"), Color.parseColor("#8E24AA"), Color.parseColor("#3949AB"),
        Color.parseColor("#00897B"), Color.parseColor("#F4511E"), Color.parseColor("#039BE5"),
        Color.parseColor("#7CB342"), Color.parseColor("#6D4C41")
    )

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun isInside(v: View, ancestor: View): Boolean {
        var p: View? = v
        while (p != null) {
            if (p === ancestor) return true
            p = p.parent as? View
        }
        return false
    }

    /** Adapter position of the card that has focus, or -1. */
    fun focusedPos(grid: RecyclerView): Int {
        val f = grid.focusedChild ?: return -1
        return grid.getChildAdapterPosition(f)
    }

    /** Focus the card at [pos] (or the nearest focusable one next to it) once it is on screen. */
    fun focusCard(grid: RecyclerView, pos: Int, spans: Int) {
        grid.postDelayed({
            val order = ArrayList<Int>()
            for (d in 0..spans) order.add(pos + d)
            for (d in 1..spans) order.add(pos - d)
            for (p in order) {
                val v = grid.findViewHolderForAdapterPosition(p)?.itemView ?: continue
                if (v.isFocusable && v.requestFocus()) return@postDelayed
            }
        }, 70)
    }

    /** PAGE UP / PAGE DOWN / CHANNEL UP / DOWN: jump about a screen. Returns true if it handled the key. */
    fun page(grid: RecyclerView, spans: Int, down: Boolean): Boolean {
        val lm = grid.layoutManager as? GridLayoutManager ?: return false
        val count = grid.adapter?.itemCount ?: 0
        val pos = focusedPos(grid)
        if (pos < 0 || count == 0) return false
        val rows = ((lm.findLastVisibleItemPosition() - lm.findFirstVisibleItemPosition()) / spans).coerceAtLeast(1)
        val target = (if (down) pos + rows * spans else pos - rows * spans).coerceIn(0, count - 1)
        if (target == pos) return true
        lm.scrollToPositionWithOffset(target, 0)
        focusCard(grid, target, spans)
        return true
    }

    /** Coloured circle with the first letter (shown until / unless the real photo loads). */
    fun letterAvatar(tv: TextView, name: String) {
        val n = name.trim()
        tv.text = if (n.isEmpty()) "" else n.substring(0, 1).uppercase()
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(avatarColors[(n.hashCode() and 0x7fffffff) % avatarColors.size])
        tv.background = bg
    }

    /** Hide status + navigation bar (full screen). Call from onCreate and onWindowFocusChanged. */
    @Suppress("DEPRECATION")
    fun immersive(w: android.view.Window) {
        w.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    fun roundRect(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    /** Card grows while it has focus (Android TV style): smooth zoom, lifted above its neighbours. */
    fun focusZoom(v: View, scale: Float) {
        val grow = DecelerateInterpolator(1.6f)
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) scale else 1f
            view.animate().cancel()
            view.animate().scaleX(s).scaleY(s).translationZ(if (focused) 24f else 0f)
                .setDuration(if (focused) 200 else 150).setInterpolator(grow).start()
        }
    }

    fun roundClip(iv: ImageView) {
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        iv.clipToOutline = true
    }

    /** Round channel photo: letter underneath, photo on top once it has loaded. */
    fun avatarView(c: Context, size: Int, textSp: Float): Triple<FrameLayout, TextView, ImageView> {
        val fl = FrameLayout(c)
        val letter = TextView(c)
        letter.gravity = Gravity.CENTER
        letter.setTextColor(Color.WHITE)
        letter.textSize = textSp
        letter.setTypeface(null, Typeface.BOLD)
        fl.addView(letter, FrameLayout.LayoutParams(size, size))
        val img = ImageView(c)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(img)
        fl.addView(img, FrameLayout.LayoutParams(size, size))
        return Triple(fl, letter, img)
    }
}

/**
 * One adapter for every grid: items can be a Vid (video card), a Chan (channel card)
 * or a String (section heading that spans the full row).
 */
class FeedAdapter(
    private val ctx: Context,
    private val items: List<Any>,
    private val cardW: Int,
    private val nearEnd: Int,
    private val onVideo: (Vid) -> Unit,
    private val onVideoMenu: (Vid) -> Unit,
    private val onChan: (Chan) -> Unit,
    private val onNearEnd: () -> Unit,
    private val onPlist: (Plist) -> Unit = {},
    private val zoom: Float = 1.05f
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private class VH(
        view: View, val img: ImageView, val dur: TextView, val avatar: TextView, val avatarPhoto: ImageView,
        val title: TextView, val sub: TextView, val track: View, val bar: View
    ) : RecyclerView.ViewHolder(view) {
        var boundVid = ""
    }

    private class CVH(
        view: View, val letter: TextView, val photo: ImageView, val name: TextView, val subs: TextView
    ) : RecyclerView.ViewHolder(view)

    private class PVH(
        view: View, val img: ImageView, val badge: TextView, val title: TextView, val sub: TextView
    ) : RecyclerView.ViewHolder(view)

    private class HVH(view: View, val text: TextView) : RecyclerView.ViewHolder(view)

    private fun dp(v: Int): Int = UiUtil.dp(ctx, v)

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int {
        val x = items[position]
        return if (x is Chan) 1 else if (x is String) 2 else if (x is Plist) 3 else 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            1 -> createChan()
            2 -> createHeader()
            3 -> createPlist()
            else -> createVideo()
        }
    }

    // ------------------------------------------------------------------ heading

    private fun createHeader(): RecyclerView.ViewHolder {
        val t = TextView(ctx)
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.setTypeface(null, Typeface.BOLD)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(10), dp(14), dp(10), dp(4))
        t.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return HVH(t, t)
    }

    // ------------------------------------------------------------------ channel card

    private fun createChan(): RecyclerView.ViewHolder {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(5), dp(14), dp(5), dp(14))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, zoom)

        val size = dp(96)
        val av = UiUtil.avatarView(ctx, size, 38f)
        card.addView(av.first, LinearLayout.LayoutParams(size, size))

        val name = TextView(ctx)
        name.setTextColor(Color.WHITE)
        name.textSize = 16f
        name.setTypeface(null, Typeface.BOLD)
        name.gravity = Gravity.CENTER
        name.maxLines = 2
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        nlp.topMargin = dp(10)
        card.addView(name, nlp)

        val subs = TextView(ctx)
        subs.setTextColor(Color.parseColor("#AAAAAA"))
        subs.textSize = 12f
        subs.gravity = Gravity.CENTER
        subs.maxLines = 1
        subs.ellipsize = TextUtils.TruncateAt.END
        card.addView(subs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
        return CVH(card, av.second, av.third, name, subs)
    }

    // ------------------------------------------------------------------ playlist card

    private fun createPlist(): RecyclerView.ViewHolder {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(5), dp(5), dp(5), dp(8))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, zoom)

        val thumbH = cardW * 9 / 16
        val fl = FrameLayout(ctx)
        UiUtil.roundRect(fl, dp(12).toFloat())
        val img = ImageView(ctx)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(Color.parseColor("#222222"))
        fl.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val badge = TextView(ctx)
        badge.setTextColor(Color.WHITE)
        badge.textSize = 12f
        badge.setTypeface(null, Typeface.BOLD)
        badge.setBackgroundColor(Color.parseColor("#CC000000"))
        badge.setPadding(dp(6), dp(2), dp(6), dp(2))
        val blp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
        blp.setMargins(0, 0, dp(6), dp(6))
        fl.addView(badge, blp)
        card.addView(fl, LinearLayout.LayoutParams(cardW, thumbH))

        val title = TextView(ctx)
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.setTypeface(null, Typeface.BOLD)
        title.setLines(2)
        title.ellipsize = TextUtils.TruncateAt.END
        title.setPadding(0, dp(8), 0, 0)
        card.addView(title, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sub = TextView(ctx)
        sub.setTextColor(Color.parseColor("#AAAAAA"))
        sub.textSize = 14f
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        sub.setPadding(0, dp(2), 0, 0)
        card.addView(sub, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
        return PVH(card, img, badge, title, sub)
    }

    // ------------------------------------------------------------------ video card

    private fun createVideo(): RecyclerView.ViewHolder {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(5), dp(5), dp(5), dp(8))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, zoom)

        val thumbH = cardW * 9 / 16
        val fl = FrameLayout(ctx)
        UiUtil.roundRect(fl, dp(12).toFloat())
        val img = ImageView(ctx)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(Color.parseColor("#222222"))
        fl.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val dur = TextView(ctx)
        dur.setTextColor(Color.WHITE)
        dur.textSize = 15f
        dur.setTypeface(null, Typeface.BOLD)
        dur.setBackgroundColor(Color.parseColor("#CC000000"))
        dur.setPadding(dp(7), dp(2), dp(7), dp(2))
        val dlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
        dlp.setMargins(0, 0, dp(6), dp(8))
        fl.addView(dur, dlp)
        // "already watched" bar along the bottom of the picture (like YouTube)
        val track = View(ctx)
        track.setBackgroundColor(Color.parseColor("#99000000"))
        track.visibility = View.GONE
        fl.addView(track, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4), Gravity.BOTTOM))
        val bar = View(ctx)
        bar.setBackgroundColor(Color.parseColor("#FF0000"))
        bar.visibility = View.GONE
        fl.addView(bar, FrameLayout.LayoutParams(0, dp(4), Gravity.BOTTOM or Gravity.START))
        card.addView(fl, LinearLayout.LayoutParams(cardW, thumbH))

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, 0)

        val avT = UiUtil.avatarView(ctx, dp(40), 17f)
        val av = avT.second
        val alp = LinearLayout.LayoutParams(dp(40), dp(40))
        alp.rightMargin = dp(10)
        row.addView(avT.first, alp)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val title = TextView(ctx)
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.setTypeface(null, Typeface.BOLD)
        title.setLines(2)
        title.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        val sub = TextView(ctx)
        sub.setTextColor(Color.parseColor("#AAAAAA"))
        sub.textSize = 14f
        sub.setLines(2)
        sub.ellipsize = TextUtils.TruncateAt.END
        sub.setPadding(0, dp(2), 0, 0)
        col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
        return VH(card, img, dur, av, avT.third, title, sub, track, bar)
    }

    // ------------------------------------------------------------------ bind

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        holder.itemView.tag = item      // lets the screen know which video / channel has focus
        if (holder is HVH && item is String) {
            holder.text.text = item
        } else if (holder is PVH && item is Plist) {
            holder.title.text = item.title
            holder.sub.text = "Playlist" + (if (item.channel.isNotEmpty()) "  \u2022  " + item.channel else "")
            holder.badge.text = "\u2630 " + item.count.ifEmpty { "Playlist" }
            Img.load(holder.img, item.thumb, cardW)
            holder.itemView.setOnClickListener { onPlist(item) }
        } else if (holder is CVH && item is Chan) {
            holder.name.text = item.name
            holder.subs.text = item.subs
            holder.subs.visibility = if (item.subs.isEmpty()) View.GONE else View.VISIBLE
            UiUtil.letterAvatar(holder.letter, item.name)
            Img.load(holder.photo, item.thumb, dp(96))
            holder.itemView.setOnClickListener { onChan(item) }
        } else if (holder is VH && item is Vid) {
            holder.title.text = item.title
            holder.sub.text = listOf(item.channel, item.meta).filter { it.isNotEmpty() }.joinToString("\n")
            holder.dur.text = item.dur
            holder.dur.visibility = if (item.dur.isEmpty()) View.GONE else View.VISIBLE
            UiUtil.letterAvatar(holder.avatar, item.channel)
            holder.boundVid = item.id
            val pct = maxOf(item.pct, Store.percent(ctx, item.id))
            if (pct in 2..100) {
                val lp = holder.bar.layoutParams
                lp.width = cardW * pct / 100
                holder.bar.layoutParams = lp
                holder.bar.visibility = View.VISIBLE
                holder.track.visibility = View.VISIBLE
            } else {
                holder.bar.visibility = View.GONE
                holder.track.visibility = View.GONE
            }
            val known = item.cthumb.ifEmpty { YT.cachedPhoto(ctx, item.channelId, item.id) }
            Img.load(holder.avatarPhoto, known, dp(34))
            if (known.isEmpty()) {
                // no photo came with the card (account feeds): look it up, show it when it arrives
                YT.resolvePhoto(ctx, item.id, item.channelId) { url ->
                    if (holder.boundVid == item.id) Img.load(holder.avatarPhoto, url, dp(34))
                }
            }
            Img.load(holder.img, item.thumb, cardW)
            holder.itemView.setOnClickListener { onVideo(item) }
            // long press on OK (if the remote supports it) opens the small menu
            holder.itemView.setOnLongClickListener { onVideoMenu(item); true }
        }
        if (position >= items.size - nearEnd) holder.itemView.post { onNearEnd() }
    }
}


/** One horizontal row of cards with a title above it. */
class FeedRow(var title: String, val items: MutableList<Any> = ArrayList()) {
    var adapter: FeedAdapter? = null
    var more: String? = null        // YouTube token: next videos of this row
    var busy = false                // loading more of this row right now
    var grow = false                // search / fallback rows: more comes from the next result page
    var scrollState: android.os.Parcelable? = null   // sideways position, kept while the row is off screen
}

/**
 * Android-TV style home / search: a vertical list of rows, every row scrolls sideways.
 * The card that has focus grows (see [UiUtil.focusZoom]).
 */
class RowsAdapter(
    private val ctx: Context,
    val rows: List<FeedRow>,
    private val cardW: Int,
    private val onVideo: (Vid) -> Unit,
    private val onVideoMenu: (Vid) -> Unit,
    private val onChan: (Chan) -> Unit,
    private val onPlist: (Plist) -> Unit,
    private val onRowEnd: (FeedRow) -> Unit
) : RecyclerView.Adapter<RowsAdapter.RVH>() {

    class RVH(view: View, val title: TextView, val list: RecyclerView) : RecyclerView.ViewHolder(view) {
        var row: FeedRow? = null
    }

    private val pool = RecyclerView.RecycledViewPool()
    private fun dp(v: Int): Int = UiUtil.dp(ctx, v)

    override fun getItemCount(): Int = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RVH {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.clipChildren = false
        box.clipToPadding = false
        box.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val t = TextView(ctx)
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.setTypeface(null, Typeface.BOLD)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(20), dp(10), dp(20), 0)
        box.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val rv = RecyclerView(ctx)
        rv.layoutManager = LinearLayoutManager(ctx, LinearLayoutManager.HORIZONTAL, false)
        rv.setRecycledViewPool(pool)
        rv.itemAnimator = null
        rv.clipToPadding = false          // room around the cards so a zoomed card is not cut
        rv.clipChildren = false
        rv.setPadding(dp(15), dp(18), dp(15), dp(18))
        rv.isFocusable = false
        box.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return RVH(box, t, rv)
    }

    override fun onBindViewHolder(holder: RVH, position: Int) {
        val row = rows[position]
        holder.title.text = row.title
        holder.title.visibility = if (row.title.isEmpty()) View.GONE else View.VISIBLE
        var a = row.adapter
        if (a == null) {
            a = FeedAdapter(ctx, row.items, cardW, 5, onVideo, onVideoMenu, onChan, { onRowEnd(row) }, onPlist, 1.14f)
            row.adapter = a
        }
        holder.row = row
        if (holder.list.adapter !== a) holder.list.adapter = a
        // come back to the same sideways position (not the start) when the row scrolls into view again
        val st = row.scrollState
        if (st != null) holder.list.layoutManager?.onRestoreInstanceState(st)
        else holder.list.scrollToPosition(0)
    }

    override fun onViewRecycled(holder: RVH) {
        holder.row?.scrollState = holder.list.layoutManager?.onSaveInstanceState()
        holder.row = null
        super.onViewRecycled(holder)
    }
}
