package com.yttv.app

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Small helpers shared by the home screen and the channel page. */
object UiUtil {
    val avatarColors = intArrayOf(
        Color.parseColor("#E53935"), Color.parseColor("#8E24AA"), Color.parseColor("#3949AB"),
        Color.parseColor("#00897B"), Color.parseColor("#F4511E"), Color.parseColor("#039BE5"),
        Color.parseColor("#7CB342"), Color.parseColor("#6D4C41")
    )

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /** Coloured circle with the first letter (shown until / unless the real photo loads). */
    fun letterAvatar(tv: TextView, name: String) {
        val n = name.trim()
        tv.text = if (n.isEmpty()) "" else n.substring(0, 1).uppercase()
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(avatarColors[(n.hashCode() and 0x7fffffff) % avatarColors.size])
        tv.background = bg
    }

    /** Hide status + navigation bar (full screen). Call from onCreate and onWindowFocusChanged. */
    @Suppress("DEPRECATION")
    fun immersive(w: android.view.Window) {
        w.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    fun roundRect(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    /** Card grows a little while it has focus (like YouTube TV). */
    fun focusZoom(v: View, scale: Float) {
        v.setOnFocusChangeListener { view, focused ->
            view.animate().scaleX(if (focused) scale else 1f).scaleY(if (focused) scale else 1f).setDuration(120).start()
            view.translationZ = if (focused) 12f else 0f
        }
    }

    fun roundClip(iv: ImageView) {
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        iv.clipToOutline = true
    }

    /** Round channel photo: letter underneath, photo on top once it has loaded. */
    fun avatarView(c: Context, size: Int, textSp: Float): Triple<FrameLayout, TextView, ImageView> {
        val fl = FrameLayout(c)
        val letter = TextView(c)
        letter.gravity = Gravity.CENTER
        letter.setTextColor(Color.WHITE)
        letter.textSize = textSp
        letter.setTypeface(null, Typeface.BOLD)
        fl.addView(letter, FrameLayout.LayoutParams(size, size))
        val img = ImageView(c)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(img)
        fl.addView(img, FrameLayout.LayoutParams(size, size))
        return Triple(fl, letter, img)
    }
}

/**
 * One adapter for every grid: items can be a Vid (video card), a Chan (channel card)
 * or a String (section heading that spans the full row).
 */
class FeedAdapter(
    private val ctx: Context,
    private val items: List<Any>,
    private val cardW: Int,
    private val nearEnd: Int,
    private val onVideo: (Vid) -> Unit,
    private val onVideoMenu: (Vid) -> Unit,
    private val onChan: (Chan) -> Unit,
    private val onNearEnd: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private class VH(
        view: View, val img: ImageView, val dur: TextView, val avatar: TextView, val avatarPhoto: ImageView,
        val title: TextView, val sub: TextView
    ) : RecyclerView.ViewHolder(view)

    private class CVH(
        view: View, val letter: TextView, val photo: ImageView, val name: TextView, val subs: TextView
    ) : RecyclerView.ViewHolder(view)

    private class HVH(view: View, val text: TextView) : RecyclerView.ViewHolder(view)

    private fun dp(v: Int): Int = UiUtil.dp(ctx, v)

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int {
        val x = items[position]
        return if (x is Chan) 1 else if (x is String) 2 else 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            1 -> createChan()
            2 -> createHeader()
            else -> createVideo()
        }
    }

    // ------------------------------------------------------------------ heading

    private fun createHeader(): RecyclerView.ViewHolder {
        val t = TextView(ctx)
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.setTypeface(null, Typeface.BOLD)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(10), dp(14), dp(10), dp(4))
        t.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return HVH(t, t)
    }

    // ------------------------------------------------------------------ channel card

    private fun createChan(): RecyclerView.ViewHolder {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(5), dp(14), dp(5), dp(14))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, 1.04f)

        val size = dp(96)
        val av = UiUtil.avatarView(ctx, size, 38f)
        card.addView(av.first, LinearLayout.LayoutParams(size, size))

        val name = TextView(ctx)
        name.setTextColor(Color.WHITE)
        name.textSize = 16f
        name.setTypeface(null, Typeface.BOLD)
        name.gravity = Gravity.CENTER
        name.maxLines = 2
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        nlp.topMargin = dp(10)
        card.addView(name, nlp)

        val subs = TextView(ctx)
        subs.setTextColor(Color.parseColor("#AAAAAA"))
        subs.textSize = 12f
        subs.gravity = Gravity.CENTER
        subs.maxLines = 1
        subs.ellipsize = TextUtils.TruncateAt.END
        card.addView(subs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
        return CVH(card, av.second, av.third, name, subs)
    }

    // ------------------------------------------------------------------ video card

    private fun createVideo(): RecyclerView.ViewHolder {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(5), dp(5), dp(5), dp(8))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, 1.04f)

        val thumbH = cardW * 9 / 16
        val fl = FrameLayout(ctx)
        UiUtil.roundRect(fl, dp(12).toFloat())
        val img = ImageView(ctx)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(Color.parseColor("#222222"))
        fl.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val dur = TextView(ctx)
        dur.setTextColor(Color.WHITE)
        dur.textSize = 12f
        dur.setTypeface(null, Typeface.BOLD)
        dur.setBackgroundColor(Color.parseColor("#CC000000"))
        dur.setPadding(dp(5), dp(1), dp(5), dp(1))
        val dlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
        dlp.setMargins(0, 0, dp(6), dp(6))
        fl.addView(dur, dlp)
        card.addView(fl, LinearLayout.LayoutParams(cardW, thumbH))

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, 0)

        val avT = UiUtil.avatarView(ctx, dp(34), 15f)
        val av = avT.second
        val alp = LinearLayout.LayoutParams(dp(34), dp(34))
        alp.rightMargin = dp(10)
        row.addView(avT.first, alp)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val title = TextView(ctx)
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.setTypeface(null, Typeface.BOLD)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        val sub = TextView(ctx)
        sub.setTextColor(Color.parseColor("#AAAAAA"))
        sub.textSize = 12f
        sub.maxLines = 2
        sub.ellipsize = TextUtils.TruncateAt.END
        sub.setPadding(0, dp(2), 0, 0)
        col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
        return VH(card, img, dur, av, avT.third, title, sub)
    }

    // ------------------------------------------------------------------ bind

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        if (holder is HVH && item is String) {
            holder.text.text = item
        } else if (holder is CVH && item is Chan) {
            holder.name.text = item.name
            holder.subs.text = item.subs
            holder.subs.visibility = if (item.subs.isEmpty()) View.GONE else View.VISIBLE
            UiUtil.letterAvatar(holder.letter, item.name)
            Img.load(holder.photo, item.thumb, dp(96))
            holder.itemView.setOnClickListener { onChan(item) }
        } else if (holder is VH && item is Vid) {
            holder.title.text = item.title
            holder.sub.text = listOf(item.channel, item.meta).filter { it.isNotEmpty() }.joinToString("\n")
            holder.dur.text = item.dur
            holder.dur.visibility = if (item.dur.isEmpty()) View.GONE else View.VISIBLE
            UiUtil.letterAvatar(holder.avatar, item.channel)
            Img.load(holder.avatarPhoto, item.cthumb, dp(34))
            Img.load(holder.img, item.thumb, cardW)
            holder.itemView.setOnClickListener { onVideo(item) }
            // long press on OK (if the remote supports it) opens the small menu
            holder.itemView.setOnLongClickListener { onVideoMenu(item); true }
        }
        if (position >= items.size - nearEnd) holder.itemView.post { onNearEnd() }
    }
}
