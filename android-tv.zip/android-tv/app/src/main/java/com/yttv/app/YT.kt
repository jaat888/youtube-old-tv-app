package com.yttv.app

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** One page of results: videos and channels in the order YouTube returned them. */
class Page(val mixed: List<Any>, val token: String?, val related: List<String> = emptyList()) {
    val items: List<Vid> get() = mixed.filterIsInstance<Vid>()
}

class ChanPage(val info: Chan?, val page: Page)

/** Marker that follows the videos of one Home shelf: "load more of THIS row" token. */
class MoreToken(val token: String)

class Fmt(val url: String, val height: Int, val bitrate: Int, val itag: Int)

/** Everything the player needs for one video. */
class Stream(
    val title: String,
    val ua: String,
    val muxed: Fmt?,          // video+audio in one file (usually 360p) - the safe fallback
    val videos: List<Fmt>,    // H.264 video-only files
    val audio: Fmt?,          // AAC audio-only file
    val channelId: String = "",
    val author: String = ""
) {
    /** Qualities that can be chosen, highest first. */
    fun heights(): List<Int> {
        val s = HashSet<Int>()
        if (audio != null) for (v in videos) s.add(v.height)
        if (muxed != null) s.add(muxed.height)
        return s.sortedDescending()
    }

    /** Best video-only file up to [max] pixels high, or null (= use the muxed file). */
    fun pickVideo(max: Int): Fmt? {
        if (audio == null) return null
        val mh = muxed?.height ?: 0
        if (max <= mh) return null
        return videos.filter { it.height <= max && it.height > mh }
            .maxByOrNull { it.height * 1_000_000L + it.bitrate }
    }
}

/**
 * Talks to YouTube's own internal API (InnerTube), straight from the TV - no server.
 *  - search / home / related use the WEB client
 *  - stream links use VISIONOS (and ANDROID_VR as backup): these clients hand out
 *    plain URLs that need no PO token (same trick as the Musike app).
 */
object YT {
    private const val BASE = "https://www.youtube.com/youtubei/v1/"

    private const val WEB_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
    private const val VISION_UA =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"
    private const val VR_UA =
        "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"

    private const val HL = "en"
    private const val GL = "IN"

    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    @Volatile private var webVersion = "2.20250925.01.00"
    @Volatile private var webVisitor = ""
    @Volatile private var webReady = false

    @Volatile private var playVisitor = ""
    @Volatile private var playVisitorAt = 0L

    // ---------------------------------------------------------------- low level

    private fun post(
        endpoint: String, body: JSONObject, ua: String,
        clientId: String, clientVersion: String, visitor: String
    ): JSONObject {
        val b = Request.Builder()
            .url(BASE + endpoint + "?prettyPrint=false&alt=json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("User-Agent", ua)
            .header("Origin", "https://www.youtube.com")
            .header("X-YouTube-Client-Name", clientId)
            .header("X-YouTube-Client-Version", clientVersion)
            .header("X-Goog-Api-Format-Version", "2")
        if (visitor.isNotEmpty()) b.header("X-Goog-Visitor-Id", visitor)
        http.newCall(b.build()).execute().use { r ->
            val text = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("YouTube HTTP ${r.code}")
            return JSONObject(text)
        }
    }

    /** Reads the current web client version + a visitor id from the YouTube home page (once). */
    private fun initWeb() {
        if (webReady) return
        synchronized(this) {
            if (webReady) return
            try {
                val req = Request.Builder().url("https://www.youtube.com/?hl=$HL&gl=$GL")
                    .header("User-Agent", WEB_UA)
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Cookie", "SOCS=CAI; CONSENT=YES+1")
                    .build()
                http.newCall(req).execute().use { r ->
                    val html = r.body?.string() ?: ""
                    Regex("\"INNERTUBE_CONTEXT_CLIENT_VERSION\":\"([^\"]+)\"").find(html)
                        ?.let { webVersion = it.groupValues[1] }
                    Regex("\"VISITOR_DATA\":\"([^\"]+)\"").find(html)
                        ?.let { webVisitor = it.groupValues[1] }
                }
            } catch (e: Exception) {
                // keep defaults
            }
            webReady = true
        }
    }

    private fun webCtx(): JSONObject {
        initWeb()
        val c = JSONObject()
            .put("clientName", "WEB").put("clientVersion", webVersion)
            .put("hl", HL).put("gl", GL)
        if (webVisitor.isNotEmpty()) c.put("visitorData", webVisitor)
        return JSONObject().put("context", JSONObject().put("client", c))
    }

    private fun webPost(endpoint: String, body: JSONObject): JSONObject {
        initWeb()
        return post(endpoint, body, WEB_UA, "1", webVersion, webVisitor)
    }

    // ---------------------------------------------------------------- feeds

    /** Home feed (logged-out). May come back nearly empty; the app then falls back to searches. */
    fun home(token: String?): Page {
        // TV home (rows with titles, like SmartTube / YouTube on TV). Tokens of that feed start with "tv:".
        if (token == null || token.startsWith("tv:")) {
            for (id in (if (token == null) listOf("default") else listOf(""))) {
                try {
                    val root = tvPostAnon("browse") {
                        if (token == null) put("browseId", id) else put("continuation", token.substring(3))
                    }
                    val p = parseShelves(root)
                    if (token != null || p.items.size >= 8)
                        return Page(p.mixed, p.token?.let { "tv:$it" }, p.related)
                } catch (e: Exception) {
                    if (token != null) throw e
                }
            }
        }
        val body = webCtx()
        if (token == null) body.put("browseId", "FEwhat_to_watch") else body.put("continuation", token)
        return parse(webPost("browse", body), null)
    }

    /** More videos of ONE Home row (sideways scrolling). Same client as the Home feed. */
    fun shelfMore(c: Context, token: String, signedIn: Boolean): Page {
        val root = if (signedIn) tvPost(c, "browse") { put("continuation", token) }
        else tvPostAnon("browse") { put("continuation", token) }
        val p = parse(root, null)
        val lc = findKey(root, "horizontalListContinuation") ?: findKey(root, "gridContinuation")
        val t = if (lc != null) listToken(lc) else ""
        return Page(p.mixed.filter { it !is MoreToken }, t.ifEmpty { null })
    }

    private val shelfMode = ThreadLocal<Boolean>()

    private fun parseShelves(root: JSONObject): Page {
        shelfMode.set(true)
        try { return parse(root, null) } finally { shelfMode.set(false) }
    }

    /** TV client without login (anonymous), for the logged-out Home (SmartTube does the same). */
    private fun tvPostAnon(endpoint: String, extra: JSONObject.() -> Unit): JSONObject = tvSend(endpoint, null, extra)

    /** Search. [filter] is an optional YouTube "params" string (videos only by default). */
    fun search(query: String, token: String?, filter: String = "EgIQAQ=="): Page {
        val body = webCtx()
        if (token == null) {
            body.put("query", query)
            if (filter.isNotEmpty()) body.put("params", filter)
        } else {
            body.put("continuation", token)
        }
        return parse(webPost("search", body), null)
    }

    /** "Up next" / related videos for a video. */
    fun related(id: String): List<Vid> {
        val body = webCtx().put("videoId", id)
        return parse(webPost("next", body), id).items
    }

    /** A channel's videos (newest first). First call (token == null) also returns the channel info. */
    fun channel(id: String, token: String?, name: String, playlists: Boolean = false): ChanPage {
        val body = webCtx()
        if (token == null) {
            body.put("browseId", id)
            body.put("params", if (playlists) "EglwbGF5bGlzdHPyBgQKAkIA" else "EgZ2aWRlb3PyBgQKAjoA")   // "Playlists" / "Videos" tab
        } else {
            body.put("continuation", token)
        }
        val root = webPost("browse", body)
        val info = if (token == null) chanInfo(id, root) else null
        val nm = info?.name?.ifEmpty { name } ?: name
        val p = parse(root, null)
        val fixed = p.mixed.map { x ->
            if (x is Vid) x.copy(
                channel = if (x.channel.isEmpty()) nm else x.channel,
                channelId = id,
                cthumb = x.cthumb.ifEmpty { info?.thumb ?: chanPhotos[id] ?: "" }
            ) else x
        }
        if (info != null && info.thumb.isNotEmpty()) chanPhotos[id] = info.thumb
        return ChanPage(info, Page(fixed, p.token))
    }

    // ---------------------------------------------------------------- signed in (TV client + bearer token)

    // Same request shape as SmartTube (MediaServiceCore AppClient.TV + BrowseApi): TVHTML5 client, Cobalt TV user agent, Referer /tv
    private const val TV_BROWSE_UA =
        "Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0) Cobalt/22.lts.3.306369-gold (unlike Gecko) v8/8.8.278.8-jit gles Starboard/13, Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless) com.amazon.firetv.youtube/22.3.r2.v66.0"
    private const val TV_CLIENT_UA =
        "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/25.lts.30.1034943-gold (unlike Gecko), Unknown_TV_Unknown_0/Unknown (Unknown, Unknown)"

    private fun tvBody(): JSONObject {
        initWeb()
        val tz = java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
        val client = JSONObject()
            .put("clientName", "TVHTML5").put("clientVersion", Auth.TV_VERSION)
            .put("clientScreen", "WATCH").put("userAgent", TV_CLIENT_UA)
            .put("browserName", "Cobalt").put("browserVersion", "25.lts.30.1034943-gold")
            .put("tvAppInfo", JSONObject().put("appQuality", "TV_APP_QUALITY_FULL_ANIMATION").put("zylonLeftNav", true))
            .put("webpSupport", false).put("animatedWebpSupport", true)
            .put("acceptLanguage", HL).put("acceptRegion", GL)
            .put("utcOffsetMinutes", tz.toString())
        if (webVisitor.isNotEmpty()) client.put("visitorData", webVisitor)
        val ctx = JSONObject().put("client", client)
            .put("user", JSONObject().put("enableSafetyMode", false).put("lockedSafetyMode", false))
        return JSONObject().put("context", ctx).put("racyCheckOk", true).put("contentCheckOk", true)
    }

    private fun tvSend(endpoint: String, at: String?, extra: JSONObject.() -> Unit): JSONObject {
        val body = tvBody()
        body.extra()
        val b = Request.Builder().url(BASE + endpoint + "?prettyPrint=false&alt=json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("User-Agent", TV_BROWSE_UA)
            .header("Referer", "https://www.youtube.com/tv")
        if (at != null) b.header("Authorization", "Bearer $at")
        http.newCall(b.build()).execute().use { r ->
            val text = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("YouTube HTTP ${r.code}")
            return JSONObject(text)
        }
    }

    private fun tvPost(c: Context, endpoint: String, extra: JSONObject.() -> Unit): JSONObject {
        val at = Auth.token(c) ?: throw RuntimeException("Not signed in")
        return tvSend(endpoint, at, extra)
    }

    /** Account feeds: "default" (recommendations), "FEsubscriptions", "FEhistory". */
    fun tvBrowse(c: Context, browseId: String, token: String?): Page {
        val root = tvPost(c, "browse") {
            if (token == null) put("browseId", browseId) else put("continuation", token)
        }
        return if (browseId == "default") parseShelves(root) else parse(root, null)
    }

    fun subscribeRemote(c: Context, channelId: String, on: Boolean) {
        tvPost(c, if (on) "subscription/subscribe" else "subscription/unsubscribe") {
            put("channelIds", JSONArray().put(channelId))
        }
    }

    /**
     * The channels this account is subscribed to (SmartTube does the same): the TV "Subscriptions" page lists
     * them as tabs. The channel id is hidden inside each tab's "params" (base64), the first tab is "All".
     */
    fun accountChannels(c: Context): List<Chan> {
        val root = tvPost(c, "browse") { put("browseId", "FEsubscriptions") }
        val tabs = root.optJSONObject("contents")?.optJSONObject("tvBrowseRenderer")?.optJSONObject("content")
            ?.optJSONObject("tvSecondaryNavRenderer")?.optJSONArray("sections")?.optJSONObject(0)
            ?.optJSONObject("tvSecondaryNavSectionRenderer")?.optJSONArray("tabs") ?: return emptyList()
        val out = ArrayList<Chan>()
        val ids = HashSet<String>()
        for (i in 0 until tabs.length()) {
            val t = tabs.optJSONObject(i) ?: continue
            val tr = t.optJSONObject("tabRenderer") ?: t.optJSONObject("expandableTabRenderer") ?: continue
            val title = tr.optString("title")
            val params = tr.optJSONObject("endpoint")?.optJSONObject("browseEndpoint")?.optString("params") ?: ""
            val id = channelIdFromParams(params)
            if (id.isEmpty() || title.isEmpty() || !ids.add(id)) continue
            val th = lastThumb(tr.optJSONObject("thumbnail")).replace(Regex("=s\\d+-"), "=s176-")
            out.add(Chan(id, title, th, ""))
        }
        for (ch in out) if (ch.thumb.isNotEmpty()) chanPhotos[ch.id] = ch.thumb
        return out
    }

    private fun channelIdFromParams(p: String): String {
        if (p.isEmpty()) return ""
        return try {
            var s = java.net.URLDecoder.decode(p, "UTF-8")
            while (s.length % 4 != 0) s += "="
            val b = android.util.Base64.decode(s, android.util.Base64.URL_SAFE)
            Regex("UC[\\w-]{22}").find(String(b, Charsets.ISO_8859_1))?.value ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    // ---------------------------------------------------------------- watch history of the account

    private class Track(val ei: String, val vm: String, val of: String, val cpn: String) {
        @Volatile var created = false
        @Volatile var lastPos = 0f
    }

    private val tracks = java.util.concurrent.ConcurrentHashMap<String, Track>()
    private const val CPN_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    private fun newCpn(): String {
        val r = java.security.SecureRandom()
        val sb = StringBuilder()
        repeat(16) { sb.append(CPN_CHARS[r.nextInt(CPN_CHARS.length)]) }
        return sb.toString()
    }

    /** The tracking values (ei / vm / of) of a video, taken from the signed-in TV player response. */
    private fun trackFor(c: Context, id: String): Track? {
        tracks[id]?.let { return it }
        val r = tvPost(c, "player") {
            put("videoId", id)
            put("racyCheckOk", true)
            put("contentCheckOk", true)
        }
        val url = r.optJSONObject("playbackTracking")?.optJSONObject("videostatsWatchtimeUrl")?.optString("baseUrl")
        if (url.isNullOrEmpty()) return null
        val u = android.net.Uri.parse(if (url.startsWith("//")) "https:$url" else url)
        val ei = u.getQueryParameter("ei") ?: ""
        val vm = u.getQueryParameter("vm") ?: ""
        if (ei.isEmpty() || vm.isEmpty()) return null
        val t = Track(ei, vm, u.getQueryParameter("of") ?: "", newCpn())
        if (tracks.size > 20) tracks.clear()
        tracks[id] = t
        return t
    }

    private fun stats(at: String, path: String, q: List<Pair<String, String>>) {
        val b = "https://www.youtube.com/api/stats/$path".toHttpUrl().newBuilder()
        for ((k, v) in q) b.addQueryParameter(k, v)
        val req = Request.Builder().url(b.build())
            .header("User-Agent", Auth.TV_UA)
            .header("Authorization", "Bearer $at")
            .build()
        http.newCall(req).execute().use { }
    }

    /**
     * Tells YouTube how far this video was watched, so it lands in the account's History
     * (same calls SmartTube makes). Best effort: any error is ignored. Runs on a background thread.
     */
    fun reportWatch(c: Context, id: String, posSec: Float, lenSec: Float) {
        if (lenSec <= 1f || id.length != 11) return
        val at = Auth.token(c) ?: return
        val t = trackFor(c, id) ?: return
        val almost = lenSec - posSec < lenSec * 0.05f
        val pos = if (almost) lenSec else posSec
        fun base(): MutableList<Pair<String, String>> {
            val l = ArrayList<Pair<String, String>>()
            l.add("ns" to "yt"); l.add("ver" to "2"); l.add("docid" to id); l.add("cpn" to t.cpn)
            l.add("ei" to t.ei); l.add("vm" to t.vm)
            if (t.of.isNotEmpty()) l.add("of" to t.of)
            return l
        }
        if (!t.created) {
            val l = base()
            if (almost) l.add("final" to "1") else { l.add("len" to lenSec.toString()); l.add("cmt" to t.lastPos.toString()) }
            stats(at, "playback", l)
            t.created = true
        }
        val l = base()
        if (almost) l.add("final" to "1") else l.add("len" to lenSec.toString())
        l.add("st" to t.lastPos.toString()); l.add("et" to pos.toString()); l.add("cmt" to pos.toString())
        stats(at, "watchtime", l)
        t.lastPos = pos
    }

    /** Videos of a playlist (first page, or the next one with [token]). */
    fun playlist(id: String, token: String?): Page {
        val body = webCtx()
        if (token == null) body.put("browseId", if (id.startsWith("VL")) id else "VL$id") else body.put("continuation", token)
        return parse(webPost("browse", body), null)
    }

    /** Search-box suggestions while typing (free Google endpoint, no key). */
    fun suggest(q: String): List<String> {
        val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=$HL&q=" +
            java.net.URLEncoder.encode(q, "UTF-8")
        val req = Request.Builder().url(url).header("User-Agent", WEB_UA).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val arr = JSONArray(r.body?.string() ?: "[]")
            val l = arr.optJSONArray(1) ?: return emptyList()
            val out = ArrayList<String>()
            for (i in 0 until minOf(l.length(), 8)) {
                val t = l.optString(i)
                if (t.isNotEmpty()) out.add(t)
            }
            return out
        }
    }

    // ---------------------------------------------------------------- parsing

    private val SKIP_KEYS = setOf("adSlotRenderer", "promotedSparklesWebRenderer", "searchPyvRenderer", "displayAdRenderer")
    private val VIDEO_KEYS = setOf("videoRenderer", "compactVideoRenderer", "gridVideoRenderer", "playlistVideoRenderer")
    // TV answers: the "next page" token sits in <list>.continuations[].nextContinuationData (rows inside a list have their own, ignored)
    private val LIST_KEYS = setOf("sectionListRenderer", "sectionListContinuation", "gridRenderer", "gridContinuation", "playlistVideoListRenderer")

    private fun listToken(v: JSONObject): String {
        val a = v.optJSONArray("continuations") ?: return ""
        for (i in 0 until a.length()) {
            val t = a.optJSONObject(i)?.optJSONObject("nextContinuationData")?.optString("continuation") ?: ""
            if (t.isNotEmpty()) return t
        }
        return ""
    }

    private fun parse(root: JSONObject, exclude: String?): Page {
        val out = ArrayList<Any>()
        val seen = HashSet<String>()
        if (exclude != null) seen.add(exclude)
        val tok = arrayOfNulls<String>(1)
        val rel = ArrayList<String>()
        walk(root, out, seen, tok, rel)
        // remember channel photos, and give them to videos that came without one
        for (x in out) if (x is Vid && x.cthumb.isNotEmpty() && x.channelId.isNotEmpty()) chanPhotos[x.channelId] = x.cthumb
        for (i in out.indices) {
            val x = out[i]
            if (x is Vid && x.cthumb.isEmpty() && x.channelId.isNotEmpty()) {
                val p = chanPhotos[x.channelId]
                if (p != null) out[i] = x.copy(cthumb = p)
            } else if (x is Chan && x.thumb.isNotEmpty()) {
                chanPhotos[x.id] = x.thumb
            }
        }
        return Page(out, tok[0], rel)
    }

    private val chanPhotos = java.util.concurrent.ConcurrentHashMap<String, String>()

    // ---- channel photos for cards that came without one (account feeds often have none)

    @Volatile private var photosLoaded = false
    private val photoFailed = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val photoWaiters = HashMap<String, MutableList<(String) -> Unit>>()   // main thread only
    private val photoQueue = java.util.concurrent.LinkedBlockingDeque<Pair<String, () -> Unit>>()
    private var photoWorker: Thread? = null
    private val vidChan = java.util.concurrent.ConcurrentHashMap<String, String>()   // video id -> channel id

    private fun loadPhotos(c: Context) {
        if (photosLoaded) return
        synchronized(this) {
            if (photosLoaded) return
            try {
                val o = JSONObject(Store.photoCache(c))
                val ks = o.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val u = o.optString(k)
                    if (u.isNotEmpty()) chanPhotos.putIfAbsent(k, u)
                }
            } catch (e: Exception) {
            }
            try {
                for (ch in Store.accountChans(c)) if (ch.thumb.isNotEmpty()) chanPhotos.putIfAbsent(ch.id, ch.thumb)
            } catch (e: Exception) {
            }
            photosLoaded = true
        }
    }

    /** Photo url we already know for this channel (or for the channel of this video), else "". */
    fun cachedPhoto(c: Context, channelId: String, videoId: String): String {
        loadPhotos(c)
        val cid = channelId.ifEmpty { vidChan[videoId] ?: "" }
        return if (cid.isEmpty()) "" else chanPhotos[cid] ?: ""
    }

    /** Main thread. Looks the photo up in the background (one at a time, newest card first); [done] gets the url. */
    fun resolvePhoto(c: Context, videoId: String, channelId: String, done: (String) -> Unit) {
        val cid = channelId.ifEmpty { vidChan[videoId] ?: "" }
        val key = if (cid.isNotEmpty()) cid else "v:$videoId"
        if (photoFailed.contains(key)) return
        val list = photoWaiters[key]
        if (list != null) {
            list.add(done)
            return
        }
        photoWaiters[key] = arrayListOf(done)
        val app = c.applicationContext
        val job: () -> Unit = {
            var url = ""
            var id = cid
            try {
                if (id.isNotEmpty()) {
                    url = chanInfo(id, webPost("browse", webCtx().put("browseId", id))).thumb
                } else {
                    val o = findKey(webPost("next", webCtx().put("videoId", videoId)), "videoOwnerRenderer")
                    if (o != null) {
                        id = findChanId(o)
                        url = lastThumb(o.optJSONObject("thumbnail"))
                    }
                }
                url = fixUrl(url).replace(Regex("=s\\d+-"), "=s88-")
            } catch (e: Exception) {
                url = ""
            }
            if (url.isNotEmpty() && id.isNotEmpty()) {
                chanPhotos[id] = url
                if (cid.isEmpty()) vidChan[videoId] = id
                Store.putPhoto(app, id, url)
            }
            val fu = url
            Net.main.post {
                val ws = photoWaiters.remove(key)
                if (fu.isEmpty()) photoFailed.add(key)
                if (ws != null && fu.isNotEmpty()) for (w in ws) w(fu)
            }
        }
        photoQueue.addLast(Pair(key, job))
        while (photoQueue.size > 60) {      // scrolled far: drop the oldest requests
            val old = photoQueue.pollFirst() ?: break
            photoWaiters.remove(old.first)
        }
        synchronized(this) {
            if (photoWorker == null) {
                val t = Thread {
                    while (true) {
                        try {
                            val job = photoQueue.takeLast()
                            job.second()
                            Thread.sleep(120)
                        } catch (e: InterruptedException) {
                            return@Thread
                        } catch (e: Throwable) {
                        }
                    }
                }
                t.isDaemon = true
                t.start()
                photoWorker = t
            }
        }
    }

    private fun findKey(n: Any?, key: String): JSONObject? {
        when (n) {
            is JSONObject -> {
                val hit = n.optJSONObject(key)
                if (hit != null) return hit
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = findKey(n.opt(ks.next()), key)
                    if (r != null) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findKey(n.opt(i), key)
                if (r != null) return r
            }
        }
        return null
    }

    /** Any image stored under a key that looks like an avatar / channel thumbnail. */
    private fun avatarIn(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = n.opt(k)
                    if ((v is JSONObject || v is JSONArray) &&
                        (k.contains("avatar", true) || k.contains("channelThumbnail", true))) {
                        val r = findImg(v)
                        if (r.isNotEmpty()) return r
                    }
                    val r = avatarIn(v)
                    if (r.isNotEmpty()) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = avatarIn(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    /** First image url found inside [n] (handles both "thumbnails" and "sources" shapes). */
    private fun findImg(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val t = n.optJSONArray("thumbnails")
                if (t != null && t.length() > 0) return fixUrl(t.optJSONObject(t.length() - 1)?.optString("url") ?: "")
                val s = n.optJSONArray("sources")
                if (s != null && s.length() > 0) return fixUrl(s.optJSONObject(s.length() - 1)?.optString("url") ?: "")
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = findImg(n.opt(ks.next()))
                    if (r.isNotEmpty()) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findImg(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    private fun walk(n: Any?, out: ArrayList<Any>, seen: HashSet<String>, tok: Array<String?>, rel: ArrayList<String>) {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    if (k in SKIP_KEYS) continue
                    val v = n.opt(k)
                    if (k in LIST_KEYS && v is JSONObject) {
                        val t = listToken(v)
                        if (t.isNotEmpty()) tok[0] = t
                    }
                    if (k in VIDEO_KEYS && v is JSONObject) {
                        videoRenderer(v)?.let { if (seen.add(it.id)) out.add(it) }
                    } else if (k == "lockupViewModel" && v is JSONObject) {
                        if (v.optString("contentType") == "LOCKUP_CONTENT_TYPE_PLAYLIST") {
                            plistLockup(v)?.let { if (seen.add("p:" + it.id)) out.add(it) }
                        } else {
                            lockup(v)?.let { if (seen.add(it.id)) out.add(it) }
                        }
                    } else if ((k == "playlistRenderer" || k == "gridPlaylistRenderer") && v is JSONObject) {
                        plistRenderer(v)?.let { if (seen.add("p:" + it.id)) out.add(it) }
                    } else if (k == "searchRefinementCardRenderer" && v is JSONObject) {
                        val q = txt(v.optJSONObject("query"))
                        if (q.isNotEmpty() && q !in rel) rel.add(q)
                    } else if (k == "shelfRenderer" && v is JSONObject && shelfMode.get() == true) {
                        val sub = ArrayList<Any>()
                        val st = arrayOfNulls<String>(1)      // this row's own "more" token (not the page's)
                        walk(v, sub, seen, st, rel)
                        // always start a new row for a shelf, even one without a title
                        if (sub.any { it is Vid }) out.add(shelfTitle(v)) 
                        out.addAll(sub)
                        if (sub.any { it is Vid }) {
                            var t = st[0] ?: ""
                            if (t.isEmpty()) {
                                val hl = findKey(v, "horizontalListRenderer") ?: findKey(v, "gridRenderer")
                                if (hl != null) t = listToken(hl)
                            }
                            if (t.isNotEmpty()) out.add(MoreToken(t))
                        }
                    } else if (k == "tileRenderer" && v is JSONObject) {
                        tile(v)?.let { if (seen.add(it.id)) out.add(it) }
                    } else if (k == "channelRenderer" && v is JSONObject) {
                        chanRenderer(v)?.let { if (seen.add("c:" + it.id)) out.add(it) }
                    } else if (k == "continuationItemRenderer" && v is JSONObject) {
                        val t = v.optJSONObject("continuationEndpoint")
                            ?.optJSONObject("continuationCommand")?.optString("token") ?: ""
                        if (t.isNotEmpty()) tok[0] = t
                    } else if (v is JSONObject || v is JSONArray) {
                        walk(v, out, seen, tok, rel)
                    }
                }
            }
            is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), out, seen, tok, rel)
        }
    }

    private fun shelfTitle(v: JSONObject): String {
        val direct = txt(v.optJSONObject("title"))
        if (direct.isNotEmpty()) return direct.trim()
        val h = v.optJSONObject("headerRenderer") ?: return ""
        val sh = h.optJSONObject("shelfHeaderRenderer") ?: h
        var t = txt(sh.optJSONObject("title"))
        if (t.isEmpty()) t = txt(sh.optJSONObject("avatarLockup")?.optJSONObject("avatarLockupRenderer")?.optJSONObject("title"))
        if (t.isEmpty()) t = txt(findKey(h, "title"))
        return t.trim()
    }

    private fun txt(o: JSONObject?): String {
        if (o == null) return ""
        val s = o.optString("simpleText")
        if (s.isNotEmpty()) return s
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun videoRenderer(v: JSONObject): Vid? {
        val id = v.optString("videoId")
        if (id.length != 11) return null
        val title = txt(v.optJSONObject("title"))
        if (title.isEmpty()) return null
        val channel = txt(v.optJSONObject("ownerText")).ifEmpty {
            txt(v.optJSONObject("longBylineText")).ifEmpty { txt(v.optJSONObject("shortBylineText")) }
        }
        val views = txt(v.optJSONObject("shortViewCountText")).ifEmpty { txt(v.optJSONObject("viewCountText")) }
        val pub = txt(v.optJSONObject("publishedTimeText"))
        var dur = txt(v.optJSONObject("lengthText"))
        if (dur.isEmpty()) {
            val ov = v.optJSONArray("thumbnailOverlays")
            if (ov != null) for (i in 0 until ov.length()) {
                val t = ov.optJSONObject(i)?.optJSONObject("thumbnailOverlayTimeStatusRenderer")
                if (t != null) { dur = txt(t.optJSONObject("text")); break }
            }
        }
        val meta = listOf(views, pub).filter { it.isNotEmpty() }.joinToString(" • ")
        val cid = findChanId(v.optJSONObject("ownerText"))
            .ifEmpty { findChanId(v.optJSONObject("longBylineText")) }
            .ifEmpty { findChanId(v.optJSONObject("shortBylineText")) }
        val cth = findImg(v.optJSONObject("channelThumbnailSupportedRenderers"))
            .ifEmpty { findImg(v.optJSONObject("channelThumbnail")) }
            .ifEmpty { findImg(v.optJSONObject("channelThumbnailWithLinkRenderer")) }
        return Vid(id, title, channel, meta, dur, cid, cth)
    }

    private fun findChanId(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val b = n.optString("browseId")
                if (b.startsWith("UC")) return b
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = findChanId(n.opt(ks.next()))
                    if (r.isNotEmpty()) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findChanId(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    private fun fixUrl(u: String): String = if (u.startsWith("//")) "https:$u" else u

    private fun lastThumb(o: JSONObject?): String {
        val a = o?.optJSONArray("thumbnails") ?: return ""
        if (a.length() == 0) return ""
        return fixUrl(a.optJSONObject(a.length() - 1)?.optString("url") ?: "")
    }

    /** A channel card from search results. */
    private fun chanRenderer(v: JSONObject): Chan? {
        val id = v.optString("channelId")
        if (!id.startsWith("UC")) return null
        val name = txt(v.optJSONObject("title"))
        if (name.isEmpty()) return null
        // YouTube sometimes puts the @handle in one field and the subscriber count in the other
        val subs = listOf(txt(v.optJSONObject("subscriberCountText")), txt(v.optJSONObject("videoCountText")))
            .firstOrNull { it.contains("subscriber", ignoreCase = true) } ?: ""
        return Chan(id, name, lastThumb(v.optJSONObject("thumbnail")), subs)
    }

    /** Name, photo and subscriber count from a channel page response. */
    private fun chanInfo(id: String, root: JSONObject): Chan {
        val md = root.optJSONObject("metadata")?.optJSONObject("channelMetadataRenderer")
        val name = md?.optString("title") ?: ""
        val thumb = lastThumb(md?.optJSONObject("avatar"))
        return Chan(id, name, thumb, findSubs(root))
    }

    private val SUBS_RE = Regex("^[\\d.,]+\\s?[KMBkmb]?\\s+subscribers?$")

    private fun findSubs(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val v = n.opt(ks.next())
                    if (v is String) {
                        if (v.length < 40 && SUBS_RE.matches(v)) return v
                    } else {
                        val r = findSubs(v)
                        if (r.isNotEmpty()) return r
                    }
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findSubs(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    private fun lockup(v: JSONObject): Vid? {
        if (v.optString("contentType") != "LOCKUP_CONTENT_TYPE_VIDEO") return null
        val id = v.optString("contentId")
        if (id.length != 11) return null
        val md = v.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel") ?: return null
        val title = md.optJSONObject("title")?.optString("content") ?: ""
        if (title.isEmpty()) return null
        val rows = md.optJSONObject("metadata")?.optJSONObject("contentMetadataViewModel")
            ?.optJSONArray("metadataRows")
        val lines = ArrayList<List<String>>()
        if (rows != null) for (i in 0 until rows.length()) {
            val parts = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
            val l = ArrayList<String>()
            for (j in 0 until parts.length()) {
                val t = parts.optJSONObject(j)?.optJSONObject("text")?.optString("content") ?: ""
                if (t.isNotEmpty()) l.add(t)
            }
            if (l.isNotEmpty()) lines.add(l)
        }
        val channel = lines.getOrNull(0)?.firstOrNull() ?: ""
        val meta = lines.drop(1).flatten().joinToString(" • ")
        val dur = findBadge(v.optJSONObject("contentImage"))
        return Vid(id, title, channel, meta, dur, findChanId(md), findImg(md.optJSONObject("image")))
    }

    /** TV-style video tile (account feeds can come back in this shape). */
    private fun tile(v: JSONObject): Vid? {
        if (v.optString("contentType") != "TILE_CONTENT_TYPE_VIDEO") return null
        val id = v.optString("contentId")
        if (id.length != 11) return null
        val md = v.optJSONObject("metadata")?.optJSONObject("tileMetadataRenderer") ?: return null
        // sponsored tiles carry an ad badge / ad ping: never show them
        if (md.toString().contains("adBadgeViewModel") ||
            v.optJSONObject("onFirstVisibleCommand")?.toString()?.contains("adPingingEndpoint") == true) return null
        val title = txt(md.optJSONObject("title"))
        if (title.isEmpty()) return null
        val texts = ArrayList<String>()
        val lines = md.optJSONArray("lines")
        if (lines != null) for (i in 0 until lines.length()) {
            val items = lines.optJSONObject(i)?.optJSONObject("lineRenderer")?.optJSONArray("items") ?: continue
            for (j in 0 until items.length()) {
                val t = txt(items.optJSONObject(j)?.optJSONObject("lineItemRenderer")?.optJSONObject("text"))
                if (t.isNotEmpty()) texts.add(t)
            }
        }
        val channel = texts.getOrNull(0) ?: ""
        val meta = texts.drop(1).joinToString(" \u2022 ")
        return Vid(id, title, channel, meta, findDur(v), findChanId(v), avatarIn(v.optJSONObject("metadata")))
    }

    private fun findDur(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val t = n.optJSONObject("thumbnailOverlayTimeStatusRenderer")
                if (t != null) return txt(t.optJSONObject("text"))
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = findDur(n.opt(ks.next()))
                    if (r.isNotEmpty()) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findDur(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    private fun plistRenderer(v: JSONObject): Plist? {
        val id = v.optString("playlistId")
        if (id.isEmpty() || id.startsWith("RD")) return null
        val title = txt(v.optJSONObject("title"))
        if (title.isEmpty()) return null
        val raw = v.optString("videoCount").ifEmpty { txt(v.optJSONObject("videoCountText")) }
            .ifEmpty { txt(v.optJSONObject("videoCountShortText")) }
        val count = if (raw.isNotEmpty() && raw.all { it.isDigit() }) "$raw videos" else raw
        val ch = txt(v.optJSONObject("shortBylineText")).ifEmpty { txt(v.optJSONObject("longBylineText")) }
        val th = findImg(v.opt("thumbnails")).ifEmpty { findImg(v.opt("thumbnail")) }
        return Plist(id, title, count, th, ch)
    }

    private fun plistLockup(v: JSONObject): Plist? {
        val id = v.optString("contentId")
        if (id.isEmpty() || id.startsWith("RD")) return null
        val md = v.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel") ?: return null
        val title = md.optJSONObject("title")?.optString("content") ?: ""
        if (title.isEmpty()) return null
        val rows = md.optJSONObject("metadata")?.optJSONObject("contentMetadataViewModel")
            ?.optJSONArray("metadataRows")
        var ch = ""
        if (rows != null && rows.length() > 0) {
            val parts = rows.optJSONObject(0)?.optJSONArray("metadataParts")
            ch = parts?.optJSONObject(0)?.optJSONObject("text")?.optString("content") ?: ""
        }
        val ci = v.optJSONObject("contentImage")
        return Plist(id, title, findBadge(ci), findImg(ci), ch)
    }

    private fun findBadge(n: Any?): String {
        when (n) {
            is JSONObject -> {
                val b = n.optJSONObject("thumbnailBadgeViewModel")
                if (b != null) {
                    val t = b.optString("text")
                    if (t.isNotEmpty()) return t
                }
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = findBadge(n.opt(ks.next()))
                    if (r.isNotEmpty()) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findBadge(n.opt(i))
                if (r.isNotEmpty()) return r
            }
        }
        return ""
    }

    // ---------------------------------------------------------------- stream links

    private class PClient(
        val name: String, val version: String, val id: String, val ua: String,
        val extra: JSONObject.() -> Unit
    )

    private val CLIENTS = listOf(
        PClient("VISIONOS", "1.02", "101", VISION_UA) {
            put("userAgent", "$VISION_UA,gzip(gfe)")
            put("platform", "DESKTOP")
        },
        PClient("ANDROID_VR", "1.60.19", "28", VR_UA) {
            put("userAgent", VR_UA)
            put("deviceMake", "Oculus")
            put("deviceModel", "Quest 3")
            put("osName", "Android")
            put("osVersion", "12L")
            put("androidSdkVersion", 32)
            put("platform", "MOBILE")
        }
    )

    /** YouTube only answers the VISIONOS client when the session already has a visitor id. */
    private fun playVisitorData(): String {
        val fresh = System.currentTimeMillis() - playVisitorAt < 24 * 3600_000L
        if (playVisitor.isNotEmpty() && fresh) return playVisitor
        try {
            val c = JSONObject().put("clientName", "VISIONOS").put("clientVersion", "1.02")
                .put("hl", HL).put("gl", GL).put("userAgent", "$VISION_UA,gzip(gfe)").put("platform", "DESKTOP")
            val r = post(
                "visitor_id", JSONObject().put("context", JSONObject().put("client", c)),
                VISION_UA, "101", "1.02", ""
            )
            val v = r.optJSONObject("responseContext")?.optString("visitorData") ?: ""
            if (v.isNotEmpty()) {
                playVisitor = v
                playVisitorAt = System.currentTimeMillis()
            }
        } catch (e: Exception) {
        }
        if (playVisitor.isEmpty()) { initWeb(); playVisitor = webVisitor }
        return playVisitor
    }

    /**
     * Finds playable file links for a video. [firstClient] rotates the client order
     * (0 = VISIONOS first, 1 = ANDROID_VR first) so a retry can use the other one.
     */
    fun resolve(id: String, firstClient: Int = 0): Stream {
        val visitor = playVisitorData()
        var reason = ""
        for (k in CLIENTS.indices) {
            val c = CLIENTS[(firstClient + k) % CLIENTS.size]
            try {
                val cj = JSONObject().put("clientName", c.name).put("clientVersion", c.version)
                    .put("hl", HL).put("gl", GL)
                c.extra(cj)
                if (visitor.isNotEmpty()) cj.put("visitorData", visitor)
                cj.put("originalUrl", "https://www.youtube.com/watch?v=$id")
                val body = JSONObject()
                    .put("videoId", id)
                    .put("racyCheckOk", true).put("contentCheckOk", true)
                    .put("context", JSONObject().put("client", cj))
                    .put(
                        "playbackContext", JSONObject().put(
                            "contentPlaybackContext", JSONObject().put("html5Preference", "HTML5_PREF_WANTS")
                        )
                    )
                val r = post("player", body, c.ua, c.id, c.version, visitor)
                val ps = r.optJSONObject("playabilityStatus")
                if (ps?.optString("status") != "OK") {
                    reason = ps?.optString("reason").orEmpty().ifEmpty { ps?.optString("status").orEmpty() }
                    continue
                }
                val s = streamFrom(r, c.ua)
                if (s != null) return s
                reason = "No playable stream"
            } catch (e: Exception) {
                reason = e.message ?: reason
            }
        }
        throw RuntimeException(if (reason.isEmpty()) "Video unavailable" else reason)
    }

    private fun streamFrom(r: JSONObject, ua: String): Stream? {
        val sd = r.optJSONObject("streamingData") ?: return null
        val vd = r.optJSONObject("videoDetails")
        val title = vd?.optString("title") ?: ""
        val chId = vd?.optString("channelId") ?: ""
        val author = vd?.optString("author") ?: ""

        var muxed: Fmt? = null
        val f = sd.optJSONArray("formats")
        if (f != null) for (i in 0 until f.length()) {
            val o = f.optJSONObject(i) ?: continue
            val url = o.optString("url")
            if (url.isEmpty() || !o.optString("mimeType").startsWith("video/mp4")) continue
            val fm = Fmt(url, o.optInt("height"), o.optInt("bitrate"), o.optInt("itag"))
            if (muxed == null || fm.height > muxed.height) muxed = fm
        }

        val videos = ArrayList<Fmt>()
        var audio: Fmt? = null
        val a = sd.optJSONArray("adaptiveFormats")
        if (a != null) for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val url = o.optString("url")
            if (url.isEmpty()) continue
            val mime = o.optString("mimeType")
            val fm = Fmt(url, o.optInt("height"), o.optInt("bitrate"), o.optInt("itag"))
            if (mime.startsWith("video/mp4") && mime.contains("avc1")) {
                videos.add(fm)
            } else if (mime.startsWith("audio/mp4")) {
                val track = o.optJSONObject("audioTrack")
                if (track != null && !track.optBoolean("audioIsDefault", true)) continue
                if (audio == null || fm.bitrate > audio.bitrate) audio = fm
            }
        }
        if (muxed == null && (videos.isEmpty() || audio == null)) return null
        return Stream(title, ua, muxed, videos, audio, chId, author)
    }
}
