package com.yttv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * YouTube-style home for TV: search pill, category chips and a video grid.
 * Home mixes "From your subscriptions" and "Because you watched ..." rows (all saved on the TV, no login).
 * Search shows videos + channels, with suggestions while typing.
 * Built in code, no WebView. D-pad: arrows move, OK opens, long OK = small menu.
 */
class MainActivity : ComponentActivity() {

    private class Cat(val key: String, val label: String, val query: String, val filter: String = "EgIQAQ==")

    private val cats = listOf(
        Cat("search", "Search", ""),
        Cat("home", "Home", ""),
        Cat("subs", "Subscriptions", ""),
        Cat("chans", "My Channels", ""),
        Cat("history", "History", ""),
        Cat("account", "Sign in", ""),
        Cat("music", "Music", "new music videos"),
        Cat("gaming", "Gaming", "gaming gameplay"),
        Cat("movies", "Movies", "movie trailers"),
        Cat("news", "News", "latest news today"),
        Cat("sports", "Sports", "sports highlights"),
        Cat("live", "Live", "live", "EgJAAQ=="),
        Cat("learn", "Learning", "learn how to tutorial"),
        Cat("comedy", "Comedy", "comedy videos"),
        Cat("tech", "Tech", "tech reviews")
    )

    private fun cat(key: String): Cat = cats.first { it.key == key }

    // used when the logged-out home feed is empty
    private val homeQueries = listOf(
        "trending today", "new songs", "latest news", "funny videos", "gaming", "movie trailers",
        "cricket highlights", "tech reviews", "cooking recipes", "travel vlog"
    )

    // Vid = video card, Chan = channel card, String = section heading
    private val items = ArrayList<Any>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: FeedAdapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private lateinit var heading: TextView
    private val chipViews = HashMap<String, TextView>()
    private lateinit var searchBar: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var sugRow: LinearLayout
    private var settingText = false
    private var pendingLive: Runnable? = null
    private var signedFeed = false     // current feed comes from the signed-in account
    private var lastSigned = false
    private var finalSearch = false   // true after Search/OK; then "Related searches" fill the chips row

    private var gen = 0
    private var loading = false
    private var exhausted = false
    private var token: String? = null
    private var homeFallback = false
    private var homeIdx = 0
    private var curCat: Cat = cats[1]
    private var curQuery = ""
    private var lastSearch = ""
    private var firstFocusPending = true

    private var cardW = 0
    private var spans = 4

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi()
        UiUtil.immersive(window)
        lastSigned = Auth.signedIn(this)
        updateAccountLabel()
        select(cat("home"))
        handleLink(intent)
        // Back: any other tab -> Home first, Home -> leave the app
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (curCat.key != "home") {
                    hideKeyboard()
                    select(cat("home"))
                    chipViews["home"]?.requestFocus()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** A youtube.com / youtu.be link opened (or shared) into the app plays right away. */
    private fun handleLink(i: Intent?) {
        val u: Uri = i?.data ?: return
        val id = videoIdFrom(u.toString()) ?: return
        i.data = null
        open(Vid(id, "YouTube video"))
    }

    /** Video id from a YouTube link; null if the text is not a link. */
    private fun videoIdFrom(text: String): String? {
        val m = Regex("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})").find(text.trim())
        return m?.groupValues?.get(1)
    }

    override fun onResume() {
        super.onResume()
        // signed in / out in the sign-in screen: reload the account feeds
        val now = Auth.signedIn(this)
        val changed = now != lastSigned
        lastSigned = now
        updateAccountLabel()
        if (now && (Store.accountChans(this).isEmpty() || Store.accountChansAge(this) > 6 * 3600_000L)) {
            val app = applicationContext
            Net.async({ YT.accountChannels(app) }, { list -> if (list.isNotEmpty()) Store.setAccountChans(app, list) }, { })
        }
        // these lists change while watching / subscribing
        val k = curCat.key
        if (changed && (k == "home" || k == "subs" || k == "history" || k == "chans")) {
            select(curCat)
            return
        }
        if (k == "history" || k == "subs" || k == "chans") select(curCat)
    }

    private fun updateAccountLabel() {
        chipViews["account"]?.text = if (Auth.signedIn(this)) "Account \u2713" else "Sign in"
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        val sideW = dp(205)
        spans = if (widthDp - 205 >= 900) 4 else 3
        val pad = dp(20)
        cardW = (dm.widthPixels - sideW - (pad - dp(5)) * 2) / spans - dp(10)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(resources.getColor(R.color.bg))

        // ---- left sidebar (like YouTube on TV): logo + Search / Home / Subscriptions ... + topics
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.setPadding(dp(34), dp(16), dp(10), dp(16))

        val logoRow = LinearLayout(this)
        logoRow.orientation = LinearLayout.HORIZONTAL
        logoRow.gravity = Gravity.CENTER_VERTICAL
        logoRow.setPadding(dp(6), 0, 0, dp(14))
        val logo = TextView(this)
        logo.text = "\u25B6 "
        logo.setTextColor(Color.parseColor("#FF0000"))
        logo.textSize = 26f
        logoRow.addView(logo)
        val logoT = TextView(this)
        logoT.text = "YT TV"
        logoT.setTextColor(Color.WHITE)
        logoT.textSize = 22f
        logoT.setTypeface(null, Typeface.BOLD)
        logoRow.addView(logoT)
        side.addView(logoRow)

        for (c in cats) {
            if (c.key == "music") {
                val lab = TextView(this)
                lab.text = "Explore"
                lab.setTextColor(Color.parseColor("#888888"))
                lab.textSize = 13f
                lab.setPadding(dp(8), dp(16), 0, dp(4))
                side.addView(lab)
            }
            val t = TextView(this)
            t.text = c.label
            t.textSize = 17f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(18), dp(9), dp(18), dp(9))
            t.maxLines = 1
            t.setBackgroundResource(R.drawable.chip_bg)
            t.isFocusable = true
            t.isClickable = true
            t.setOnClickListener { select(c) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            side.addView(t, lp)
            chipViews[c.key] = t
        }
        val exit = TextView(this)
        exit.text = "Exit"
        exit.textSize = 17f
        exit.setTextColor(Color.WHITE)
        exit.setPadding(dp(18), dp(9), dp(18), dp(9))
        exit.maxLines = 1
        exit.setBackgroundResource(R.drawable.chip_bg)
        exit.isFocusable = true
        exit.isClickable = true
        exit.setOnClickListener { finishAffinity() }
        val elp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        elp.topMargin = dp(18)
        side.addView(exit, elp)
        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(side)
        root.addView(sc, LinearLayout.LayoutParams(sideW, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- right side: heading + grid
        val rightCol = LinearLayout(this)
        rightCol.orientation = LinearLayout.VERTICAL

        heading = TextView(this)
        heading.setTextColor(Color.WHITE)
        heading.textSize = 20f
        heading.setTypeface(null, Typeface.BOLD)
        heading.setPadding(pad, dp(14), pad, dp(2))
        heading.maxLines = 1
        heading.ellipsize = TextUtils.TruncateAt.END
        heading.visibility = View.GONE
        rightCol.addView(heading)

        // ---- search bar (shown on the Search tab): box + live suggestion chips
        searchBar = LinearLayout(this)
        searchBar.orientation = LinearLayout.VERTICAL
        searchBar.setPadding(pad, dp(12), pad, dp(2))
        searchBar.visibility = View.GONE
        searchBox = EditText(this)
        searchBox.setSingleLine(true)
        searchBox.hint = "Search YouTube"
        searchBox.setHintTextColor(Color.parseColor("#888888"))
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 20f
        searchBox.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchBox.setPadding(dp(22), dp(10), dp(22), dp(10))
        searchBox.setBackgroundResource(R.drawable.chip_bg)
        searchBar.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val sugScroll = HorizontalScrollView(this)
        sugScroll.isHorizontalScrollBarEnabled = false
        sugRow = LinearLayout(this)
        sugRow.orientation = LinearLayout.HORIZONTAL
        sugScroll.addView(sugRow)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(8)
        searchBar.addView(sugScroll, slp)
        rightCol.addView(searchBar)
        searchBox.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(searchBox.text.toString())
                true
            } else false
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (settingText) return
                finalSearch = false
                pendingLive?.let { Net.main.removeCallbacks(it) }
                val q = s?.toString()?.trim() ?: ""
                if (q.isEmpty()) {
                    showRecents()
                    return
                }
                val r = Runnable {
                    Net.async({ YT.suggest(q) }, { res ->
                        if (searchBox.text.toString().trim() == q) fillSugs(res)
                    })
                    // live results: the grid below follows what is typed
                    if (videoIdFrom(q) == null) {
                        lastSearch = q
                        select(cat("search"), q)
                    }
                }
                pendingLive = r
                Net.main.postDelayed(r, 350)
            }
        })

        val right = FrameLayout(this)
        grid = RecyclerView(this)
        val lm = GridLayoutManager(this, spans)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (position in 0 until items.size && items[position] is String) spans else 1
        }
        grid.layoutManager = lm
        grid.setPadding(pad - dp(5), dp(10), pad - dp(5), pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        adapter = FeedAdapter(
            this, items, cardW, spans * 2,
            { v -> open(v) },
            { v -> videoMenu(v) },
            { c -> openChannel(c.id, c.name) },
            { loadMore() },
            { p -> openPlist(p) }
        )
        grid.adapter = adapter
        right.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.chip_bg)
        message.isFocusable = true
        message.isClickable = true
        message.visibility = View.GONE
        message.setOnClickListener { select(curCat, curQuery) }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        rightCol.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(rightCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        setContentView(root)
    }

    private fun markRail(c: Cat) {
        for ((k, v) in chipViews) {
            val on = k == c.key
            v.isSelected = on
            v.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
    }

    // ------------------------------------------------------------------ feeds

    private fun select(c: Cat, forcedQuery: String? = null) {
        if (c.key == "account") {
            startActivity(Intent(this, SignInActivity::class.java))
            return
        }
        if (c.key == "search" && forcedQuery == null) {
            enterSearch()
            return
        }
        curCat = c
        markRail(c)
        curQuery = when {
            c.key == "search" -> forcedQuery ?: lastSearch
            else -> c.query
        }
        heading.visibility = View.GONE
        if (c.key == "search") {
            searchBar.visibility = View.VISIBLE
        } else {
            searchBar.visibility = View.GONE
            pendingLive?.let { Net.main.removeCallbacks(it) }
            hideKeyboard()
        }
        gen++
        items.clear()
        seen.clear()
        adapter.notifyDataSetChanged()
        token = null
        exhausted = false
        homeFallback = false
        homeIdx = 0
        signedFeed = false
        loading = false
        message.visibility = View.GONE

        if (c.key == "history" && !Auth.signedIn(this)) {
            for (v in Store.history(this)) if (seen.add(v.id)) items.add(v)
            adapter.notifyDataSetChanged()
            exhausted = true
            spinner.visibility = View.GONE
            if (items.isEmpty()) showMessage("Nothing watched yet", false)
            return
        }
        if (c.key == "chans") {
            exhausted = true
            if (Auth.signedIn(this)) {
                // signed in: the channels of the real account (cached copy first, then refreshed from YouTube)
                val shown = Store.accountChans(this).ifEmpty { Store.subs(this) }
                for (ch in shown) items.add(ch)
                adapter.notifyDataSetChanged()
                // fresh copy (e.g. just back from the player): no need to download the whole list again
                if (items.isNotEmpty() && Store.accountChansAge(this) < 10 * 60_000L) {
                    spinner.visibility = View.GONE
                    return
                }
                spinner.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                val g = gen
                val app = applicationContext
                Net.async({ YT.accountChannels(app) }, { list ->
                    if (list.isNotEmpty()) Store.setAccountChans(app, list)
                    if (g == gen && curCat.key == "chans") {
                        spinner.visibility = View.GONE
                        if (list.isNotEmpty() && list.map { it.id } != items.filterIsInstance<Chan>().map { it.id }) {
                            items.clear()
                            items.addAll(list)
                            adapter.notifyDataSetChanged()
                        }
                        if (items.isEmpty()) showMessage("No subscribed channels on this account", false)
                    }
                }, { e ->
                    if (g == gen && curCat.key == "chans") {
                        spinner.visibility = View.GONE
                        if (items.isEmpty()) showMessage("Could not load channels\n(${e.message})\n\nPress OK to retry", true)
                    }
                })
                return
            }
            for (ch in Store.subs(this)) items.add(ch)
            adapter.notifyDataSetChanged()
            spinner.visibility = View.GONE
            if (items.isEmpty()) showMessage("No channels yet\nOpen a channel and press Subscribe", false)
            return
        }
        if (c.key == "subs" && Store.subs(this).isEmpty() && !Auth.signedIn(this)) {
            exhausted = true
            spinner.visibility = View.GONE
            showMessage("No subscriptions yet\nSearch a channel, open it and press Subscribe", false)
            return
        }
        loadMore()
    }

    /** Search tab: show the box (with the last search), recent searches as chips, open the keyboard. */
    private fun enterSearch() {
        val sc = cat("search")
        curCat = sc
        markRail(sc)
        heading.visibility = View.GONE
        searchBar.visibility = View.VISIBLE
        settingText = true
        searchBox.setText(lastSearch)
        searchBox.setSelection(searchBox.text.length)
        settingText = false
        if (lastSearch.isNotEmpty()) {
            select(sc, lastSearch)
        } else {
            gen++
            items.clear()
            seen.clear()
            adapter.notifyDataSetChanged()
            loading = false
            exhausted = true
            spinner.visibility = View.GONE
            message.visibility = View.GONE
        }
        showRecents()
        searchBox.requestFocus()
        showKeyboard()
    }

    private fun showRecents() = fillSugs(Store.recents(this))

    /** "Related searches": from the results page if YouTube sent them, else search suggestions. */
    private fun showRelated(rel: List<String>, q: String) {
        if (rel.isNotEmpty()) {
            fillSugs(rel, "Related searches")
        } else {
            Net.async({ YT.suggest(q) }, { res ->
                if (finalSearch && curCat.key == "search" && curQuery == q) fillSugs(res.filter { !it.equals(q, true) }, "Related searches")
            })
        }
    }

    private fun fillSugs(l: List<String>, label: String? = null) {
        sugRow.removeAllViews()
        if (label != null && l.isNotEmpty()) {
            val lab = TextView(this)
            lab.text = label
            lab.textSize = 14f
            lab.setTextColor(Color.parseColor("#AAAAAA"))
            lab.gravity = Gravity.CENTER_VERTICAL
            lab.setPadding(dp(4), 0, dp(12), 0)
            sugRow.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        for (q in l.take(8)) {
            val t = TextView(this)
            t.text = q
            t.textSize = 16f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(18), dp(7), dp(18), dp(7))
            t.maxLines = 1
            t.setBackgroundResource(R.drawable.chip_bg)
            t.isFocusable = true
            t.isClickable = true
            t.setOnClickListener { doSearch(q) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            sugRow.addView(t, lp)
        }
    }

    private fun showKeyboard() {
        searchBox.post {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun hideKeyboard() {
        if (!::searchBox.isInitialized) return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        val id = videoIdFrom(query)
        if (id != null) {
            open(Vid(id, "YouTube video"))
            return
        }
        pendingLive?.let { Net.main.removeCallbacks(it) }
        finalSearch = true
        lastSearch = query
        Store.addRecent(this, query)
        settingText = true
        searchBox.setText(query)
        searchBox.setSelection(searchBox.text.length)
        settingText = false
        hideKeyboard()
        firstFocusPending = true
        select(cat("search"), query)
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val g = gen
        val cat = curCat
        val q = curQuery
        val tok = token
        val fb = homeFallback
        val idx = homeIdx
        val sf = signedFeed
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({
            fetch(cat, q, tok, fb, idx, sf)
        }, { r ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                token = r.token
                homeFallback = r.fallback
                homeIdx = r.idx
                signedFeed = r.signed
                exhausted = r.done
                val start = items.size
                for (x in r.items) {
                    val ok = when (x) {
                        is Vid -> seen.add(x.id)
                        is Chan -> seen.add("c:" + x.id)
                        is Plist -> seen.add("p:" + x.id)
                        else -> true
                    }
                    if (ok) items.add(x)
                }
                if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                if (cat.key == "search" && start == 0 && finalSearch) showRelated(r.related, q)
                if (items.isEmpty()) {
                    if (exhausted) showMessage("No videos found", false) else loadMore()
                } else if (firstFocusPending) {
                    firstFocusPending = false
                    grid.post { focusFirstCard() }
                }
            }
        }, { e ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMessage("Could not load videos\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private fun focusFirstCard() {
        for (i in 0 until grid.childCount) {
            val c = grid.getChildAt(i)
            if (c.isFocusable && c.requestFocus()) return
        }
    }

    private class Result(
        val items: List<Any>, val token: String?, val fallback: Boolean, val idx: Int, val done: Boolean,
        val related: List<String> = emptyList(), val signed: Boolean = false
    )

    /** Runs on a background thread. */
    private fun fetch(cat: Cat, q: String, tok: String?, fallback: Boolean, idx: Int, sf: Boolean): Result {
        // signed in: Home = your recommendations, Subscriptions / History = your account
        val k = cat.key
        if ((k == "home" || k == "subs" || k == "history") && Auth.signedIn(this) && (sf || tok == null)) {
            val id = when (k) {
                "home" -> "default"
                "subs" -> "FEsubscriptions"
                else -> "FEhistory"
            }
            try {
                val p = YT.tvBrowse(this, id, if (sf) tok else null)
                if (p.mixed.isNotEmpty() || sf) return Result(p.mixed, p.token, false, 0, p.token == null, p.related, true)
            } catch (e: Exception) {
                if (sf) throw e
                // first page failed: fall through to the normal (not signed in) feed
            }
        }
        if (k == "history") return Result(Store.history(this), null, false, 0, true)
        if (cat.key == "home") return fetchHome(tok, fallback, idx)
        if (cat.key == "subs") {
            val vids = subsVideos(Store.subs(this).take(20), 6)
            return Result(vids, null, false, 0, true)
        }
        // "search" has no filter: videos AND channels come back mixed, like on YouTube
        val p = YT.search(q, tok, if (cat.key == "search") "" else cat.filter)
        return Result(p.mixed, p.token, false, 0, p.token == null, p.related)
    }

    private fun fetchHome(tok: String?, fallback: Boolean, idx: Int): Result {
        val first = tok == null && !fallback && idx == 0
        val personal: List<Any> = if (first) {
            try { personalBlock() } catch (e: Exception) { emptyList() }
        } else emptyList()
        val feed = try {
            homeFeed(tok, fallback, idx)
        } catch (e: Exception) {
            if (personal.isEmpty()) throw e
            return Result(personal, null, false, 0, true)
        }
        if (personal.isEmpty()) return feed
        val all = ArrayList<Any>(personal)
        all.add("More to explore")
        all.addAll(feed.items)
        return Result(all, feed.token, feed.fallback, feed.idx, feed.done)
    }

    private fun homeFeed(tok: String?, fallback: Boolean, idx: Int): Result {
        var fb = fallback
        var i = idx
        if (!fb) {
            val p = YT.home(tok)
            if (tok != null || p.items.size >= 8) return Result(p.mixed, p.token, false, 0, p.token == null)
            fb = true // logged-out home was (almost) empty
        }
        val p = YT.search(homeQueries[i], null)
        i++
        return Result(p.mixed, null, true, i, i >= homeQueries.size)
    }

    /** Runs the tasks in parallel (max 9 s). One list per task, empty if it failed. */
    private fun runAll(tasks: List<Callable<List<Vid>>>): List<List<Vid>> {
        if (tasks.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(4)
        try {
            return pool.invokeAll(tasks, 9, TimeUnit.SECONDS).map { f ->
                try {
                    if (f.isCancelled) emptyList<Vid>() else f.get()
                } catch (e: Exception) {
                    emptyList<Vid>()
                }
            }
        } finally {
            pool.shutdownNow()
        }
    }

    private fun channelTask(ch: Chan, per: Int): Callable<List<Vid>> = Callable<List<Vid>> {
        try {
            YT.channel(ch.id, null, ch.name).page.items.take(per)
        } catch (e: Exception) {
            emptyList<Vid>()
        }
    }

    /** Newest videos of the subscribed channels, freshest first. */
    private fun subsVideos(subs: List<Chan>, per: Int): List<Vid> {
        val res = runAll(subs.map { channelTask(it, per) })
        val all = ArrayList<Vid>()
        for (l in res) all.addAll(l)
        return all.distinctBy { it.id }.sortedBy { ageMinutes(it.meta) }
    }

    /** Home rows built from what this TV saved: subscriptions + "because you watched". */
    private fun personalBlock(): List<Any> {
        val subs = Store.subs(this).take(8)
        val hist = Store.history(this)
        val seeds = hist.filter { it.title != "YouTube video" }.take(2)
        if (subs.isEmpty() && seeds.isEmpty()) return emptyList()
        val watched = HashSet<String>()
        for (h in hist) watched.add(h.id)

        val tasks = ArrayList<Callable<List<Vid>>>()
        for (ch in subs) tasks.add(channelTask(ch, 5))
        for (v in seeds) {
            tasks.add(Callable<List<Vid>> {
                try {
                    YT.related(v.id).take(8)
                } catch (e: Exception) {
                    emptyList<Vid>()
                }
            })
        }
        val res = runAll(tasks)

        val out = ArrayList<Any>()
        val used = HashSet<String>()

        val subVids = ArrayList<Vid>()
        for (i in subs.indices) if (i < res.size) subVids.addAll(res[i])
        val fresh = subVids.filter { it.id !in watched }
            .distinctBy { it.id }
            .sortedBy { ageMinutes(it.meta) }
            .take(12)
        if (fresh.isNotEmpty()) {
            out.add("From your subscriptions")
            for (v in fresh) {
                used.add(v.id)
                out.add(v)
            }
        }
        for ((k, seed) in seeds.withIndex()) {
            val at = subs.size + k
            if (at >= res.size) continue
            val r = res[at].filter { it.id !in watched && it.id !in used }.take(4)
            if (r.isNotEmpty()) {
                out.add("Because you watched " + seed.title)
                for (v in r) {
                    used.add(v.id)
                    out.add(v)
                }
            }
        }
        return out
    }

    private fun showMessage(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    // ------------------------------------------------------------------ actions

    private fun open(v: Vid) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        startActivity(i)
    }

    private fun openPlist(p: Plist) {
        val i = Intent(this, PlaylistActivity::class.java)
        i.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        i.putExtra(PlaylistActivity.EXTRA_TITLE, p.title)
        startActivity(i)
    }

    private fun openChannel(id: String, name: String) {
        if (id.isEmpty()) return
        val i = Intent(this, ChannelActivity::class.java)
        i.putExtra(ChannelActivity.EXTRA_ID, id)
        i.putExtra(ChannelActivity.EXTRA_NAME, name)
        startActivity(i)
    }

    /** Long press on a video card: Play / Go to channel / Subscribe. */
    private fun videoMenu(v: Vid) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("Play")
        acts.add { open(v) }
        if (v.channelId.isNotEmpty()) {
            labels.add("Go to channel: " + v.channel)
            acts.add { openChannel(v.channelId, v.channel) }
            labels.add(if (Store.isSub(this, v.channelId)) "Unsubscribe" else "Subscribe")
            acts.add {
                val now = Store.toggleSub(this, Chan(v.channelId, v.channel))
                Toast.makeText(this, if (now) "Subscribed: ${v.channel}" else "Unsubscribed: ${v.channel}", Toast.LENGTH_SHORT).show()
            }
        }
        AlertDialog.Builder(this)
            .setTitle(v.title)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }
}
