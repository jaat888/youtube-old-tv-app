package com.yttv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * YouTube-style home for TV: left menu (Home, Search, topics, History) + video grid on the right.
 * Everything is built in code, no WebView. D-pad: Left/Right moves between menu and grid, OK opens.
 */
class MainActivity : ComponentActivity() {

    private class Cat(val key: String, val label: String, val query: String, val filter: String = "EgIQAQ==")

    private val cats = listOf(
        Cat("home", "Home", ""),
        Cat("search", "Search", ""),
        Cat("music", "Music", "new music videos"),
        Cat("gaming", "Gaming", "gaming gameplay"),
        Cat("movies", "Movies", "movie trailers"),
        Cat("news", "News", "latest news today"),
        Cat("sports", "Sports", "sports highlights"),
        Cat("live", "Live", "live", "EgJAAQ=="),
        Cat("learn", "Learning", "learn how to tutorial"),
        Cat("comedy", "Comedy", "comedy videos"),
        Cat("tech", "Tech", "tech reviews"),
        Cat("history", "History", "")
    )

    // used when the logged-out home feed is empty
    private val homeQueries = listOf(
        "trending today", "new songs", "latest news", "funny videos", "gaming", "movie trailers",
        "cricket highlights", "tech reviews", "cooking recipes", "travel vlog"
    )

    private val items = ArrayList<Vid>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: Adapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private lateinit var heading: TextView
    private val railViews = ArrayList<TextView>()

    private var gen = 0
    private var loading = false
    private var exhausted = false
    private var token: String? = null
    private var homeFallback = false
    private var homeIdx = 0
    private var curCat: Cat = cats[0]
    private var curQuery = ""
    private var lastSearch = ""
    private var firstFocusPending = true

    private var cardW = 0
    private var spans = 4

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi()
        select(cats[0])
    }

    override fun onResume() {
        super.onResume()
        // History changes while watching
        if (curCat.key == "history") select(curCat)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        spans = if (widthDp >= 1000) 4 else 3

        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(resources.getColor(R.color.bg))

        // ---- left menu
        val railW = dp(210)
        val rail = LinearLayout(this)
        rail.orientation = LinearLayout.VERTICAL
        rail.setPadding(dp(14), dp(18), dp(10), dp(10))
        rail.setBackgroundColor(Color.parseColor("#141414"))

        val logo = TextView(this)
        logo.text = "▶ YT TV"
        logo.setTextColor(Color.WHITE)
        logo.textSize = 24f
        logo.setTypeface(null, Typeface.BOLD)
        logo.setPadding(dp(8), 0, 0, dp(14))
        rail.addView(logo)

        val scroll = android.widget.ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        for (c in cats) {
            val t = TextView(this)
            t.text = c.label
            t.textSize = 18f
            t.setTextColor(Color.parseColor("#CCCCCC"))
            t.setPadding(dp(16), dp(10), dp(12), dp(10))
            t.setBackgroundResource(R.drawable.rail_bg)
            t.isFocusable = true
            t.isClickable = true
            t.setOnClickListener { select(c) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(4)
            col.addView(t, lp)
            railViews.add(t)
        }
        scroll.addView(col)
        rail.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(rail, LinearLayout.LayoutParams(railW, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- right side
        val right = FrameLayout(this)
        val pad = dp(18)

        val pane = LinearLayout(this)
        pane.orientation = LinearLayout.VERTICAL
        heading = TextView(this)
        heading.setTextColor(Color.WHITE)
        heading.textSize = 22f
        heading.setTypeface(null, Typeface.BOLD)
        heading.setPadding(pad + dp(6), dp(14), pad, dp(6))
        heading.maxLines = 1
        heading.ellipsize = TextUtils.TruncateAt.END
        pane.addView(heading)

        grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, spans)
        grid.setPadding(pad, 0, pad, pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        grid.setHasFixedSize(false)
        adapter = Adapter()
        grid.adapter = adapter
        pane.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        right.addView(pane, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.rail_bg)
        message.isFocusable = true
        message.isClickable = true
        message.visibility = View.GONE
        message.setOnClickListener { select(curCat, curQuery) }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        setContentView(root)

        val gridW = dm.widthPixels - railW - pad * 2
        cardW = gridW / spans - dp(10)
    }

    private fun markRail(c: Cat) {
        for (i in cats.indices) {
            val on = cats[i].key == c.key
            railViews[i].setTextColor(if (on) Color.WHITE else Color.parseColor("#BBBBBB"))
            railViews[i].setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    // ------------------------------------------------------------------ feeds

    private fun select(c: Cat, forcedQuery: String? = null) {
        if (c.key == "search" && forcedQuery == null) {
            askSearch()
            return
        }
        curCat = c
        markRail(c)
        curQuery = when {
            c.key == "search" -> forcedQuery ?: lastSearch
            else -> c.query
        }
        heading.text = when (c.key) {
            "search" -> "Results for \"$curQuery\""
            "home" -> "Recommended"
            else -> c.label
        }
        gen++
        items.clear()
        seen.clear()
        adapter.notifyDataSetChanged()
        token = null
        exhausted = false
        homeFallback = false
        homeIdx = 0
        loading = false
        message.visibility = View.GONE

        if (c.key == "history") {
            val h = Store.history(this)
            for (v in h) if (seen.add(v.id)) items.add(v)
            adapter.notifyDataSetChanged()
            exhausted = true
            spinner.visibility = View.GONE
            if (items.isEmpty()) showMessage("Nothing watched yet", false)
            return
        }
        loadMore()
    }

    private fun askSearch() {
        val et = EditText(this)
        et.setText(lastSearch)
        et.setSelection(et.text.length)
        et.setSingleLine(true)
        et.imeOptions = EditorInfo.IME_ACTION_SEARCH
        et.hint = "Type here"
        val dlg = AlertDialog.Builder(this)
            .setTitle("Search YouTube")
            .setView(et)
            .setPositiveButton("Search") { _, _ -> doSearch(et.text.toString()) }
            .setNegativeButton("Cancel", null)
            .create()
        et.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                dlg.dismiss()
                doSearch(et.text.toString())
                true
            } else false
        }
        dlg.show()
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        lastSearch = query
        select(cats[1], query)
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val g = gen
        val cat = curCat
        val q = curQuery
        val tok = token
        val fb = homeFallback
        val idx = homeIdx
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({
            fetch(cat, q, tok, fb, idx)
        }, { r ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                token = r.token
                homeFallback = r.fallback
                homeIdx = r.idx
                exhausted = r.done
                val start = items.size
                for (v in r.items) if (seen.add(v.id)) items.add(v)
                if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                if (items.isEmpty()) {
                    if (exhausted) showMessage("No videos found", false) else loadMore()
                } else if (firstFocusPending) {
                    firstFocusPending = false
                    grid.post { grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
                }
            }
        }, { e ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMessage("Could not load videos\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private class Result(val items: List<Vid>, val token: String?, val fallback: Boolean, val idx: Int, val done: Boolean)

    /** Runs on a background thread. */
    private fun fetch(cat: Cat, q: String, tok: String?, fallback: Boolean, idx: Int): Result {
        if (cat.key == "home") {
            var fb = fallback
            var i = idx
            if (!fb) {
                val p = YT.home(tok)
                if (tok != null || p.items.size >= 8) return Result(p.items, p.token, false, 0, p.token == null)
                fb = true // logged-out home was (almost) empty
            }
            val p = YT.search(homeQueries[i], null)
            i++
            return Result(p.items, null, true, i, i >= homeQueries.size)
        }
        val p = YT.search(q, tok, cat.filter)
        return Result(p.items, p.token, false, 0, p.token == null)
    }

    private fun showMessage(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    private fun open(v: Vid) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        startActivity(i)
    }

    // ------------------------------------------------------------------ grid

    private class VH(
        view: View, val img: ImageView, val dur: TextView, val title: TextView, val sub: TextView
    ) : RecyclerView.ViewHolder(view)

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(this@MainActivity)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(5), dp(5), dp(5), dp(8))
            card.setBackgroundResource(R.drawable.card_bg)
            card.isFocusable = true
            card.isClickable = true

            val thumbH = cardW * 9 / 16
            val fl = FrameLayout(this@MainActivity)
            val img = ImageView(this@MainActivity)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(Color.parseColor("#222222"))
            fl.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val dur = TextView(this@MainActivity)
            dur.setTextColor(Color.WHITE)
            dur.textSize = 12f
            dur.setTypeface(null, Typeface.BOLD)
            dur.setBackgroundColor(Color.parseColor("#CC000000"))
            dur.setPadding(dp(5), dp(1), dp(5), dp(1))
            val dlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
            dlp.setMargins(0, 0, dp(6), dp(6))
            fl.addView(dur, dlp)
            card.addView(fl, LinearLayout.LayoutParams(cardW, thumbH))

            val title = TextView(this@MainActivity)
            title.setTextColor(Color.WHITE)
            title.textSize = 15f
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            title.setPadding(dp(2), dp(8), dp(2), 0)
            card.addView(title, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

            val sub = TextView(this@MainActivity)
            sub.setTextColor(Color.parseColor("#AAAAAA"))
            sub.textSize = 12f
            sub.maxLines = 2
            sub.ellipsize = TextUtils.TruncateAt.END
            sub.setPadding(dp(2), dp(2), dp(2), 0)
            card.addView(sub, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))

            card.layoutParams = RecyclerView.LayoutParams(cardW + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT)
            return VH(card, img, dur, title, sub)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val v = items[position]
            h.title.text = v.title
            h.sub.text = listOf(v.channel, v.meta).filter { it.isNotEmpty() }.joinToString("\n")
            h.dur.text = v.dur
            h.dur.visibility = if (v.dur.isEmpty()) View.GONE else View.VISIBLE
            Img.load(h.img, v.thumb, cardW)
            h.itemView.setOnClickListener { open(v) }
            if (position >= items.size - spans * 2) grid.post { loadMore() }
        }
    }
}
