package com.yttv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.animation.ValueAnimator
import android.view.Gravity
import android.view.KeyEvent
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * YouTube-style home for TV: search pill, category chips and a video grid.
 * Home mixes "From your subscriptions" and "Because you watched ..." rows (all saved on the TV, no login).
 * Search shows videos + channels, with suggestions while typing.
 * Built in code, no WebView. D-pad: arrows move, OK opens, long OK = small menu.
 */
class MainActivity : ComponentActivity() {

    private class Cat(val key: String, val label: String, val query: String, val filter: String = "EgIQAQ==")

    private val cats = listOf(
        Cat("search", "Search", ""),
        Cat("home", "Home", ""),
        Cat("subs", "Subscriptions", ""),
        Cat("chans", "My Channels", ""),
        Cat("history", "History", ""),
        Cat("watchlater", "Watch later", ""),
        Cat("liked", "Liked videos", ""),
        Cat("playlists", "Playlists", ""),
        Cat("account", "Sign in", ""),
        Cat("music", "Music", "new music videos"),
        Cat("gaming", "Gaming", "gaming gameplay"),
        Cat("movies", "Movies", "movie trailers"),
        Cat("news", "News", "latest news today"),
        Cat("sports", "Sports", "sports highlights"),
        Cat("live", "Live", "live", "EgJAAQ=="),
        Cat("learn", "Learning", "learn how to tutorial"),
        Cat("comedy", "Comedy", "comedy videos"),
        Cat("tech", "Tech", "tech reviews")
    )

    private fun cat(key: String): Cat = cats.first { it.key == key }

    // the account's Library, same ids YouTube on TV uses
    private val libraryIds = mapOf("watchlater" to "VLWL", "liked" to "VLLL", "playlists" to "FEplaylist_aggregation")

    // used when the logged-out home feed is empty
    private val homeQueries = listOf(
        "trending today", "new songs", "latest news", "funny videos", "gaming", "movie trailers",
        "cricket highlights", "tech reviews", "cooking recipes", "travel vlog"
    )

    // Vid = video card, Chan = channel card, String = section heading
    private val items = ArrayList<Any>()
    private val seen = HashSet<String>()
    private lateinit var grid: RecyclerView
    private lateinit var adapter: FeedAdapter
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private lateinit var heading: TextView
    private val chipViews = HashMap<String, View>()        // the focusable rail rows, by tab key
    private val labelViews = HashMap<String, TextView>()   // their text (hidden while the rail is thin)
    private val iconViews = HashMap<String, ImageView>()
    private val railFade = ArrayList<View>()               // faded in when the rail opens
    private lateinit var rail: ScrollView
    private lateinit var shade: View
    private var railColW = 0
    private var railExpW = 0
    private var railFrac = 0f
    private var railTarget = 0f
    private var railAnim: ValueAnimator? = null
    private var lastGridPos = -1
    private var restorePos = -1       // after coming back from the player: card to focus again
    private lateinit var searchBar: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var sugRow: LinearLayout
    private var settingText = false
    private var pendingLive: Runnable? = null
    private var signedFeed = false     // current feed comes from the signed-in account
    private var lastSigned = false
    private var finalSearch = false   // true after Search/OK; then "Related searches" fill the chips row

    private var gen = 0
    private var loading = false
    private var exhausted = false
    private var token: String? = null
    private var homeFallback = false
    private var homeIdx = 0
    private var curCat: Cat = cats[1]
    private var curQuery = ""
    private var lastSearch = ""
    private var firstFocusPending = true

    private var cardW = 0
    private var spans = 4

    // Home + Search are shown as horizontal rows (Android TV style); the other tabs stay a grid
    private val rowData = ArrayList<FeedRow>()
    private lateinit var rowsAdapter: RowsAdapter
    private lateinit var gridLm: GridLayoutManager
    private lateinit var rowsLm: LinearLayoutManager
    private var rowsMode = false
    private var lastRowFocus = -1               // row the focus is on (rows mode)
    private var lastKeyAt = 0L                  // last remote key press (to spot focus jumps nobody asked for)
    private var sectionMode = false             // this feed has titled shelves
    private var pendingTitle: String? = null    // title waiting for the first video of its shelf
    private var lastCard: View? = null          // card that had focus last (to come back to from the rail)
    private val ROW_MAX = 12
    private var sectionRow: FeedRow? = null     // row that a heading (String) opened
    private val kindRow = HashMap<String, FeedRow>()   // open row per kind: v / c / p

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Img.init(applicationContext)
        window.setBackgroundDrawableResource(R.color.bg)
        buildUi()
        UiUtil.immersive(window)
        lastSigned = Auth.signedIn(this)
        updateAccountLabel()
        select(cat("home"))
        handleLink(intent)
        // Back: any other tab -> Home first, Home -> leave the app
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val f = currentFocus
                val inRail = f != null && isInside(f, rail)
                if (curCat.key != "home") {
                    // any other tab: Back goes to Home
                    hideKeyboard()
                    select(cat("home"))
                    chipViews["home"]?.requestFocus()
                } else if (!inRail) {
                    // Home: first Back opens the rail, second Back leaves the app
                    chipViews["home"]?.requestFocus()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** A youtube.com / youtu.be link opened (or shared) into the app plays right away. */
    private fun handleLink(i: Intent?) {
        val u: Uri = i?.data ?: return
        val id = videoIdFrom(u.toString()) ?: return
        i.data = null
        open(Vid(id, "YouTube video"))
    }

    /** Video id from a YouTube link; null if the text is not a link. */
    private fun videoIdFrom(text: String): String? {
        val m = Regex("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})").find(text.trim())
        return m?.groupValues?.get(1)
    }

    override fun onResume() {
        super.onResume()
        // back from the player: cards show the new "watched" bars
        if (rowsMode) for (r in rowData) {
            val a = r.adapter
            if (a != null && r.items.isNotEmpty()) a.notifyItemRangeChanged(0, r.items.size)
        }
        // signed in / out in the sign-in screen: reload the account feeds
        val now = Auth.signedIn(this)
        val changed = now != lastSigned
        lastSigned = now
        updateAccountLabel()
        if (now && (Store.accountChans(this).isEmpty() || Store.accountChansAge(this) > 6 * 3600_000L)) {
            val app = applicationContext
            Net.async({ YT.accountChannels(app) }, { list -> if (list.isNotEmpty()) Store.setAccountChans(app, list) }, { })
        }
        // these lists change while watching / subscribing
        val k = curCat.key
        if (changed && (k == "home" || k == "subs" || k == "history" || k == "chans")) {
            select(curCat)
            return
        }
        if (k == "history" || k == "subs" || k == "chans" || k == "watchlater" || k == "liked") {
            // these lists are reloaded when we come back: keep the card you were on
            val keep = lastGridPos
            select(curCat)
            restorePos = keep
            applyRestore()
        }
    }

    /** Put focus back on the card the person was on (after the list has been reloaded). */
    private fun applyRestore() {
        val want = restorePos
        if (want < 0 || items.isEmpty()) return
        restorePos = -1
        val f = currentFocus
        if (f != null && isInside(f, rail)) return
        if (rowsMode) {
            // want = the row you were on
            val p = want.coerceIn(0, maxOf(0, rowData.size - 1))
            if (rowData.isEmpty()) return
            rowsLm.scrollToPositionWithOffset(p, 0)
            grid.postDelayed({ grid.findViewHolderForAdapterPosition(p)?.itemView?.requestFocus() }, 100)
            return
        }
        val p = want.coerceAtMost(items.size - 1)
        (grid.layoutManager as GridLayoutManager).scrollToPositionWithOffset(p, 0)
        UiUtil.focusCard(grid, p, spans)
    }

    private fun updateAccountLabel() {
        labelViews["account"]?.text = if (Auth.signedIn(this)) "Account \u2713" else "Sign in"
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        railColW = dp(76)
        railExpW = dp(220)
        spans = 3   // big YouTube-TV-like cards
        val pad = dp(20)
        cardW = (dm.widthPixels - railColW - (pad - dp(5)) * 2) / spans - dp(10)

        val root = FrameLayout(this)
        root.setBackgroundColor(resources.getColor(R.color.bg))

        // ---- left rail (like YouTube on TV): thin, icons only. It opens over the videos while it has
        //      focus (names appear) and closes again when focus goes back to the videos.
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.setPadding(dp(8), dp(16), dp(8), dp(16))

        val logoRow = LinearLayout(this)
        logoRow.orientation = LinearLayout.HORIZONTAL
        logoRow.gravity = Gravity.CENTER_VERTICAL
        logoRow.setPadding(dp(18), 0, 0, dp(14))
        val logo = TextView(this)
        logo.text = "\u25B6"
        logo.setTextColor(Color.parseColor("#FF0000"))
        logo.textSize = 24f
        logoRow.addView(logo, LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.WRAP_CONTENT))
        val logoT = TextView(this)
        logoT.text = "YT TV"
        logoT.setTextColor(Color.WHITE)
        logoT.textSize = 22f
        logoT.setTypeface(null, Typeface.BOLD)
        logoT.maxLines = 1
        val llp = LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.WRAP_CONTENT)
        llp.leftMargin = dp(14)
        logoRow.addView(logoT, llp)
        railFade.add(logoT)
        side.addView(logoRow)

        val navIcons = mapOf(
            "search" to R.drawable.ic_nav_search, "home" to R.drawable.ic_nav_home,
            "subs" to R.drawable.ic_nav_subs, "chans" to R.drawable.ic_nav_chans,
            "history" to R.drawable.ic_nav_history, "account" to R.drawable.ic_nav_account,
            "watchlater" to R.drawable.ic_nav_history, "liked" to R.drawable.ic_nav_movies,
            "playlists" to R.drawable.ic_nav_chans,
            "music" to R.drawable.ic_nav_music, "gaming" to R.drawable.ic_nav_gaming,
            "movies" to R.drawable.ic_nav_movies, "news" to R.drawable.ic_nav_news,
            "sports" to R.drawable.ic_nav_sports, "live" to R.drawable.ic_nav_live,
            "learn" to R.drawable.ic_nav_learn, "comedy" to R.drawable.ic_nav_comedy,
            "tech" to R.drawable.ic_nav_tech
        )
        for (c in cats) {
            if (c.key == "music") {
                val line = View(this)
                line.setBackgroundColor(Color.parseColor("#2E2E2E"))
                val lnl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
                lnl.setMargins(dp(10), dp(8), dp(10), dp(4))
                side.addView(line, lnl)
                val lab = TextView(this)
                lab.text = "Explore"
                lab.setTextColor(Color.parseColor("#888888"))
                lab.textSize = 13f
                lab.setPadding(dp(8), dp(4), 0, dp(4))
                side.addView(lab)
                railFade.add(lab)
            }
            val row = railRow(c.label, navIcons[c.key] ?: R.drawable.ic_nav_home) { select(c) }
            chipViews[c.key] = row.first
            iconViews[c.key] = row.second
            labelViews[c.key] = row.third
            side.addView(row.first, railRowLp())
        }
        val ex = railRow("Exit", R.drawable.ic_nav_exit) { finishAffinity() }
        val elp = railRowLp()
        elp.topMargin = dp(18)
        side.addView(ex.first, elp)

        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.setBackgroundColor(resources.getColor(R.color.bg))
        sc.addView(side)
        rail = sc
        shade = View(this)
        shade.setBackgroundResource(R.drawable.rail_shade)

        // ---- right side: heading + grid
        val rightCol = LinearLayout(this)
        rightCol.orientation = LinearLayout.VERTICAL

        heading = TextView(this)
        heading.setTextColor(Color.WHITE)
        heading.textSize = 20f
        heading.setTypeface(null, Typeface.BOLD)
        heading.setPadding(pad, dp(14), pad, dp(2))
        heading.maxLines = 1
        heading.ellipsize = TextUtils.TruncateAt.END
        heading.visibility = View.GONE
        rightCol.addView(heading)

        // ---- search bar (shown on the Search tab): box + live suggestion chips
        searchBar = LinearLayout(this)
        searchBar.orientation = LinearLayout.VERTICAL
        searchBar.setPadding(pad, dp(12), pad, dp(2))
        searchBar.visibility = View.GONE
        searchBox = EditText(this)
        searchBox.setSingleLine(true)
        searchBox.hint = "Search YouTube"
        searchBox.setHintTextColor(Color.parseColor("#888888"))
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 20f
        searchBox.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchBox.setPadding(dp(22), dp(10), dp(22), dp(10))
        searchBox.setBackgroundResource(R.drawable.chip_bg)
        searchBar.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val sugScroll = HorizontalScrollView(this)
        sugScroll.isHorizontalScrollBarEnabled = false
        sugRow = LinearLayout(this)
        sugRow.orientation = LinearLayout.HORIZONTAL
        sugScroll.addView(sugRow)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(8)
        searchBar.addView(sugScroll, slp)
        rightCol.addView(searchBar)
        searchBox.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(searchBox.text.toString())
                true
            } else false
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (settingText) return
                finalSearch = false
                pendingLive?.let { Net.main.removeCallbacks(it) }
                val q = s?.toString()?.trim() ?: ""
                if (q.isEmpty()) {
                    showRecents()
                    return
                }
                val r = Runnable {
                    Net.async({ YT.suggest(q) }, { res ->
                        if (searchBox.text.toString().trim() == q) fillSugs(res)
                    })
                    // live results: the grid below follows what is typed
                    if (videoIdFrom(q) == null) {
                        lastSearch = q
                        select(cat("search"), q)
                    }
                }
                pendingLive = r
                Net.main.postDelayed(r, 350)
            }
        })

        val right = FrameLayout(this)
        grid = RecyclerView(this)
        val lm = GridLayoutManager(this, spans)
        gridLm = lm
        rowsLm = LinearLayoutManager(this)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (position in 0 until items.size && items[position] is String) spans else 1
        }
        grid.layoutManager = lm
        grid.setPadding(pad - dp(5), dp(10), pad - dp(5), pad)
        grid.clipToPadding = false
        grid.itemAnimator = null
        grid.setHasFixedSize(true)       // new rows must not re-layout the whole list (focus used to jump)
        grid.setItemViewCacheSize(6)
        adapter = FeedAdapter(
            this, items, cardW, spans * 2,
            { v -> open(v) },
            { v -> videoMenu(v) },
            { c -> openChannel(c.id, c.name) },
            { loadMore() },
            { p -> openPlist(p) }
        )
        grid.adapter = adapter
        rowsAdapter = RowsAdapter(
            this, rowData, (cardW * 0.88f).toInt(),
            { v -> open(v) },
            { v -> videoMenu(v) },
            { c -> openChannel(c.id, c.name) },
            { p -> openPlist(p) },
            { row -> rowEnd(row) }
        )
        grid.clipChildren = false
        grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) { checkMoreRows() }
        })
        right.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spinner = ProgressBar(this)
        right.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        message = TextView(this)
        message.setTextColor(Color.WHITE)
        message.textSize = 20f
        message.gravity = Gravity.CENTER
        message.setPadding(dp(30), dp(20), dp(30), dp(20))
        message.setBackgroundResource(R.drawable.chip_bg)
        message.isFocusable = true
        message.isClickable = true
        message.visibility = View.GONE
        message.setOnClickListener { select(curCat, curQuery) }
        right.addView(message, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        rightCol.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val rlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        rlp.leftMargin = railColW
        root.addView(rightCol, rlp)
        root.addView(shade, FrameLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(rail, FrameLayout.LayoutParams(railColW, ViewGroup.LayoutParams.MATCH_PARENT))
        applyRail(0f)
        setContentView(root)

        // rail opens while one of its icons has focus, closes when focus is back on the videos
        root.viewTreeObserver.addOnGlobalFocusChangeListener { _, nf ->
            if (nf != null) {
                val inRail = isInside(nf, rail)
                setRailOpen(inRail)
                if (!inRail && nf.tag != null && isInside(nf, grid)) {
                    if (rowsMode) {
                        val rowView = grid.findContainingItemView(nf)
                        val rp = if (rowView != null) try { grid.getChildAdapterPosition(rowView) } catch (e: Exception) { -1 } else -1
                        val prev = lastCard
                        val noKey = android.os.SystemClock.uptimeMillis() - lastKeyAt > 600L
                        if (noKey && prev != null && prev !== nf && prev.isAttachedToWindow && isInside(prev, grid) &&
                            lastRowFocus >= 0 && rp >= 0 && Math.abs(rp - lastRowFocus) > 1) {
                            // focus jumped to another row by itself (list changed while loading): put it back
                            grid.post { if (prev.isAttachedToWindow) prev.requestFocus() }
                            return@addOnGlobalFocusChangeListener
                        }
                        if (rp >= 0 && rp != lastRowFocus) {
                            lastRowFocus = rp
                            snapToRow(rp)
                        }
                    }
                    lastCard = nf
                }
                if (!inRail && nf !== grid && isInside(nf, grid)) {
                    val item = grid.findContainingItemView(nf)
                    if (item != null) {
                        val pos = try { grid.getChildAdapterPosition(item) } catch (e: Exception) { -1 }
                        if (pos >= 0) lastGridPos = pos
                    }
                }
            }
        }
    }

    private fun railRowLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(6)
        return lp
    }

    /** One rail row: icon always visible, name fades in when the rail opens. */
    private fun railRow(label: String, icon: Int, onClick: () -> Unit): Triple<LinearLayout, ImageView, TextView> {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(12), dp(8), dp(12))
        row.setBackgroundResource(R.drawable.chip_bg)
        row.isFocusable = true
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val ic = ImageView(this)
        ic.setImageResource(icon)
        ic.setColorFilter(Color.WHITE)
        row.addView(ic, LinearLayout.LayoutParams(dp(28), dp(28)))
        val t = TextView(this)
        t.text = label
        t.textSize = 17f
        t.setTextColor(Color.WHITE)
        t.maxLines = 1
        val tlp = LinearLayout.LayoutParams(dp(130), ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.leftMargin = dp(16)
        row.addView(t, tlp)
        railFade.add(t)
        return Triple(row, ic, t)
    }

    private fun isInside(v: View, ancestor: View): Boolean {
        var p: View? = v
        while (p != null) {
            if (p === ancestor) return true
            p = p.parent as? View
        }
        return false
    }

    private fun setRailOpen(open: Boolean) {
        val target = if (open) 1f else 0f
        if (railTarget == target) return
        railTarget = target
        railAnim?.cancel()
        val a = ValueAnimator.ofFloat(railFrac, target)
        a.duration = 170
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { applyRail(it.animatedValue as Float) }
        railAnim = a
        a.start()
    }

    /** f = 0: thin icon rail, f = 1: open with names. Only the rail changes size; the videos stay put. */
    private fun applyRail(f: Float) {
        railFrac = f
        val w = railColW + ((railExpW - railColW) * f).toInt()
        val lp = rail.layoutParams
        if (lp.width != w) {
            lp.width = w
            rail.layoutParams = lp
        }
        shade.translationX = w.toFloat()
        shade.alpha = f
        for (v in railFade) v.alpha = f
    }

    /** Back from the rail to the video that was selected before. */
    private fun focusGridBack(): Boolean {
        val lc = lastCard
        if (lc != null && lc.isAttachedToWindow && lc.isFocusable && isInside(lc, grid) && lc.requestFocus()) return true
        if (lastGridPos >= 0) {
            val vh = grid.findViewHolderForAdapterPosition(lastGridPos)
            if (vh != null && (vh.itemView.isFocusable || rowsMode) && vh.itemView.requestFocus()) return true
        }
        for (i in 0 until grid.childCount) {
            val c = grid.getChildAt(i)
            if ((c.isFocusable || rowsMode) && c.requestFocus()) return true
        }
        return false
    }

    /** Colour buttons / search key: jump to a tab and put focus on its videos. */
    private fun goTab(key: String) {
        if (key != "search") firstFocusPending = true
        select(cat(key))
    }

    /** MENU / INFO on a channel card (no long-press needed). */
    private fun chanMenu(c: Chan) {
        val on = Store.isSub(this, c.id)
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(arrayOf("Open channel", if (on) "Unsubscribe" else "Subscribe")) { _, i ->
                if (i == 0) openChannel(c.id, c.name)
                else {
                    val now = Store.toggleSub(this, c)
                    Toast.makeText(this, if (now) "Subscribed: ${c.name}" else "Unsubscribed: ${c.name}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        lastKeyAt = android.os.SystemClock.uptimeMillis()
        if (ev.action == KeyEvent.ACTION_DOWN) {
            when (ev.keyCode) {
                KeyEvent.KEYCODE_PROG_RED -> { goTab("home"); return true }
                KeyEvent.KEYCODE_PROG_GREEN -> { goTab("subs"); return true }
                KeyEvent.KEYCODE_PROG_YELLOW -> { goTab("history"); return true }
                KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_SEARCH -> { goTab("search"); return true }
            }
            val f0 = currentFocus
            if (f0 != null && isInside(f0, grid)) {
                val item = f0.tag
                when (ev.keyCode) {
                    KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> {
                        if (ev.repeatCount == 0) {
                            if (item is Vid) videoMenu(item) else if (item is Chan) chanMenu(item)
                        }
                        return true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                        if (ev.repeatCount == 0) {
                            when (item) {
                                is Vid -> open(item)
                                is Chan -> openChannel(item.id, item.name)
                                is Plist -> openPlist(item)
                            }
                        }
                        return true
                    }
                    KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN ->
                        if (UiUtil.page(grid, spans, true)) return true
                    KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP ->
                        if (UiUtil.page(grid, spans, false)) return true
                }
            }
        }
        if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
            val f = currentFocus
            if (f != null) {
                if (ev.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && isInside(f, grid)) {
                    // left edge of the videos: go to the icon of the tab that is open
                    val n = f.focusSearch(View.FOCUS_LEFT)
                    if (n != null && isInside(n, rail)) {
                        (chipViews[curCat.key] ?: n).requestFocus()
                        return true
                    }
                } else if (ev.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && isInside(f, rail)) {
                    if (focusGridBack()) return true
                }
            }
        }
        return super.dispatchKeyEvent(ev)
    }

    private fun markRail(c: Cat) {
        for ((k, v) in chipViews) {
            val on = k == c.key
            v.isSelected = on
            val col = if (on) Color.BLACK else Color.WHITE
            labelViews[k]?.setTextColor(col)
            iconViews[k]?.setColorFilter(col)
        }
    }

    // ------------------------------------------------------------------ feeds

    private fun select(c: Cat, forcedQuery: String? = null) {
        if (c.key == "account") {
            startActivity(Intent(this, SignInActivity::class.java))
            return
        }
        if (c.key == "search" && forcedQuery == null) {
            enterSearch()
            return
        }
        curCat = c
        markRail(c)
        curQuery = when {
            c.key == "search" -> forcedQuery ?: lastSearch
            else -> c.query
        }
        heading.visibility = View.GONE
        if (c.key == "search") {
            searchBar.visibility = View.VISIBLE
        } else {
            searchBar.visibility = View.GONE
            pendingLive?.let { Net.main.removeCallbacks(it) }
            hideKeyboard()
        }
        gen++
        lastGridPos = -1
        restorePos = -1
        items.clear()
        seen.clear()
        adapter.notifyDataSetChanged()
        setRowsMode(true)
        token = null
        exhausted = false
        homeFallback = false
        homeIdx = 0
        signedFeed = false
        loading = false
        message.visibility = View.GONE

        if (c.key == "history" && !Auth.signedIn(this)) {
            for (v in Store.history(this)) if (seen.add(v.id)) items.add(v)
            showItems()
            exhausted = true
            spinner.visibility = View.GONE
            if (items.isEmpty()) showMessage("Nothing watched yet", false)
            return
        }
        if (c.key == "chans") {
            exhausted = true
            if (Auth.signedIn(this)) {
                // signed in: the channels of the real account (cached copy first, then refreshed from YouTube)
                val shown = Store.accountChans(this).ifEmpty { Store.subs(this) }
                for (ch in shown) items.add(ch)
                showItems()
                // fresh copy (e.g. just back from the player): no need to download the whole list again
                if (items.isNotEmpty() && Store.accountChansAge(this) < 10 * 60_000L) {
                    spinner.visibility = View.GONE
                    return
                }
                spinner.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                val g = gen
                val app = applicationContext
                Net.async({ YT.accountChannels(app) }, { list ->
                    if (list.isNotEmpty()) Store.setAccountChans(app, list)
                    if (g == gen && curCat.key == "chans") {
                        spinner.visibility = View.GONE
                        if (list.isNotEmpty() && list.map { it.id } != items.filterIsInstance<Chan>().map { it.id }) {
                            items.clear()
                            items.addAll(list)
                            showItems()
                        }
                        if (items.isEmpty()) showMessage("No subscribed channels on this account", false)
                    }
                }, { e ->
                    if (g == gen && curCat.key == "chans") {
                        spinner.visibility = View.GONE
                        if (items.isEmpty()) showMessage("Could not load channels\n(${e.message})\n\nPress OK to retry", true)
                    }
                })
                return
            }
            for (ch in Store.subs(this)) items.add(ch)
            showItems()
            spinner.visibility = View.GONE
            if (items.isEmpty()) showMessage("No channels yet\nOpen a channel and press Subscribe", false)
            return
        }
        if (c.key in libraryIds && !Auth.signedIn(this)) {
            exhausted = true
            spinner.visibility = View.GONE
            showMessage("Sign in (left menu: Sign in) to see this,\nlike on YouTube", false)
            return
        }
        if (c.key == "subs" && Store.subs(this).isEmpty() && !Auth.signedIn(this)) {
            exhausted = true
            spinner.visibility = View.GONE
            showMessage("No subscriptions yet\nSearch a channel, open it and press Subscribe", false)
            return
        }
        loadMore()
    }

    /** Search tab: show the box (with the last search), recent searches as chips, open the keyboard. */
    private fun enterSearch() {
        val sc = cat("search")
        curCat = sc
        markRail(sc)
        heading.visibility = View.GONE
        searchBar.visibility = View.VISIBLE
        settingText = true
        searchBox.setText(lastSearch)
        searchBox.setSelection(searchBox.text.length)
        settingText = false
        if (lastSearch.isNotEmpty()) {
            select(sc, lastSearch)
        } else {
            gen++
            items.clear()
            seen.clear()
            adapter.notifyDataSetChanged()
            setRowsMode(true)
            loading = false
            exhausted = true
            spinner.visibility = View.GONE
            message.visibility = View.GONE
        }
        showRecents()
        searchBox.requestFocus()
        showKeyboard()
    }

    private fun showRecents() = fillSugs(Store.recents(this))

    /** "Related searches": from the results page if YouTube sent them, else search suggestions. */
    private fun showRelated(rel: List<String>, q: String) {
        if (rel.isNotEmpty()) {
            fillSugs(rel, "Related searches")
        } else {
            Net.async({ YT.suggest(q) }, { res ->
                if (finalSearch && curCat.key == "search" && curQuery == q) fillSugs(res.filter { !it.equals(q, true) }, "Related searches")
            })
        }
    }

    private fun fillSugs(l: List<String>, label: String? = null) {
        sugRow.removeAllViews()
        if (label != null && l.isNotEmpty()) {
            val lab = TextView(this)
            lab.text = label
            lab.textSize = 14f
            lab.setTextColor(Color.parseColor("#AAAAAA"))
            lab.gravity = Gravity.CENTER_VERTICAL
            lab.setPadding(dp(4), 0, dp(12), 0)
            sugRow.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        for (q in l.take(8)) {
            val t = TextView(this)
            t.text = q
            t.textSize = 16f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(18), dp(7), dp(18), dp(7))
            t.maxLines = 1
            t.setBackgroundResource(R.drawable.chip_bg)
            t.isFocusable = true
            t.isClickable = true
            t.setOnClickListener { doSearch(q) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            sugRow.addView(t, lp)
        }
    }

    private fun showKeyboard() {
        searchBox.post {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun hideKeyboard() {
        if (!::searchBox.isInitialized) return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        val id = videoIdFrom(query)
        if (id != null) {
            open(Vid(id, "YouTube video"))
            return
        }
        pendingLive?.let { Net.main.removeCallbacks(it) }
        finalSearch = true
        lastSearch = query
        Store.addRecent(this, query)
        settingText = true
        searchBox.setText(query)
        searchBox.setSelection(searchBox.text.length)
        settingText = false
        hideKeyboard()
        firstFocusPending = true
        select(cat("search"), query)
    }

    // ------------------------------------------------------------------ rows (home + search)

    /** Home and Search: horizontal rows. Other tabs: the normal grid. */
    private fun setRowsMode(on: Boolean) {
        if (on) {
            val n = rowData.size
            rowData.clear()
            lastRowFocus = -1
            lastCard = null
            sectionMode = false
            pendingTitle = null
            sectionRow = null
            kindRow.clear()
            if (rowsMode) {
                if (n > 0) rowsAdapter.notifyDataSetChanged()
                return
            }
            rowsMode = true
            grid.layoutManager = rowsLm
            grid.adapter = rowsAdapter
            grid.setPadding(0, dp(6), 0, dp(20))
        } else {
            if (!rowsMode) return
            rowsMode = false
            rowData.clear()
            sectionMode = false
            pendingTitle = null
            sectionRow = null
            kindRow.clear()
            val pad = dp(20)
            grid.layoutManager = gridLm
            grid.adapter = adapter
            grid.setPadding(pad - dp(5), dp(10), pad - dp(5), pad)
        }
    }

    /** Focus moved to another row: scroll so that row (with its title) sits at the top, next row peeking below. */
    private fun snapToRow(pos: Int) {
        val ss = object : LinearSmoothScroller(this) {
            override fun getVerticalSnapPreference(): Int = SNAP_TO_START
        }
        ss.targetPosition = pos
        rowsLm.startSmoothScroll(ss)
    }

    /** Items were filled in directly (History, My Channels ...): show them. */
    private fun showItems() {
        if (!rowsMode) {
            adapter.notifyDataSetChanged()
            return
        }
        setRowsMode(true)       // empties the rows
        if (items.isNotEmpty()) addToRows(items.toList())
    }

    private fun newRow(title: String, added: HashMap<FeedRow, Int>): FeedRow {
        val r = FeedRow(title)
        rowData.add(r)
        added[r] = -1          // -1 = brand new row (whole row is inserted)
        return r
    }

    /**
     * Put new items into rows. A heading (String) starts a titled row; otherwise items are grouped
     * by kind (videos / channels / playlists) and a row is filled up to ROW_MAX cards.
     */
    private fun addToRows(list: List<Any>) {
        val firstNew = rowData.size
        val added = HashMap<FeedRow, Int>()    // existing row -> size before we added to it
        fun put(row: FeedRow, x: Any) {
            if (!added.containsKey(row)) added[row] = row.items.size
            row.items.add(x)
        }
        val search = curCat.key == "search"
        // Music, Gaming, History ... : rows of CHUNK cards, more rows below. Search / Home rows grow sideways.
        val chunk = curCat.key != "search" && curCat.key != "home"
        for (x in list) {
            if (x is String) {
                // the row is made when its first video arrives (a shelf whose videos were all seen = no empty row)
                pendingTitle = x
                sectionRow = null
                sectionMode = true
                continue
            }
            if (x is MoreToken) {
                sectionRow?.more = x.token
                continue
            }
            if (sectionMode) {
                var sr = sectionRow
                if (sr == null) {
                    sr = newRow(pendingTitle ?: "", added)
                    sectionRow = sr
                    pendingTitle = null
                }
                put(sr, x)
                continue
            }
            val kind = if (x is Chan) "c" else if (x is Plist) "p" else "v"
            // one row per kind; it keeps growing sideways as more result pages arrive
            var kr = kindRow[kind]
            if (kr == null || (chunk && kr.items.size >= ROW_MAX)) {
                val title = if (kr != null) ""
                else if (chunk) curCat.label
                else when (kind) {
                    "c" -> "Channels"
                    "p" -> "Playlists"
                    else -> if (search) "Videos" else "Recommended"
                }
                kr = newRow(title, added)
                kr.grow = !chunk
                kindRow[kind] = kr
            }
            put(kr, x)
        }
        // tell the lists what changed
        for ((row, before) in added) {
            if (before < 0) continue
            if (row.items.size > before) row.adapter?.notifyItemRangeInserted(before, row.items.size - before)
        }
        if (rowData.size > firstNew) rowsAdapter.notifyItemRangeInserted(firstNew, rowData.size - firstNew)
    }

    /** Near the last rows: load the next page. */
    private fun checkMoreRows() {
        if (!rowsMode || loading || exhausted || rowData.isEmpty()) return
        if (rowData.last().grow) return        // those rows load sideways, see rowEnd()
        if (rowsLm.findLastVisibleItemPosition() >= rowData.size - 2) loadMore()
    }

    /** Focus reached the right end of a row: get more cards for it. */
    private fun rowEnd(row: FeedRow) {
        if (row.more != null) loadRow(row) else if (row.grow) loadMore()
    }

    private fun loadRow(row: FeedRow) {
        val tok = row.more ?: return
        if (row.busy) return
        row.busy = true
        val g = gen
        val app = applicationContext
        val signed = Auth.signedIn(this)
        Net.async({ YT.shelfMore(app, tok, signed) }, { p ->
            row.busy = false
            if (g != gen) return@async
            val before = row.items.size
            for (x in p.mixed) {
                val ok = when (x) {
                    is Vid -> seen.add(x.id)
                    is Chan -> seen.add("c:" + x.id)
                    is Plist -> seen.add("p:" + x.id)
                    else -> false
                }
                if (ok) row.items.add(x)
            }
            row.more = if (row.items.size > before) p.token else null
            if (row.items.size > before) row.adapter?.notifyItemRangeInserted(before, row.items.size - before)
        }, { row.busy = false })
    }

    private fun loadMore() {
        if (loading || exhausted) return
        loading = true
        val g = gen
        val cat = curCat
        val q = curQuery
        val tok = token
        val fb = homeFallback
        val idx = homeIdx
        val sf = signedFeed
        if (items.isEmpty()) {
            spinner.visibility = View.VISIBLE
            message.visibility = View.GONE
        }
        Net.async({
            fetch(cat, q, tok, fb, idx, sf)
        }, { r ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                token = r.token
                homeFallback = r.fallback
                homeIdx = r.idx
                signedFeed = r.signed
                exhausted = r.done
                val start = items.size
                val fresh = ArrayList<Any>()
                for (x in r.items) {
                    if (x is MoreToken) { fresh.add(x); continue }
                    val ok = when (x) {
                        is Vid -> seen.add(x.id)
                        is Chan -> seen.add("c:" + x.id)
                        is Plist -> seen.add("p:" + x.id)
                        else -> true
                    }
                    if (ok) { items.add(x); fresh.add(x) }
                }
                if (rowsMode) {
                    if (fresh.isNotEmpty()) addToRows(fresh)
                } else if (items.size > start) adapter.notifyItemRangeInserted(start, items.size - start)
                applyRestore()
                if (cat.key == "search" && start == 0 && finalSearch) showRelated(r.related, q)
                if (items.isEmpty()) {
                    if (exhausted) showMessage("No videos found", false) else loadMore()
                } else if (firstFocusPending) {
                    firstFocusPending = false
                    grid.post { focusFirstCard() }
                }
                grid.post { checkMoreRows() }
            }
        }, { e ->
            if (g == gen) {
                loading = false
                spinner.visibility = View.GONE
                if (items.isEmpty()) showMessage("Could not load videos\n(${e.message})\n\nPress OK to retry", true)
            }
        })
    }

    private fun focusFirstCard() {
        for (i in 0 until grid.childCount) {
            val c = grid.getChildAt(i)
            if ((c.isFocusable || rowsMode) && c.requestFocus()) return
        }
    }

    private class Result(
        val items: List<Any>, val token: String?, val fallback: Boolean, val idx: Int, val done: Boolean,
        val related: List<String> = emptyList(), val signed: Boolean = false
    )

    /** Runs on a background thread. */
    private fun fetch(cat: Cat, q: String, tok: String?, fallback: Boolean, idx: Int, sf: Boolean): Result {
        // signed in: Home = your recommendations, Subscriptions / History = your account
        val k = cat.key
        // genres: YouTube's own topic channels, opened as the account (like YouTube on TV), so they follow the account's taste
        val genreIds = mapOf(
            "music" to "UC-9-kyTW8ZkZNDHQJ6FgpwQ", "gaming" to "UCOpNcN46UbXVtpKMrmU4Abg",
            "movies" to "UClgRkhTL3_hImCAmdLfDE4g", "news" to "UCYfdidRxbB8Qhf0Nx7ioOYw",
            "sports" to "UCEgdi0XIXXZ-qJOFPf4JSKw", "live" to "UC4R8DWoMoI7CAwX8_LjQHig",
            "learn" to "UCtFRv9O2AHqOZjjynzrv-xg"
        )
        if ((k == "home" || k == "subs" || k == "history" || genreIds.containsKey(k) || libraryIds.containsKey(k)) && Auth.signedIn(this) && (sf || tok == null)) {
            val id = when (k) {
                "home" -> "default"
                "subs" -> "FEsubscriptions"
                "history" -> "FEhistory"
                else -> libraryIds[k] ?: genreIds[k]!!
            }
            try {
                val p = YT.tvBrowse(this, id, if (sf) tok else null)
                if (p.mixed.isEmpty() && !sf && !libraryIds.containsKey(k)) throw RuntimeException("the account feed is empty")
                return Result(p.mixed, p.token, false, 0, p.token == null, p.related, true)
            } catch (e: Exception) {
                // signed in: show what went wrong (no silent switch to non-account videos)
                throw RuntimeException("$k (account): ${e.message}", e)
            }
        }
        if (k == "history") return Result(Store.history(this), null, false, 0, true)
        if (libraryIds.containsKey(k)) return Result(emptyList(), null, false, 0, true)   // no search fallback for the Library
        if (cat.key == "home") return fetchHome(tok, fallback, idx)
        if (cat.key == "subs") {
            val vids = subsVideos(Store.subs(this).take(20), 6)
            return Result(vids, null, false, 0, true)
        }
        // "search" has no filter: videos AND channels come back mixed, like on YouTube
        // signed in: genres without a topic channel (Comedy, Tech) are also asked as the account
        val asAccount = cat.key == "search" || (Auth.signedIn(this) && cat.key in listOf("comedy", "tech", "music", "gaming", "movies", "news", "sports", "live", "learn"))
        val p = if (asAccount) YT.searchFor(this, q, tok) else YT.search(q, tok, cat.filter)
        if (cat.key == "search" && tok == null && !Auth.signedIn(this)) {
            // playlists rarely come mixed into the results: ask for them on purpose (they get their own row)
            val pl = try { YT.search(q, null, "EgIQAw==").mixed.filterIsInstance<Plist>().take(15) } catch (e: Exception) { emptyList() }
            if (pl.isNotEmpty()) return Result(p.mixed + pl, p.token, false, 0, p.token == null, p.related)
        }
        return Result(p.mixed, p.token, false, 0, p.token == null, p.related)
    }

    private fun fetchHome(tok: String?, fallback: Boolean, idx: Int): Result {
        val first = tok == null && !fallback && idx == 0
        val personal: List<Any> = if (first) {
            val l = ArrayList<Any>()
            try { l.addAll(personalBlock()) } catch (e: Exception) { }
            try { l.addAll(playlistRow()) } catch (e: Exception) { }
            l
        } else emptyList()
        val feed = try {
            homeFeed(tok, fallback, idx)
        } catch (e: Exception) {
            if (personal.isEmpty()) throw e
            return Result(personal, null, false, 0, true)
        }
        if (personal.isEmpty()) return feed
        val all = ArrayList<Any>(personal)
        all.add("More to explore")
        all.addAll(feed.items)
        return Result(all, feed.token, feed.fallback, feed.idx, feed.done)
    }

    private fun homeFeed(tok: String?, fallback: Boolean, idx: Int): Result {
        var fb = fallback
        var i = idx
        if (!fb) {
            val p = YT.home(tok)
            if (tok != null || p.items.size >= 8) return Result(p.mixed, p.token, false, 0, p.token == null)
            fb = true // logged-out home was (almost) empty
        }
        val p = YT.search(homeQueries[i], null)
        i++
        return Result(p.mixed, null, true, i, i >= homeQueries.size)
    }

    /** Runs the tasks in parallel (max 9 s). One list per task, empty if it failed. */
    private fun runAll(tasks: List<Callable<List<Vid>>>): List<List<Vid>> {
        if (tasks.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(4)
        try {
            return pool.invokeAll(tasks, 9, TimeUnit.SECONDS).map { f ->
                try {
                    if (f.isCancelled) emptyList<Vid>() else f.get()
                } catch (e: Exception) {
                    emptyList<Vid>()
                }
            }
        } finally {
            pool.shutdownNow()
        }
    }

    private fun channelTask(ch: Chan, per: Int): Callable<List<Vid>> = Callable<List<Vid>> {
        try {
            YT.channel(ch.id, null, ch.name).page.items.take(per)
        } catch (e: Exception) {
            emptyList<Vid>()
        }
    }

    /** Newest videos of the subscribed channels, freshest first. */
    private fun subsVideos(subs: List<Chan>, per: Int): List<Vid> {
        val res = runAll(subs.map { channelTask(it, per) })
        val all = ArrayList<Vid>()
        for (l in res) all.addAll(l)
        return all.distinctBy { it.id }.sortedBy { ageMinutes(it.meta) }
    }

    /** A "Playlists" row for Home: playlists about what was watched last (or popular ones). */
    private fun playlistRow(): List<Any> {
        val seed = Store.history(this).firstOrNull { it.title != "YouTube video" && it.channel.isNotEmpty() }?.channel
        val q = if (seed != null) "$seed playlist" else "best songs playlist"
        val l = YT.search(q, null, "EgIQAw==").mixed.filterIsInstance<Plist>().take(14)
        if (l.isEmpty()) return emptyList()
        val out = ArrayList<Any>()
        out.add("Playlists")
        out.addAll(l)
        return out
    }

    /** Put [extra] in [list] after the first [n] titled rows (or at the end if there are fewer). */
    private fun insertAfterShelves(list: List<Any>, extra: List<Any>, n: Int): List<Any> {
        var seenHeads = 0
        var at = list.size
        for ((i, x) in list.withIndex()) {
            if (x is String) {
                if (seenHeads == n) { at = i; break }
                seenHeads++
            }
        }
        val out = ArrayList<Any>(list.subList(0, at))
        out.addAll(extra)
        out.addAll(list.subList(at, list.size))
        return out
    }

    /** Home rows built from what this TV saved: subscriptions + "because you watched". */
    private fun personalBlock(): List<Any> {
        val subs = Store.subs(this).take(8)
        val hist = Store.history(this)
        val seeds = hist.filter { it.title != "YouTube video" }.take(2)
        if (subs.isEmpty() && seeds.isEmpty()) return emptyList()
        val watched = HashSet<String>()
        for (h in hist) watched.add(h.id)

        val tasks = ArrayList<Callable<List<Vid>>>()
        for (ch in subs) tasks.add(channelTask(ch, 5))
        for (v in seeds) {
            tasks.add(Callable<List<Vid>> {
                try {
                    YT.related(v.id).take(8)
                } catch (e: Exception) {
                    emptyList<Vid>()
                }
            })
        }
        val res = runAll(tasks)

        val out = ArrayList<Any>()
        val used = HashSet<String>()

        val subVids = ArrayList<Vid>()
        for (i in subs.indices) if (i < res.size) subVids.addAll(res[i])
        val fresh = subVids.filter { it.id !in watched }
            .distinctBy { it.id }
            .sortedBy { ageMinutes(it.meta) }
            .take(12)
        if (fresh.isNotEmpty()) {
            out.add("From your subscriptions")
            for (v in fresh) {
                used.add(v.id)
                out.add(v)
            }
        }
        for ((k, seed) in seeds.withIndex()) {
            val at = subs.size + k
            if (at >= res.size) continue
            val r = res[at].filter { it.id !in watched && it.id !in used }.take(4)
            if (r.isNotEmpty()) {
                out.add("Because you watched " + seed.title)
                for (v in r) {
                    used.add(v.id)
                    out.add(v)
                }
            }
        }
        return out
    }

    private fun showMessage(text: String, retry: Boolean) {
        message.text = text
        message.visibility = View.VISIBLE
        message.isFocusable = retry
        message.isClickable = retry
        if (retry) message.requestFocus()
    }

    // ------------------------------------------------------------------ actions

    private fun open(v: Vid) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_VID, v.toJson().toString())
        startActivity(i)
    }

    private fun openPlist(p: Plist) {
        val i = Intent(this, PlaylistActivity::class.java)
        i.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        i.putExtra(PlaylistActivity.EXTRA_TITLE, p.title)
        startActivity(i)
    }

    private fun openChannel(id: String, name: String) {
        if (id.isEmpty()) return
        val i = Intent(this, ChannelActivity::class.java)
        i.putExtra(ChannelActivity.EXTRA_ID, id)
        i.putExtra(ChannelActivity.EXTRA_NAME, name)
        startActivity(i)
    }

    /** Account action in the background, with a toast for the result. */
    private fun remote(okMsg: String, work: () -> Unit) {
        Net.async({ work() }, { Toast.makeText(this, okMsg, Toast.LENGTH_SHORT).show() },
            { e -> Toast.makeText(this, "Failed: " + (e.message ?: "error"), Toast.LENGTH_LONG).show() })
    }

    /** Long press on a video card: Play / Go to channel / Subscribe. */
    private fun videoMenu(v: Vid) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("Play")
        acts.add { open(v) }
        if (v.channelId.isNotEmpty()) {
            labels.add("Go to channel: " + v.channel)
            acts.add { openChannel(v.channelId, v.channel) }
            labels.add(if (Store.isSub(this, v.channelId)) "Unsubscribe" else "Subscribe")
            acts.add {
                val now = Store.toggleSub(this, Chan(v.channelId, v.channel))
                Toast.makeText(this, if (now) "Subscribed: ${v.channel}" else "Unsubscribed: ${v.channel}", Toast.LENGTH_SHORT).show()
            }
        }
        if (Auth.signedIn(this)) {
            val app = applicationContext
            labels.add("Save to Watch later")
            acts.add { remote("Saved to Watch later") { YT.watchLater(app, v.id, true) } }
            labels.add("Like")
            acts.add { remote("Liked") { YT.rate(app, v.id, true) } }
        }
        AlertDialog.Builder(this)
            .setTitle(v.title)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }
}
