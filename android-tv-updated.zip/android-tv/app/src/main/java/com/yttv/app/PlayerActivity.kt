package com.yttv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Full-screen player.
 *   OK            play / pause (+ show bar)
 *   Left / Right  seek 10 s (hold = 30 s)
 *   Up            choose quality
 *   Down          panel: Previous / Next / channel / Subscribe / playlist or Up next
 *   Back          close
 * When a video ends, the first related video plays automatically (autoplay).
 */
class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_VID = "vid"
        const val EXTRA_QUEUE = "queue"   // optional: playlist videos to play in order
        const val EXTRA_QUEUE_TITLE = "queue_title"   // optional: name shown above the playlist row
        private const val BAR_MS = 4000L
        /** Video not playing (stuck loading / buffering) for this long: load it again. */
        private const val STALL_MS = 120_000L
        private const val MAX_RELOADS = 5
    }

    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var spinner: View
    private lateinit var pauseIcon: ImageView
    private lateinit var seekText: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var titleText: TextView
    private lateinit var channelText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlay: TextView
    private var dragging = false
    private lateinit var panel: LinearLayout
    private lateinit var panelChips: LinearLayout
    private lateinit var panelRow: LinearLayout
    private lateinit var panelLabel: TextView
    private lateinit var panelScroll: HorizontalScrollView
    private var panelTargetIdx = 0     // card the panel lands on when it opens
    private var panelOpen = false
    private lateinit var timeCur: TextView
    private lateinit var timeDur: TextView

    private var cur: Vid? = null
    private var stream: Stream? = null
    private var related: List<Vid> = emptyList()
    private val played = HashSet<String>()
    private var queue: List<Vid> = emptyList()
    private var qIdx = -1
    private var queueTitle = ""
    private val trail = ArrayList<Vid>()     // videos played before this one (for Previous)
    private var stallSince = 0L
    private var reloads = 0
    private var inForeground = true
    private var lastState = Player.STATE_IDLE
    private var musicMode = false                    // audio only: thumbnail on screen, no video downloaded
    private lateinit var musicView: ImageView
    private var lastSeekAt = 0L                      // last time the person jumped around in the video

    /** Every jump (arrow keys, number keys, bar, Previous) calls this (used by the Up key). */
    private fun markSeek() {
        lastSeekAt = SystemClock.elapsedRealtime()
    }

    /** What plays next: the rest of the playlist if there is one, else YouTube's related videos. */
    private fun nextList(): List<Vid> =
        if (qIdx >= 0 && qIdx + 1 < queue.size) queue.drop(qIdx + 1) else related

    private var gen = 0
    private var mode = 0        // 0 = separate video+audio, 1 = single safe file
    private var retries = 0
    private var curHeight = 0
    private var closing = false
    private var wasPlaying = false
    private var reportedId = ""
    private var reportedAt = 0L

    /** Signed in: tell YouTube how far this video got, so it also shows up in the account's History. */
    private fun reportWatch(force: Boolean = false) {
        val v = cur ?: return
        val p = player ?: return
        if (!Auth.signedIn(this)) return
        val pos = p.currentPosition
        val dur = p.duration
        if (dur == C.TIME_UNSET || dur <= 0L || pos < 2000L) return
        val now = System.currentTimeMillis()
        if (!force && reportedId == v.id && now - reportedAt < 30_000L) return
        reportedId = v.id
        reportedAt = now
        val app = applicationContext
        val id = v.id
        val ps = pos / 1000f
        val ls = dur / 1000f
        Net.async({ YT.reportWatch(app, id, ps, ls) }, { }, { })
    }

    private var pendingSeekMs = -1L
    private var barHideAt = 0L

    private val applySeek = Runnable {
        val p = player ?: return@Runnable
        if (pendingSeekMs >= 0) {
            markSeek()
            p.seekTo(pendingSeekMs)
            pendingSeekMs = -1L
        }
        handler.postDelayed({ seekText.visibility = View.GONE }, 700)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            if (player?.isPlaying == true) reportWatch()
            checkStall()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.player_view)
        spinner = findViewById(R.id.spinner)
        // Music mode picture: sits right above the video, below spinner / bars
        musicView = ImageView(this)
        musicView.scaleType = ImageView.ScaleType.FIT_CENTER
        musicView.setBackgroundColor(Color.BLACK)
        musicView.setPadding(dp(200), dp(60), dp(200), dp(60))
        musicView.visibility = View.GONE
        val pv = playerView.parent as ViewGroup
        pv.addView(musicView, pv.indexOfChild(playerView) + 1,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        pauseIcon = findViewById(R.id.pause_icon)
        seekText = findViewById(R.id.seek_text)
        topBar = findViewById(R.id.top_bar)
        bottomBar = findViewById(R.id.bottom_bar)
        titleText = findViewById(R.id.title_text)
        channelText = findViewById(R.id.channel_text)
        seekBar = findViewById(R.id.seek_bar)
        btnPlay = findViewById(R.id.btn_play)
        btnPlay.setOnClickListener { togglePause() }
        findViewById<TextView>(R.id.btn_quality).setOnClickListener { showBars(); qualityDialog() }
        findViewById<TextView>(R.id.btn_menu).setOnClickListener { openPanel() }
        // touch: drag the bar to seek
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val d = player?.duration ?: C.TIME_UNSET
                if (d != C.TIME_UNSET && d > 0) timeCur.text = fmt(progress * d / 1000)
                showBars()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                val d = player?.duration ?: C.TIME_UNSET
                if (d != C.TIME_UNSET && d > 0) {
                    markSeek()
                    player?.seekTo((sb?.progress ?: 0) * d / 1000)
                }
                showBars()
            }
        })
        timeCur = findViewById(R.id.time_cur)
        timeDur = findViewById(R.id.time_dur)
        UiUtil.immersive(window)
        findViewById<TextView>(R.id.btn_prev).setOnClickListener { prevVideo() }
        findViewById<TextView>(R.id.btn_next).setOnClickListener { nextVideo() }
        buildPanel()

        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20_000, 60_000, 2_500, 6_000)
            .setTargetBufferBytes(40 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        // light on old TVs: small buffer, and fall back to another decoder if one fails
        val rf = androidx.media3.exoplayer.DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, rf).setLoadControl(load).build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true
        )
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                spinner.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                lastState = state
                if (state == Player.STATE_ENDED) playNextAuto()
                refreshPauseIcon()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                refreshPauseIcon()
            }

            override fun onPlayerError(error: PlaybackException) {
                onPlaybackFailed(error)
            }
        })
        playerView.player = p
        player = p

        val vid = try {
            Vid.fromJson(JSONObject(intent.getStringExtra(EXTRA_VID) ?: "{}"))
        } catch (e: Exception) {
            null
        }
        if (vid == null || vid.id.isEmpty()) {
            finish()
            return
        }
        queue = try {
            val a = JSONArray(intent.getStringExtra(EXTRA_QUEUE) ?: "[]")
            (0 until a.length()).map { Vid.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
        queueTitle = intent.getStringExtra(EXTRA_QUEUE_TITLE) ?: ""
        startVideo(vid)
        handler.post(tick)
    }

    // ------------------------------------------------------------------ loading

    private fun startVideo(v: Vid, push: Boolean = true) {
        if (panelOpen) {
            panelOpen = false
            panel.visibility = View.GONE
        }
        reportWatch(true)   // the video we are leaving
        val old = cur
        if (push && old != null && old.id != v.id) {
            trail.add(old)
            if (trail.size > 50) trail.removeAt(0)
        }
        stallSince = 0L
        reloads = 0
        cur = v
        qIdx = queue.indexOfFirst { it.id == v.id }
        played.add(v.id)
        Store.addHistory(this, v)
        titleText.text = v.title
        channelText.text = listOf(v.channel, v.meta).filter { it.isNotEmpty() }.joinToString("  •  ")
        showMusicPicture()
        mode = 0
        retries = 0
        stream = null
        related = emptyList()
        spinner.visibility = View.VISIBLE
        player?.stop()
        player?.clearMediaItems()
        showBars()
        val g = ++gen
        Net.async({ YT.resolve(v.id, 0) }, { s ->
            if (g == gen && !closing) {
                stream = s
                enrich(s)
                play(s, 0L)
            }
        }, { e ->
            if (g == gen && !closing) fail(e.message ?: "Video unavailable")
        })
        Net.async({ YT.related(v.id) }, { r ->
            if (g == gen) {
                related = r
                if (panelOpen) {
                    fillPanel()
                    if (!panel.hasFocus()) focusPanelDefault()
                }
            }
        }, { })
    }

    /** Opened from a link? Fill in the real title / channel from the player response. */
    private fun enrich(s: Stream) {
        val v = cur ?: return
        val nv = v.copy(
            title = if (v.title == "YouTube video" && s.title.isNotEmpty()) s.title else v.title,
            channel = if (v.channel.isEmpty()) s.author else v.channel,
            channelId = if (v.channelId.isEmpty()) s.channelId else v.channelId
        )
        if (nv != v) {
            cur = nv
            Store.addHistory(this, nv)
            titleText.text = nv.title
            channelText.text = listOf(nv.channel, nv.meta).filter { it.isNotEmpty() }.joinToString("  •  ")
        }
    }

    private fun play(s: Stream, startMs: Long) {
        val p = player ?: return
        val http = ChunkedDataSource.factory(YT.http, s.ua)
        val pf = ProgressiveMediaSource.Factory(http)
        val src: MediaSource
        val v = if (mode == 0 && !musicMode) s.pickVideo(Store.quality(this)) else null
        if (musicMode && mode == 0 && s.audio != null) {
            // music mode: only the sound is downloaded
            src = pf.createMediaSource(MediaItem.fromUri(s.audio.url))
            curHeight = 0
        } else if (v != null && s.audio != null) {
            src = MergingMediaSource(
                pf.createMediaSource(MediaItem.fromUri(v.url)),
                pf.createMediaSource(MediaItem.fromUri(s.audio.url))
            )
            curHeight = v.height
        } else if (s.muxed != null) {
            src = pf.createMediaSource(MediaItem.fromUri(s.muxed.url))
            curHeight = s.muxed.height
        } else {
            fail("No playable stream")
            return
        }
        p.setMediaSource(src, startMs)
        p.prepare()
        p.playWhenReady = true
    }

    private fun onPlaybackFailed(e: PlaybackException) {
        val v = cur ?: return
        val p = player ?: return
        val pos = p.currentPosition
        val s = stream
        if (mode == 0 && s?.muxed != null) {
            // 1) try the single-file version (safer on old TVs)
            mode = 1
            toast("Switching to safe quality (${e.errorCodeName} ${e.cause?.message ?: ""})")
            play(s, pos)
            return
        }
        if (retries < 2) {
            // 2) ask YouTube again, starting with the other client
            retries++
            mode = 0
            val g = ++gen
            spinner.visibility = View.VISIBLE
            val first = retries
            Net.async({ YT.resolve(v.id, first) }, { ns ->
                if (g == gen && !closing) {
                    stream = ns
                    play(ns, pos)
                }
            }, { ex ->
                if (g == gen && !closing) fail(ex.message ?: "Playback failed")
            })
            return
        }
        fail("Playback failed: ${e.errorCodeName} ${e.cause?.message ?: ""}")
    }

    private fun fail(msg: String) {
        spinner.visibility = View.GONE
        toast(msg)
        handler.postDelayed({ if (!closing) finish() }, 2500)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    /** Next: the next playlist / channel video, else the first suggested video not played yet. */
    private fun nextVideo() {
        val n = if (qIdx >= 0 && qIdx + 1 < queue.size) queue[qIdx + 1]
        else related.firstOrNull { it.id !in played } ?: related.firstOrNull()
        if (n == null) {
            toast("No next video yet")
            return
        }
        startVideo(n)
    }

    /** Previous: like YouTube - after 5 s it restarts this video, else goes to the one before. */
    private fun prevVideo() {
        val p = player
        if (p != null && p.currentPosition > 5000L) {
            markSeek()
            p.seekTo(0)
            showBars()
            return
        }
        if (qIdx > 0) {
            startVideo(queue[qIdx - 1], false)
        } else if (trail.isNotEmpty()) {
            startVideo(trail.removeAt(trail.size - 1), false)
        } else {
            p?.seekTo(0)
            showBars()
        }
    }

    /** Not playing for 2 minutes (YouTube slow / limiting us): ask for a fresh stream and carry on. */
    private fun checkStall() {
        val p = player ?: return
        if (closing || cur == null || !inForeground) {
            stallSince = 0L
            return
        }
        val loading = stream == null || (p.playWhenReady && !p.isPlaying && p.playbackState != Player.STATE_ENDED)
        if (!loading) {
            stallSince = 0L
            if (p.isPlaying) reloads = 0
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (stallSince == 0L) {
            stallSince = now
            return
        }
        if (now - stallSince >= STALL_MS) {
            stallSince = 0L
            reloadStuck()
        }
    }

    private fun reloadStuck() {
        val v = cur ?: return
        val p = player ?: return
        if (reloads >= MAX_RELOADS) {
            fail("Video is not loading. Try again later.")
            return
        }
        reloads++
        val pos = if (stream != null) maxOf(0L, p.currentPosition) else 0L
        toast("Video stuck, reloading...")
        mode = 0
        retries = 0
        val g = ++gen
        spinner.visibility = View.VISIBLE
        p.stop()
        val first = reloads % 3
        Net.async({ YT.resolve(v.id, first) }, { ns ->
            if (g == gen && !closing) {
                stream = ns
                play(ns, pos)
            }
        }, { _ ->
            // could not even ask YouTube: the watchdog tries again after the next wait
            if (g == gen && !closing) toast("Reload failed, will try again")
        })
    }

    private fun playNextAuto(force: Boolean = false) {
        if (!force && !Store.autoplay(this)) {
            // autoplay off: stay here and show the "Up next" panel
            openPanel()
            return
        }
        val next = nextList().firstOrNull { it.id !in played }
        if (next == null) {
            finish()
        } else {
            startVideo(next)
        }
    }

    // ------------------------------------------------------------------ UI

    private fun refreshPauseIcon() {
        val p = player ?: return
        val paused = !p.playWhenReady && p.playbackState == Player.STATE_READY
        pauseIcon.visibility = if (paused) View.VISIBLE else View.GONE
        btnPlay.text = if (p.playWhenReady) "Pause" else "Play"
    }

    private fun showBars() {
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        barHideAt = System.currentTimeMillis() + BAR_MS
    }

    private fun updateUi() {
        val p = player ?: return
        val pos = if (pendingSeekMs >= 0) pendingSeekMs else p.currentPosition
        val dur = p.duration
        if (dur != C.TIME_UNSET && dur > 0) {
            if (!dragging) seekBar.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
            timeDur.text = fmt(dur) + (if (musicMode) "   \u266B Music" else if (curHeight > 0) "   ${curHeight}p" else "")
        }
        if (!dragging) timeCur.text = fmt(pos)
        val paused = !p.playWhenReady
        if (!paused && System.currentTimeMillis() > barHideAt && topBar.visibility == View.VISIBLE) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    private fun nudge(dir: Int, repeat: Int) {
        val p = player ?: return
        val step = (if (repeat > 6) 30_000L else 10_000L) * dir
        val base = if (pendingSeekMs >= 0) pendingSeekMs else p.currentPosition
        var t = base + step
        val d = p.duration
        t = if (d != C.TIME_UNSET && d > 0) t.coerceIn(0L, maxOf(0L, d - 1000)) else maxOf(0L, t)
        pendingSeekMs = t
        markSeek()
        seekText.text = (if (dir > 0) "▶▶ " else "◀◀ ") + fmt(t)
        seekText.visibility = View.VISIBLE
        showBars()
        handler.removeCallbacks(applySeek)
        handler.postDelayed(applySeek, 350)
    }

    private fun togglePause() {
        val p = player ?: return
        p.playWhenReady = !p.playWhenReady
        showBars()
        refreshPauseIcon()
    }

    /** Thumbnail of the playing video, shown instead of the picture while Music mode is on. */
    private fun showMusicPicture() {
        if (!::musicView.isInitialized) return
        val v = cur
        musicView.visibility = if (musicMode && v != null) View.VISIBLE else View.GONE
        if (musicMode && v != null) Img.load(musicView, v.thumb, dp(480))
    }

    /** Music mode on / off: same video, same second, only the sound (or sound + picture) is loaded. */
    private fun toggleMusic() {
        musicMode = !musicMode
        val pos = player?.currentPosition ?: 0L
        showMusicPicture()
        toast(if (musicMode) "Music mode: audio only (next videos too)" else "Video back on")
        closePanel()
        val s = stream
        if (s != null) {
            mode = 0
            play(s, pos)
        }
    }

    private fun qualityDialog() {
        val s = stream ?: return
        val hs = s.heights()
        if (hs.isEmpty()) return
        val labels = hs.map { "${it}p" + (if (it == curHeight) "   ✓" else "") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Quality")
            .setItems(labels) { _, i ->
                Store.setQuality(this, hs[i])
                val pos = player?.currentPosition ?: 0L
                mode = 0
                play(s, pos)
            }
            .show()
    }

    private fun openChannel(v: Vid) {
        val i = Intent(this, ChannelActivity::class.java)
        i.putExtra(ChannelActivity.EXTRA_ID, v.channelId)
        i.putExtra(ChannelActivity.EXTRA_NAME, v.channel)
        startActivity(i)
        // leave the player: Back from the channel page then goes to where you came from,
        // not to an old video (and the video decoder / buffer is freed)
        finish()
    }

    /** Exit: straight back to the app's main screen, on whatever tab was open. */
    private fun goHome() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
        finish()
    }

    /** Down: Open channel, Subscribe / Unsubscribe, then the "Up next" videos. */
    private fun menuDialog() {
        val v = cur
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (v != null && v.channelId.isNotEmpty()) {
            val name = v.channel.ifEmpty { "this channel" }
            labels.add("Open channel: $name")
            acts.add { openChannel(v) }
            labels.add(if (Store.isSub(this, v.channelId)) "Unsubscribe: $name" else "Subscribe: $name")
            acts.add {
                val now = Store.toggleSub(this, Chan(v.channelId, v.channel))
                toast(if (now) "Subscribed: $name" else "Unsubscribed: $name")
            }
        }
        for (r in nextList().take(20)) {
            labels.add("Up next:  " + r.title)
            acts.add { startVideo(r) }
        }
        if (labels.isEmpty()) {
            toast("Loading suggestions...")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) UiUtil.immersive(window)
    }

    private fun dp(v: Int): Int = UiUtil.dp(this, v)

    // ------------------------------------------------------------------ YouTube-style bottom panel

    private fun buildPanel() {
        val host = findViewById<ViewGroup>(android.R.id.content)
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.parseColor("#F2101010"))
        panel.setPadding(dp(30), dp(12), dp(30), dp(8))
        panel.clipChildren = false
        panel.visibility = View.GONE

        val cs = HorizontalScrollView(this)
        cs.isHorizontalScrollBarEnabled = false
        panelChips = LinearLayout(this)
        panelChips.orientation = LinearLayout.HORIZONTAL
        cs.addView(panelChips)
        panel.addView(cs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lbl = TextView(this)
        lbl.text = "Up next"
        lbl.setTextColor(Color.WHITE)
        lbl.textSize = 17f
        lbl.setTypeface(null, Typeface.BOLD)
        lbl.setPadding(dp(4), dp(10), 0, dp(6))
        panel.addView(lbl)
        panelLabel = lbl

        val rs = HorizontalScrollView(this)
        rs.isHorizontalScrollBarEnabled = false
        rs.clipToPadding = false
        rs.clipChildren = false
        rs.setPadding(dp(14), dp(14), dp(14), dp(14))
        panelRow = LinearLayout(this)
        panelRow.orientation = LinearLayout.HORIZONTAL
        panelRow.clipChildren = false
        rs.addView(panelRow)
        panelScroll = rs
        panel.addView(rs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        host.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }

    private fun chip(text: String, on: Boolean = false, click: (TextView) -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 16f
        t.setPadding(dp(20), dp(8), dp(20), dp(8))
        t.setBackgroundResource(R.drawable.chip_bg)
        t.isFocusable = true
        t.isClickable = true
        t.isSelected = on
        t.setTextColor(if (on) Color.BLACK else Color.WHITE)
        t.setOnClickListener { click(t) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(10)
        panelChips.addView(t, lp)
        return t
    }

    private fun setOn(t: TextView, on: Boolean) {
        t.isSelected = on
        t.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun fillPanel() {
        panelChips.removeAllViews()
        panelRow.removeAllViews()
        val v = cur
        chip("Previous") { prevVideo() }
        chip("Next") { nextVideo() }
        if (v != null && v.channelId.isNotEmpty()) {
            val name = v.channel.ifEmpty { "channel" }
            chip("Channel: $name") { closePanel(); openChannel(v) }
            chip(if (Store.isSub(this, v.channelId)) "Subscribed" else "Subscribe", Store.isSub(this, v.channelId)) { t ->
                val now = Store.toggleSub(this, Chan(v.channelId, v.channel))
                t.text = if (now) "Subscribed" else "Subscribe"
                setOn(t, now)
                toast(if (now) "Subscribed: $name" else "Unsubscribed: $name")
            }
        }
        chip(if (musicMode) "Exit music mode" else "Music mode", musicMode) { toggleMusic() }
        chip("Quality") { closePanel(); qualityDialog() }
        chip("Exit to Home") { goHome() }
        chip(if (Store.autoplay(this)) "Autoplay: On" else "Autoplay: Off") { t ->
            val now = !Store.autoplay(this)
            Store.setAutoplay(this, now)
            t.text = if (now) "Autoplay: On" else "Autoplay: Off"
        }

        // playing from a playlist / channel: show the whole list (this video marked); else YouTube's suggestions
        val inQueue = qIdx >= 0 && queue.size > 1
        val list = if (inQueue) queue.take(150) else related.take(20)
        panelLabel.text = if (inQueue)
            (queueTitle.ifEmpty { "Playlist" }) + "   \u2022   ${qIdx + 1} / ${queue.size}"
        else "Up next"
        if (list.isEmpty()) {
            val l = TextView(this)
            l.text = "Loading suggestions..."
            l.setTextColor(Color.parseColor("#AAAAAA"))
            l.textSize = 15f
            l.setPadding(dp(4), dp(10), 0, dp(10))
            panelRow.addView(l)
        }
        var nowIdx = -1
        for ((i, r) in list.withIndex()) {
            val isNow = inQueue && r.id == v?.id
            if (isNow) nowIdx = i
            panelRow.addView(upCard(r, isNow))
        }
        // land on the next video of the list (YouTube style), or the first suggestion
        panelTargetIdx = if (nowIdx >= 0) minOf(nowIdx + 1, list.size - 1) else 0
        if (nowIdx > 0) panelScroll.post { panelScroll.scrollTo(maxOf(0, nowIdx * dp(178) - dp(40)), 0) }
    }

    /** Focus goes to the video row, not to the buttons above it (they are one Up away). */
    private fun focusPanelDefault() {
        var t: View? = null
        if (panelRow.childCount > 0) t = panelRow.getChildAt(panelTargetIdx.coerceIn(0, panelRow.childCount - 1))
        if (t == null || !t.isFocusable) t = if (panelChips.childCount > 0) panelChips.getChildAt(0) else null
        t?.requestFocus()
    }

    private fun upCard(r: Vid, isNow: Boolean = false): View {
        val w = dp(170)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(4), dp(4), dp(4), dp(6))
        card.setBackgroundResource(R.drawable.card_bg)
        card.isFocusable = true
        card.isClickable = true
        UiUtil.focusZoom(card, 1.14f)

        val img = android.widget.ImageView(this)
        img.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(Color.parseColor("#222222"))
        UiUtil.roundRect(img, dp(10).toFloat())
        card.addView(img, LinearLayout.LayoutParams(w, w * 9 / 16))
        Img.load(img, r.thumb, w)

        val title = TextView(this)
        title.text = r.title
        title.setTextColor(Color.WHITE)
        title.textSize = 13f
        title.setTypeface(null, Typeface.BOLD)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        title.setPadding(0, dp(5), 0, 0)
        card.addView(title, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))

        val ch = TextView(this)
        ch.text = if (isNow) "\u25B6  Now playing" else r.channel
        ch.setTextColor(Color.parseColor(if (isNow) "#FF5252" else "#AAAAAA"))
        ch.textSize = 11f
        ch.maxLines = 1
        ch.ellipsize = TextUtils.TruncateAt.END
        card.addView(ch, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))

        card.setOnClickListener { if (isNow) closePanel() else { closePanel(); startVideo(r) } }
        val lp = LinearLayout.LayoutParams(w + dp(8), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(8)
        card.layoutParams = lp
        return card
    }

    private fun openPanel() {
        panelOpen = true
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        fillPanel()
        panel.visibility = View.VISIBLE
        focusPanelDefault()
    }

    private fun closePanel() {
        panelOpen = false
        panel.visibility = View.GONE
        showBars()
    }

    /** Touch: tap the video to show / hide the controls. */
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (panelOpen) {
            if (event.action == MotionEvent.ACTION_UP) closePanel()
            return true
        }
        if (event.action == MotionEvent.ACTION_DOWN) return true
        if (event.action == MotionEvent.ACTION_UP) {
            if (topBar.visibility == View.VISIBLE) {
                topBar.visibility = View.GONE
                bottomBar.visibility = View.GONE
                barHideAt = 0L
            } else {
                showBars()
            }
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (panelOpen) {
            // panel is open: Back closes it, every other key moves / clicks inside it
            if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP) closePanel()
                return true
            }
            // Up with nothing above (top chips row): hide the panel
            if (event.keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    val f = currentFocus
                    val n = f?.focusSearch(View.FOCUS_UP)
                    if (f == null || n == null || !UiUtil.isInside(n, panel)) closePanel()
                    else n.requestFocus()
                }
                return true
            }
            if (event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                event.keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    val p = player
                    if (p != null) p.playWhenReady = event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                        (event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE && !p.playWhenReady)
                }
                return true
            }
            return super.dispatchKeyEvent(event)
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (event.repeatCount == 0) togglePause()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { player?.playWhenReady = true; showBars(); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { player?.playWhenReady = false; showBars(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { nudge(-1, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { nudge(1, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PROG_RED -> {
                    if (event.repeatCount == 0) {
                        // Up right after seeking, or while the bar is hidden, only shows the bar.
                        // The quality list opens on a second, deliberate Up (RED button always opens it).
                        val justSeeked = pendingSeekMs >= 0 || SystemClock.elapsedRealtime() - lastSeekAt < 2000L
                        if (event.keyCode == KeyEvent.KEYCODE_PROG_RED || (!justSeeked && bottomBar.visibility == View.VISIBLE)) qualityDialog()
                        else showBars()
                    }
                    return true
                }
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_BLUE -> {
                    if (event.repeatCount == 0) openPanel()
                    return true
                }
                KeyEvent.KEYCODE_INFO -> { showBars(); return true }
                KeyEvent.KEYCODE_MEDIA_STOP -> { finish(); return true }
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PROG_GREEN -> {
                    if (event.repeatCount == 0) nextVideo()
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_PROG_YELLOW -> {
                    if (event.repeatCount == 0) prevVideo()
                    return true
                }
                // number keys: jump to 0%, 10% ... 90% of the video (like on the YouTube website)
                KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_4,
                KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_9 -> {
                    val p = player
                    val d = p?.duration ?: C.TIME_UNSET
                    if (p != null && d != C.TIME_UNSET && d > 0 && event.repeatCount == 0) {
                        val t = d * (event.keyCode - KeyEvent.KEYCODE_0) / 10
                        markSeek()
                        p.seekTo(t)
                        seekText.text = fmt(t)
                        seekText.visibility = View.VISIBLE
                        handler.postDelayed({ seekText.visibility = View.GONE }, 900)
                        showBars()
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (event.repeatCount == 0) openPanel()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> { nextVideo(); return true }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { prevVideo(); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        inForeground = true
        if (wasPlaying) {
            wasPlaying = false
            player?.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        inForeground = false
        reportWatch(true)
        wasPlaying = player?.playWhenReady == true
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        reportWatch(true)
        closing = true
        gen++
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
